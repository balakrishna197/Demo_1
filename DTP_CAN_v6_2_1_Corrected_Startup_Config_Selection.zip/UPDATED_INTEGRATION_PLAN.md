# DTP-CAN v6.2.1 – Corrected Startup/Configuration Integration

## Problem corrected

The previous refactoring introduced two behavioral regressions:

1. `main.py` loaded `drivers/config/config.json` before Git selection, which made that local JSON mandatory during build/runtime.
2. The new startup selector printed all choices and used numeric selection instead of preserving the previous interactive selection behavior.
3. The startup workflow printed `Diagnostic main menu is intentionally not started.` and then exited. That message is removed; the application simply completes startup and exits.

## Correct design

The JSON configuration is a **runtime-selected Git artifact**, not a build-time dependency.

The build therefore does not check for or package `drivers/config/config.json`.

At runtime:

```text
main.py
  |
  +--> AppPaths
  |
  +--> WiFiManager --> Wi-Fi selection
  |
  +--> GitRepository
          |
          +--> Employee
          +--> Variant
          +--> Type
          +--> Stage
          +--> Date
          +--> matching branch
          +--> clone/pull
          +--> testcase discovery
          +--> config discovery
  |
  +--> ConfigLoader(selected_absolute_config_path)
  |
  +--> Repository Ready
  |
  +--> EXIT
```

The diagnostic application/main menu is not invoked.

## Selection behavior

The previous selector concept is preserved:

- Only the current option is displayed.
- `Enter` selects the current option.
- `N` / `D` moves to the next option.
- `P` / `A` moves to the previous option.
- A single testcase/config is automatically selected, matching the previous behavior.

This prevents the terminal from dumping a large numbered list of options.

## Configuration path

After Git selection, the selected JSON is converted to an absolute path and loaded directly:

```python
config = self.config_loader.load(config_path)
```

The resulting output is:

```text
Using absolute configuration path: /absolute/path/to/<selected-git-repository>/<config>.json
```

Therefore the JSON does **not** have to be copied into:

```text
drivers/config/config.json
```

## Files modified

- `main.py`
- `drivers/application/startup.py`
- `drivers/repository/git.py`
- `drivers/config/paths.py`
- `drivers/config/loader.py`
- `build_on_pi.sh`
- `run_on_pi.sh`
- `STARTUP_BEHAVIOR.md`

No existing directory was moved or renamed.
