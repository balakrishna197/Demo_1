#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_NAME="uds_diagnostics"
VENV_DIR="$PROJECT_DIR/venv"
OUTPUT_DIR="$PROJECT_DIR/dist"

printf '\n==============================================\n'
printf '  DTP-CAN v6.2.1 - Raspberry Pi Build Tool\n'
printf '==============================================\n\n'

printf '[1/6] Installing Raspberry Pi prerequisites...\n'
sudo apt-get update
sudo apt-get install -y python3-venv python3-pip python3-rpi-lgpio

printf '[2/6] Creating virtual environment...\n'
python3 -m venv --system-site-packages "$VENV_DIR"
source "$VENV_DIR/bin/activate"

printf '[3/6] Updating build tools...\n'
python -m pip install --upgrade pip setuptools wheel

printf '[4/6] Installing Python dependencies...\n'
python -m pip install pyinstaller adafruit-circuitpython-ssd1306 adafruit-blinka Pillow python-can can-isotp udsoncan

printf '[5/6] Verifying modular package...\n'
cd "$PROJECT_DIR"
python -m compileall -q main.py drivers
python -c "import drivers; import drivers.application.startup; import drivers.network.wifi; import drivers.repository.git; print('drivers package OK')"

printf '[6/6] Building executable...\n'
# IMPORTANT: config.json is a runtime-selected file from the Git repository.
# Therefore the build must NOT require drivers/config/config.json to exist.
python -m PyInstaller \
    --onefile \
    --clean \
    --name "$APP_NAME" \
    --collect-submodules drivers \
    --hidden-import RPi \
    --hidden-import RPi.GPIO \
    --hidden-import adafruit_blinka \
    --hidden-import adafruit_blinka.board \
    --hidden-import adafruit_platformdetect \
    --hidden-import busio \
    --hidden-import adafruit_ssd1306 \
    --hidden-import PIL \
    --hidden-import PIL.Image \
    --hidden-import can \
    --hidden-import can.interfaces.socketcan \
    --hidden-import can.io.asc \
    --hidden-import isotp \
    --hidden-import udsoncan \
    --hidden-import udsoncan.client \
    --hidden-import udsoncan.connections \
    --hidden-import udsoncan.configs \
    --hidden-import udsoncan.services \
    main.py

chmod +x "$OUTPUT_DIR/$APP_NAME"
printf '\nBuild complete: %s\n' "$OUTPUT_DIR/$APP_NAME"
printf 'Run with: ./dist/%s\n' "$APP_NAME"
