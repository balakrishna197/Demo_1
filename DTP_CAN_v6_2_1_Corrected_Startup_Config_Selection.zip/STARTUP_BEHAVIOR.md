# DTP-CAN v6.2.1 Startup Behavior

## Preserved behavior

The refactored executable preserves the previous startup sequence:

1. Scan/select Wi-Fi.
2. Git selection: Employee -> Variant -> Type -> Stage -> Date.
3. Resolve the matching branch.
4. Clone/pull the selected branch.
5. Auto-select a single testcase/config, or interactively select when multiple exist.
6. Load the selected JSON using its **absolute path**.
7. Show repository-ready information.
8. Stop. The diagnostic/main menu is never started.

## Selection behavior

The terminal no longer prints every option as a numbered list. Only the current
option is shown.

- **Enter**: select the currently displayed option.
- **N / D**: next option.
- **P / A**: previous option.

This matches the previous selector concept while avoiding a full list on screen.

## Configuration behavior

`drivers/config/config.json` is NOT required for the build.

The build script only compiles/packages the application. The runtime config is
discovered after the Git branch is selected and is loaded from the selected Git
repository with an absolute path.

Therefore the correct runtime flow is:

```text
Build executable
      |
      v
Run executable
      |
      v
Wi-Fi selection
      |
      v
Git hierarchy selection
      |
      v
Branch clone/pull
      |
      v
Config discovered in selected repository
      |
      v
Absolute config path
      |
      v
ConfigLoader
      |
      v
Repository Ready
      |
      v
Exit (no diagnostic main menu)
```
