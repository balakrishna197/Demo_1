"""DTP-CAN startup workflow.

The startup workflow preserves the previous v6.2.1 behavior:

1. Scan Wi-Fi and select one interactively.
2. Discover Git metadata from remote branches.
3. Select Employee -> Variant -> Type -> Stage -> Date.
4. Resolve the matching Git branch, clone/pull it.
5. Select testcase/config when more than one exists; auto-select when only one exists.
6. Load the selected JSON using its absolute path.

The diagnostic/main menu is deliberately not started from this executable.
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass
from pathlib import Path

from drivers.config.loader import ConfigLoader
from drivers.config.models import AppConfig
from drivers.network.wifi import WiFiManager, WifiNetwork
from drivers.repository.git import GitRepository
from drivers.ui.terminal import TerminalUI


@dataclass(frozen=True)
class StartupResult:
    wifi_ssid: str | None
    employee: str | None
    variant: str | None
    test_type: str | None
    stage: str | None
    date: str | None
    branch: str | None
    testcase: str | None
    config_path: str | None
    config: AppConfig | None
    commit: str | None


class StartupCoordinator:
    """Preserve the old interactive startup behavior without starting main_menu."""

    def __init__(
        self,
        ui: TerminalUI,
        wifi: WiFiManager,
        git: GitRepository,
        config_loader: ConfigLoader,
        config_path_hint: str | Path | None = None,
    ) -> None:
        self.ui = ui
        self.wifi = wifi
        self.git = git
        self.config_loader = config_loader
        self.config_path_hint = Path(config_path_hint).resolve() if config_path_hint else None

    def run(self) -> StartupResult:
        ssid = self._select_wifi()

        employee = variant = test_type = stage = date = None
        branch = testcase = config_path = None
        config = None

        employee = self._select("Employee", self.git.get_employee_ids())
        variant = self._select("Variant", self.git.get_variants(employee))
        test_type = self._select("Type", self.git.get_types(employee, variant))
        stage = self._select("Stage", self.git.get_stages(employee, variant, test_type))
        date = self._select("Date", self.git.get_dates(employee, variant, test_type, stage))

        branch = self.git.get_matching_branch(employee, variant, test_type, stage, date)
        self.ui.show(f"Selected Branch: {branch}")
        self.git.clone_repository(branch)
        self.git.pull_repository()

        testcases, configs = self.git.get_testcases_and_configs()
        testcase = self._auto_or_select("Testcase", testcases, formatter=os.path.basename)
        config_path = self._auto_or_select("Config", configs, formatter=os.path.basename)

        # The selected Git config is the real runtime configuration.  Do not
        # require drivers/config/config.json to exist during the build.
        config = self.config_loader.load(config_path)

        commit = self.git.current_commit(repository_path=self.git.repo_path)
        self.ui.show("Repository Ready")
        self.ui.show(f"Absolute configuration path: {config_path}")
        if commit:
            self.ui.show(f"Git commit: {commit}")

        return StartupResult(
            wifi_ssid=ssid,
            employee=employee,
            variant=variant,
            test_type=test_type,
            stage=stage,
            date=date,
            branch=branch,
            testcase=testcase,
            config_path=config_path,
            config=config,
            commit=commit,
        )

    def _select_wifi(self) -> str | None:
        self.ui.show("\n=== Wi-Fi Setup ===")
        networks = self.wifi.scan()
        if not networks:
            raise RuntimeError("No Wi-Fi networks found.")

        selected = self._select("Wi-Fi", networks, formatter=lambda n: n.ssid)
        ssid = selected.ssid

        if self.wifi.is_connected(ssid):
            self.ui.show(f"Already connected to: {ssid}")
            return ssid

        if self.config_path_hint:
            # A build-time config is only a hint.  It is never required.
            try:
                cfg = self.config_loader.load(self.config_path_hint)
                if cfg.network.saved_ssid == ssid and self.wifi.connect_saved(ssid):
                    self.ui.show(f"Connected to: {ssid}")
                    return ssid
            except (FileNotFoundError, ValueError):
                pass

        password = input(f"Enter Wi-Fi password for '{ssid}': ")
        if not self.wifi.connect(ssid, password):
            raise RuntimeError(f"Failed to connect to Wi-Fi: {ssid}")
        self.ui.show(f"Connected to: {ssid}")
        return ssid

    def _select(self, title: str, items, formatter=str):
        """Show only the current option; Enter selects it.

        Navigation is intentionally compatible with the previous UI:
        previous/next can be used to move, and Enter selects.  The terminal
        does not print the complete option list.
        """
        if not items:
            raise RuntimeError(f"No {title} options found.")

        index = 0
        while True:
            value = formatter(items[index])
            self.ui.show("")
            self.ui.show(f"Select {title}: {value}")
            self.ui.show("Press Enter to select | N/D = next | P/A = previous")
            command = input("> ").strip().lower()

            if command == "":
                return items[index]
            if command in {"n", "d"}:
                index = (index + 1) % len(items)
                continue
            if command in {"p", "a"}:
                index = (index - 1) % len(items)
                continue
            self.ui.show("Press Enter to select, or use N/D/P/A to navigate.")

    def _auto_or_select(self, title: str, items, formatter=str):
        if not items:
            raise RuntimeError(f"No {title} files found.")
        if len(items) == 1:
            value = items[0]
            self.ui.show(f"{title} Auto Selected: {formatter(value)}")
            time.sleep(0.5)
            return value
        return self._select(title, items, formatter=formatter)
