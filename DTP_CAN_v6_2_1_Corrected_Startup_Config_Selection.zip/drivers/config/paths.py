"""Absolute runtime path handling for DTP-CAN v6.2.1."""

from __future__ import annotations

import os
import sys
from pathlib import Path


class AppPaths:
    CONFIG_FILENAME = "config.json"
    CONFIG_ENV_VAR = "DTP_CAN_CONFIG_PATH"

    def __init__(self, base_dir: str | Path | None = None) -> None:
        self.base_dir = self._detect_base_dir(base_dir)
        env_path = os.environ.get(self.CONFIG_ENV_VAR)
        self.config_file = Path(env_path).expanduser().resolve() if env_path else None
        self.output_dir = (self.base_dir / "output").resolve()
        self.html_reports_dir = (self.output_dir / "html_reports").resolve()
        self.can_logs_dir = (self.output_dir / "can_logs").resolve()
        self.logs_dir = (self.output_dir / "logs").resolve()

    @staticmethod
    def _detect_base_dir(base_dir=None) -> Path:
        if base_dir is not None:
            return Path(base_dir).expanduser().resolve()
        if getattr(sys, "frozen", False):
            exe = Path(sys.executable).resolve().parent
            return exe.parent if exe.name.lower() == "dist" else exe
        return Path(__file__).resolve().parents[2]

    def resolve_config(self, path=None, required=True) -> Path:
        if path is None:
            if self.config_file is None:
                candidate = (self.base_dir / "drivers" / "config" / self.CONFIG_FILENAME).resolve()
            else:
                candidate = self.config_file
        else:
            requested = Path(path).expanduser()
            candidate = requested.resolve() if requested.is_absolute() else (self.base_dir / requested).resolve()

        if required and not candidate.is_file():
            raise FileNotFoundError(
                "DTP-CAN configuration file not found.\n"
                f"ABSOLUTE CONFIGURATION PATH: {candidate}"
            )
        return candidate

    def ensure_output_dirs(self):
        for directory in (self.output_dir, self.html_reports_dir, self.can_logs_dir, self.logs_dir):
            directory.mkdir(parents=True, exist_ok=True)
