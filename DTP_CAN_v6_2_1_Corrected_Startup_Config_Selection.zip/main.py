"""DTP-CAN v6.2.1 executable entry point.

Startup preserves the previous Wi-Fi/Git selection behavior.  The diagnostic
main menu is not started by this startup executable.
"""

from __future__ import annotations

from drivers.application.startup import StartupCoordinator
from drivers.config.loader import ConfigLoader
from drivers.config.paths import AppPaths
from drivers.network.wifi import WiFiManager
from drivers.repository.git import GitRepository
from drivers.ui.terminal import TerminalUI


def main() -> int:
    print("DTP-CAN v6.2.1 - modular application")

    paths = AppPaths()
    paths.ensure_output_dirs()

    ui = TerminalUI()
    loader = ConfigLoader(paths)
    wifi = WiFiManager()
    git = GitRepository(str(paths.base_dir))

    startup = StartupCoordinator(
        ui=ui,
        wifi=wifi,
        git=git,
        config_loader=loader,
        # Optional hint only. It is NOT required to build or start.
        config_path_hint=paths.config_file,
    )
    startup.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
