#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="$PROJECT_DIR/dist/uds_diagnostics"

if [[ ! -x "$APP" ]]; then
    echo "Executable not found: $APP"
    echo "Run ./build_on_pi.sh first."
    exit 1
fi

# No config.json check here. The config is selected after the Git repository
# startup flow and its absolute path is passed directly to ConfigLoader.
exec "$APP" "$@"
