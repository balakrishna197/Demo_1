#!/usr/bin/env bash
# Build DTP-CAN v6.2.1 modular application on Raspberry Pi OS.
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_NAME="uds_diagnostics"
VENV_DIR="$PROJECT_DIR/venv"
OUTPUT_DIR="$PROJECT_DIR/dist"

printf '\n==============================================\n'
printf '  DTP-CAN v6.2.1 - Raspberry Pi Build Tool\n'
printf '==============================================\n\n'

printf '[1/7] Installing Raspberry Pi prerequisites...\n'
sudo apt-get update
sudo apt-get install -y python3-venv python3-pip python3-rpi-lgpio

printf '[2/7] Creating virtual environment...\n'
python3 -m venv --system-site-packages "$VENV_DIR"
# shellcheck disable=SC1091
source "$VENV_DIR/bin/activate"

printf '[3/7] Updating build tools...\n'
python -m pip install --upgrade pip setuptools wheel

printf '[4/7] Installing Python dependencies...\n'
python -m pip install \
    pyinstaller \
    adafruit-circuitpython-ssd1306 \
    adafruit-blinka \
    Pillow \
    python-can \
    can-isotp \
    udsoncan

printf '[5/7] Verifying GPIO compatibility...\n'
python -c "import RPi.GPIO as GPIO; print('GPIO backend:', GPIO.VERSION)"

printf '[6/7] Checking modular drivers package...\n'
python -c "import drivers; import drivers.network.wifi; import drivers.diagnostic.executor; import drivers.reporting.report_manager; print('drivers package OK')"

printf '[7/7] Building executable with PyInstaller...\n'
cd "$PROJECT_DIR"

PYINSTALLER_DATA_ARGS=()
while IFS= read -r imports_json; do
    PYINSTALLER_DATA_ARGS+=(--add-data "$imports_json:.")
done < <(python - <<'PY'
import pathlib
import site
import sysconfig

package_dirs = set(site.getsitepackages())
package_dirs.add(site.getusersitepackages())
package_dirs.update(sysconfig.get_paths().get(key) for key in ("purelib", "platlib"))

for package_dir in sorted(path for path in package_dirs if path):
    directory = pathlib.Path(package_dir)
    if directory.is_dir():
        for data_file in sorted(directory.glob("*_imports.json")):
            print(data_file)
PY
)

if (( ${#PYINSTALLER_DATA_ARGS[@]} == 0 )); then
    echo "No Blinka *_imports.json files found in the active Python environment." >&2
    exit 1
fi

python -m PyInstaller \
    --onefile \
    --clean \
    --name "$APP_NAME" \
    --collect-all adafruit_platformdetect \
    --collect-all adafruit_blinka \
    --collect-all digitalio \
    --collect-all busio \
    --collect-all microcontroller \
    --collect-data microcontroller \
    --collect-submodules drivers \
    --hidden-import board \
    "${PYINSTALLER_DATA_ARGS[@]}" \
    --hidden-import RPi \
    --hidden-import RPi.GPIO \
    --hidden-import adafruit_blinka \
    --hidden-import adafruit_blinka.board \
    --hidden-import adafruit_platformdetect \
    --hidden-import adafruit_platformdetect.constants \
    --hidden-import busio \
    --hidden-import adafruit_ssd1306 \
    --hidden-import PIL \
    --hidden-import PIL.Image \
    --hidden-import PIL.ImageDraw \
    --hidden-import PIL.ImageFont \
    --hidden-import can \
    --hidden-import can.interfaces.socketcan \
    --hidden-import can.io.asc \
    --hidden-import isotp \
    --hidden-import udsoncan \
    --hidden-import udsoncan.client \
    --hidden-import udsoncan.connections \
    --hidden-import udsoncan.configs \
    --hidden-import udsoncan.services \
    main.py

if [[ -f "$OUTPUT_DIR/$APP_NAME" ]]; then
    chmod +x "$OUTPUT_DIR/$APP_NAME"
    echo ""
    echo "Build complete: $OUTPUT_DIR/$APP_NAME"
    echo "Run with: ./dist/$APP_NAME"
else
    echo "Build failed: executable not found at $OUTPUT_DIR/$APP_NAME" >&2
    exit 1
fi
