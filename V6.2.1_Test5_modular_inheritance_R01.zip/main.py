"""Application composition root for the modular
DTP-CAN diagnostic tool.
"""

import logging
import os
import subprocess
import sys
import time

# import RPi.GPIO as GPIO

from drivers.config_handler import JsonConfigurationHandler
from drivers.diagnostic_handler import UDSClient
from drivers.git_handler import GitManager, GitWorkflow
from drivers.input_handler import LocalInputFileHandler, USBTransfer
from drivers.network_handler import WifiManager
from drivers.system_handler import RaspberryPiSystemHandler
from drivers.ui_handler import UIHandler


if getattr(sys, "frozen", False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

LOG_DIR = os.path.join(BASE_DIR, "logs")
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, "uds_debug.log")

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, mode="w"),
        logging.StreamHandler(),
    ],
)


class DiagnosticApplication:
    """Coordinates independent handlers; business behavior
    lives in handlers.
    """

    def __init__(self, base_dir=BASE_DIR):
        self.base_dir = base_dir
        self.config = None
        self.ui = None
        self.git = None
        self.uds = None
        self.usb = None
        self.wifi = None
        self.initialized_once = False
        self.selected_branch = None
        self.selected_testcase = None
        self.selected_config = None
        self.report_branch_name = "N/A"
        self.report_branch_url = ""

        self.config_loader = JsonConfigurationHandler(base_dir)
        self.input_files = LocalInputFileHandler(base_dir)
        self.system = RaspberryPiSystemHandler()

    def resolve_ui_mode(self):
        requested = (
            os.environ.get("DTP_UI_MODE", "auto").strip().lower()
        )
        if requested in {"oled", "hardware"}:
            return "hardware"
        if requested in {"terminal", "console"}:
            return "terminal"
        return "auto"

    def selector(self, title, items, formatter=str, allow_cancel=False):
        return self.ui.select_from_list(
            title,
            items,
            formatter,
            allow_cancel,
        )

    def setup_repository(self):
        self.git = GitManager(self.base_dir)
        workflow = GitWorkflow(
            repository=self.git,
            selector=self.selector,
            display=self.ui.oled,
            config_loader=self.config_loader,
            input_handler=self.input_files,
        )
        selection, config = workflow.setup()
        self.config = config
        self.selected_branch = selection.branch
        self.selected_testcase = selection.testcase
        self.selected_config = selection.config
        self.report_branch_name = selection.branch
        self.report_branch_url = selection.branch_url
        logging.info("Employee: %s", selection.employee)
        logging.info("Variant: %s", selection.variant)
        logging.info("Type: %s", selection.test_type)
        logging.info("Stage: %s", selection.stage)
        logging.info("Date: %s", selection.date)
        logging.info("Branch: %s", selection.branch)
        logging.info("Testcase: %s", selection.testcase)
        logging.info("Config: %s", selection.config)

    def check_can0_present(self):
        result = subprocess.run(
            "ip link show can0",
            shell=True,
            stdout=subprocess.PIPE,
        )
        return "can0" in result.stdout.decode()

    def bringup_can_interface(self, can_config):
        try:
            logging.info("Bringing up CAN interface can0...")
            subprocess.run(
                ["sudo", "ip", "link", "set", "can0", "down"],
                check=True,
            )
            subprocess.run(
                [
                    "sudo",
                    "ip",
                    "link",
                    "set",
                    "can0",
                    "up",
                    "type",
                    "can",
                    "bitrate",
                    str(can_config.get("bitrate", 500000)),
                    "dbitrate",
                    str(can_config.get("dbitrate", 2000000)),
                    "restart-ms",
                    str(can_config.get("restart_ms", 1000)),
                    "berr-reporting",
                    "on",
                    "fd",
                    "on",
                ],
                check=True,
            )
            subprocess.run(["sudo", "ifconfig", "can0", "up"], check=True)
        except subprocess.CalledProcessError as exc:
            logging.error("CAN bringup failed: %s", exc)
            self.ui.oled.display_centered_text("CAN init failed")
            time.sleep(2)

    def initialize(self):
        self.system.initialize()
        self.system.setup_ssh()
        self.system.install_service()
        self.ui = UIHandler(self.resolve_ui_mode())
        self.wifi = WifiManager(self.ui.oled, self.ui)
        self.wifi.setup()
        self.wifi.start_monitor()

        self.setup_repository()

        self.uds = UDSClient(
            self.config,
            config_path=self.selected_config,
            repo_path=self.git.repo_path,
        )
        self.uds.report_branch_name = self.report_branch_name
        self.uds.report_branch_url = self.report_branch_url

        connected = False
        for retry in range(1, 4):
            self.ui.oled.display_centered_text(
                f"Checking\nUDP Server...\n\n{retry}/3"
            )
            try:
                if self.uds.check_udp_server():
                    connected = True
                    break
            except Exception:
                logging.exception("UDP server check failed")
            if retry < 3:
                self.ui.oled.display_centered_text(
                    f"UDP Server\nNot Found\n\nRetry {retry}/3"
                )
                time.sleep(2)

        self.uds.udp_server_available = connected
        can_config = (self.config or {}).get("uds", {}).get("can", {})
        if can_config.get("bringup_on_startup", False):
            deadline = time.time() + 60
            while time.time() < deadline:
                if self.check_can0_present():
                    self.bringup_can_interface(can_config)
                    time.sleep(1)
                    try:
                        if UDSClient(self.config).try_basic_communication():
                            break
                    except Exception:
                        logging.exception("UDS handshake failed")
                time.sleep(2)
            else:
                self.ui.oled.display_centered_text(
                    "CAN/ECU Timeout\nCheck Setup"
                )
                raise SystemExit(
                    "Initialization failed: CAN or ECU not "
                    "responding."
                )

        self.usb = USBTransfer(self.ui.oled)
        self.initialized_once = True

    def run(self):
        self.initialize()
        self.main_menu()

    def main_menu(self):
        while True:
            self.ui.oled.display_centered_text(
                "1 ECU info\n2 Run TestCases\n3 ShutDown\n"
                "4 Push to Bitbucket"
            )
            selected = (
                self.ui.poll_main_menu_selection()
                if hasattr(self.ui, "poll_main_menu_selection")
                else None
            )
            if selected is None:
                # Keep terminal operation usable even when no hardware button
                # is present.
                try:
                    selected = input("Select option [1-4]: ").strip()
                except EOFError:
                    return
            if selected == "1":
                self.uds.get_ecu_information(self.ui.oled)
                self.ui.oled.display_centered_text("Done")
            elif selected == "2":
                self.git.start_report_tracking()
                tester = self.ui.enter_text("Tester Name") or "N/A"
                self.uds.run_testcase(self.ui.oled, tester_name=tester)
                self.git.finish_report_tracking()
            elif selected == "3":
                subprocess.run(["sudo", "poweroff"], check=False)
                return
            elif selected == "4":
                self.ui.oled.display_centered_text(
                    "Uploading\nReports to Bitbucket..."
                )
                try:
                    self.git.copy_reports()
                    self.git.git_add()
                    self.git.git_commit()
                    self.git.git_push()
                    self.ui.oled.display_centered_text("Upload\nComplete")
                except Exception:
                    logging.exception("Bitbucket push failed")
                    self.ui.oled.display_centered_text(
                        "Bitbucket Push\nFailed"
                    )
                time.sleep(2)

    def shutdown(self):
        if self.wifi:
            self.wifi.shutdown()
        if self.ui and self.ui.terminal_input:
            self.ui.terminal_input.restore()


def main():
    app = DiagnosticApplication()
    try:
        app.run()
    finally:
        app.shutdown()


if __name__ == "__main__":
    main()
