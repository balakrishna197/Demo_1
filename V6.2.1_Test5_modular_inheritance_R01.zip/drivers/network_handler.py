"""Wi-Fi discovery, connection and monitoring."""

from abc import ABC, abstractmethod
import logging
import subprocess
import threading
import time


class NetworkHandler(ABC):
    @abstractmethod
    def scan(self):
        raise NotImplementedError

    @abstractmethod
    def connect(self, ssid, password):
        raise NotImplementedError


class WifiManager(NetworkHandler):
    def __init__(self, display, ui):
        self.display = display
        self.ui = ui
        self.current_ssid = None
        self.wifi_connected = False
        self.stop_monitor = False
        self.monitor_thread = None
        self.last_status = True

    def scan(self):
        try:
            result = subprocess.check_output(
                ["nmcli", "-t", "-f", "SSID", "dev", "wifi"],
                text=True,
            )
            networks = []
            for ssid in result.splitlines():
                ssid = ssid.strip()
                if ssid and ssid not in networks:
                    networks.append(ssid)
            return networks
        except Exception as exc:
            logging.error("WiFi Scan Error: %s", exc)
            return []

    def connect(self, ssid, password):
        self.display.display_centered_text(f"Connecting\n{ssid}")
        result = subprocess.run(
            [
                "nmcli", "--wait", "15", "device", "wifi", "connect",
                ssid,
                "password",
                password,
            ],
            capture_output=True,
            text=True,
        )
        logging.info(result.stdout)
        logging.error(result.stderr)
        return result.returncode == 0

    def is_connected(self, ssid):
        result = subprocess.run(
            ["nmcli", "-t", "-f", "ACTIVE,SSID", "device", "wifi"],
            capture_output=True,
            text=True,
        )
        return any(
            line == f"yes:{ssid}" for line in result.stdout.splitlines()
        )

    def try_saved_connection(self, ssid):
        result = subprocess.run(
            ["nmcli", "connection", "up", ssid],
            capture_output=True,
            text=True,
        )
        return result.returncode == 0

    def setup(self):
        self.display.display_centered_text("Scanning\nWiFi...")
        networks = self.scan()
        if not networks:
            self.display.display_centered_text("No WiFi\nFound")
            time.sleep(2)
            return False
        while True:
            selected = self.ui.select_from_list(
                "WiFi", networks, allow_cancel=True
            )
            if selected is None:
                self.display.display_centered_text("No WiFi\nConnected")
                return False
            ssid = networks[selected]
            saved = subprocess.run(
                ["nmcli", "-t", "-f", "NAME", "connection", "show"],
                capture_output=True,
                text=True,
            ).stdout.splitlines()
            if ssid in saved:
                if self.is_connected(ssid) or self.try_saved_connection(ssid):
                    self.current_ssid = ssid
                    self.wifi_connected = True
                    self.display.set_wifi_status("W+")
                    self.display.display_centered_text(f"Connected\n{ssid}")
                    time.sleep(1)
                    return True
                subprocess.run(
                    ["nmcli", "connection", "delete", ssid],
                    capture_output=True,
                    text=True,
                )
            # Terminal password prompt when available; hardware users can use
            # input().
            password = input(
                f"Enter WiFi password for '{ssid}': "
            )
            if self.connect(ssid, password):
                self.current_ssid = ssid
                self.wifi_connected = True
                self.display.set_wifi_status("W+")
                self.display.display_centered_text(f"Connected\n{ssid}")
                return True
            self.display.display_centered_text("Wrong Password\nTry Again")

    def start_monitor(self):
        self.stop_monitor = False
        self.monitor_thread = threading.Thread(
            target=self.monitor, daemon=True
        )
        self.monitor_thread.start()

    def reconnect(self):
        if not self.current_ssid:
            return False
        success = self.try_saved_connection(self.current_ssid)
        self.wifi_connected = success
        return success

    def monitor(self):
        while not self.stop_monitor:
            connected = bool(
                self.current_ssid and self.is_connected(self.current_ssid)
            )
            if connected:
                self.display.set_wifi_status("W+")
                self.last_status = True
            else:
                self.display.set_wifi_status("W~")
                self.last_status = False
                if self.reconnect():
                    self.display.set_wifi_status("W+")
                    self.last_status = True
                else:
                    self.display.set_wifi_status("W-")
            time.sleep(10)

    def shutdown(self):
        self.stop_monitor = True
        if (
            self.monitor_thread
            and self.monitor_thread.is_alive()
        ):
            self.monitor_thread.join(timeout=1)
