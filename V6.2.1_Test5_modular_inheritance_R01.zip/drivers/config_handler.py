"""Configuration loading with a small replaceable abstraction."""

from abc import ABC, abstractmethod
import json
import os
import sys


def get_base_path():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class ConfigurationHandler(ABC):
    @abstractmethod
    def load(self, config_path):
        raise NotImplementedError


class JsonConfigurationHandler(ConfigurationHandler):
    def __init__(self, base_path=None):
        self.base_path = base_path or get_base_path()

    def load(self, config_path):
        path = (
            config_path
            if os.path.isabs(config_path)
            else os.path.join(self.base_path, config_path)
        )
        if not os.path.exists(path):
            raise FileNotFoundError(f"Configuration file not found:\n{path}")
        try:
            with open(path, "r", encoding="utf-8") as file:
                return json.load(file)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"Invalid JSON format in:\n{path}\n\n{exc}"
            ) from exc
        except OSError as exc:
            raise OSError(
                f"Failed to load configuration:\n{path}\n\n{exc}"
            ) from exc


# Compatibility-style function for simple reuse without creating an object.
def load_config(config_path):
    return JsonConfigurationHandler().load(config_path)
