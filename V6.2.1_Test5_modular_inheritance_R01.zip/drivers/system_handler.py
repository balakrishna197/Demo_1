"""System-level setup: Raspberry Pi interfaces, SSH and service lifecycle."""

from abc import ABC, abstractmethod

import os
import pwd
import logging
import subprocess
import sys
# import textwrap
# from drivers import oled_display


class interface:
    def __init__(self):
        self.reboot_required = False
        self.config_file = "/boot/firmware/config.txt"

    # ---------------------------
    # Command runner
    # ---------------------------
    def _run(self, cmd):
        print(f"➡️ {cmd}")
        result = subprocess.run(
            cmd, shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        if result.returncode != 0:
            print(f"❌ {result.stderr.strip()}")
        return result.stdout.strip()

    # ---------------------------
    # Safe append using sudo
    # ---------------------------
    def _append_line_root(self, line):
        check = subprocess.run(
            f"grep -qxF '{line}' {self.config_file}",
            shell=True
        )

        if check.returncode == 0:
            return False  # already exists

        self._run(
            f"echo '{line}' | sudo tee -a {self.config_file} > /dev/null"
        )
        return True

    # ===========================
    # SPI
    # ===========================
    def _spi_enabled(self):
        return os.path.exists("/dev/spidev0.0")

    def _enable_spi(self):
        if self._spi_enabled():
            print("✅ SPI already enabled")
            return

        print("🔧 Enabling SPI...")
        if self._append_line_root("dtparam=spi=on"):
            self.reboot_required = True
            print("✅ SPI enabled (reboot required)")

    # ===========================
    # I2C
    # ===========================
    def _i2c_enabled(self):
        return os.path.exists("/dev/i2c-1")

    def _enable_i2c(self):
        if self._i2c_enabled():
            print("✅ I2C already enabled")
            return

        print("🔧 Enabling I2C...")
        if self._append_line_root("dtparam=i2c_arm=on"):
            self.reboot_required = True
            print("✅ I2C enabled (reboot required)")

    # ===========================
    # CAN FD
    # ===========================
    def _canfd_configured(self):
        result = subprocess.run(
            f"grep -q mcp251xfd {self.config_file}",
            shell=True
        )
        return result.returncode == 0

    def _enable_canfd(self):
        if self._canfd_configured():
            print("✅ CAN FD already configured")
            return

        print("🔧 Enabling CAN FD...")

        changes = False
        changes |= self._append_line_root("# CAN FD Setup")
        changes |= self._append_line_root("dtparam=spi=on")
        changes |= self._append_line_root(
            "dtoverlay=mcp251xfd, spi0-0, interrupt=25"
        )
        changes |= self._append_line_root(
            "dtoverlay=mcp251xfd, spi1-0, interrupt=24"
        )

        if changes:
            self.reboot_required = True
            print("✅ CAN FD config added (reboot required)")

    # ===========================
    # CAN FD Bring-up
    # ===========================
    def _can_exists(self):
        return os.path.exists("/sys/class/net/can0")

    def _can_up(self):
        output = self._run("ip link show can0")
        return "UP" in output

    def _bringup_canfd(self):
        if not self._can_exists():
            print("❌ CAN FD interface not found (reboot needed)")
            # self.oled.display_centered_text(
            #     "CAN FD interface not found (reboot needed)"
            # )
            return

        if self._can_up():
            print("✅ CAN FD already UP")
            return

        print("🔧 Bringing up CAN FD...")

        self._run("sudo ip link set can0 down")
        self._run(
            "sudo ip link set can0 up type can bitrate 1000000 "
            "dbitrate 8000000 "
            "restart-ms 1000 berr-reporting on fd on"
        )
        self._run("sudo ifconfig can0 txqueuelen 65536")
        self._run("sudo ip link set can0 up")

        if self._can_up():
            print("✅ CAN FD is UP")
            # self.oled.display_centered_text("CAN FD is UP")
        else:
            print("❌ CAN FD bring-up failed")
            # self.oled.display_centered_text("CAN FD bring-up failed")

    # ===========================
    # Reboot
    # ===========================
    def _handle_reboot(self):
        if self.reboot_required:
            print("\n⚠️ Reboot required. Rebooting...\n")
            sys.stdout.flush()
            subprocess.run("sudo reboot", shell=True)
            sys.exit(0)
        else:
            print("\n✅ No reboot required")

    # ===========================
    # PUBLIC ENTRY
    # ===========================
    def initialize(self):
        print("\n===== HARDWARE INIT =====\n")

        self._enable_spi()
        self._enable_i2c()
        self._enable_canfd()

        self._handle_reboot()

        print("\n--- CAN FD Bring-up ---")
        self._bringup_canfd()

        print("\n===== DONE =====\n")


class ssh_key_setup:

    @staticmethod
    def run_cmd(cmd):
        return subprocess.run(
            cmd,
            shell=True,
            capture_output=True,
            text=True
        )

    @staticmethod
    def ensure_openssh():
        logging.info("Checking openssh-client...")

        result = ssh_key_setup.run_cmd("which ssh-agent")

        if result.returncode != 0:
            logging.info("Installing openssh-client...")
            subprocess.run(
                "sudo apt update && sudo apt install -y openssh-client",
                shell=True,
                check=True
            )
        else:
            logging.info("openssh-client already installed.")

    @staticmethod
    def ensure_ssh_agent():

        if "SSH_AUTH_SOCK" in os.environ:
            logging.info("ssh-agent already running.")
            return

        logging.info("Starting ssh-agent...")

        agent = subprocess.run(
            ["ssh-agent", "-s"],
            capture_output=True,
            text=True,
            check=True
        )

        for line in agent.stdout.splitlines():

            if "=" in line and ";" in line:

                key, value = line.split(";", 1)[0].split("=", 1)
                os.environ[key] = value

        logging.info("ssh-agent started successfully.")

    @staticmethod
    def ensure_keys(ssh_dir, private_key_content, public_key_content):

        ssh_dir = os.path.expanduser(ssh_dir)

        os.makedirs(ssh_dir, mode=0o700, exist_ok=True)

        private_key_path = os.path.join(
            ssh_dir,
            "diagtestpi_bitbucket"
        )

        public_key_path = private_key_path + ".pub"

        logging.info("Writing private key...")

        with open(private_key_path, "w") as f:
            f.write(private_key_content.strip() + "\n")

        os.chmod(private_key_path, 0o600)

        logging.info("Writing public key...")

        with open(public_key_path, "w") as f:
            f.write(public_key_content.strip() + "\n")

        os.chmod(public_key_path, 0o644)

        logging.info("Validating private key...")

        result = subprocess.run(
            ["ssh-keygen", "-lf", private_key_path],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            raise RuntimeError(
                "Invalid private key:\n" + result.stderr
            )

        logging.info("Private key validated successfully.")

        return private_key_path

    @staticmethod
    def add_key_to_agent(private_key_path):

        logging.info("Checking existing keys in ssh-agent...")

        result = subprocess.run(
            ["ssh-add", "-l"],
            capture_output=True,
            text=True
        )

        if private_key_path in result.stdout:
            logging.info("Key already present in ssh-agent.")
            return

        logging.info("Adding key to ssh-agent...")

        result = subprocess.run(
            ["ssh-add", private_key_path],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            raise RuntimeError(
                "Failed to add SSH key:\n" + result.stderr
            )

        logging.info("SSH key added successfully.")

    @staticmethod
    def ensure_known_host():
        ssh_dir = os.path.expanduser("~/.ssh")
        known_hosts = os.path.join(ssh_dir, "known_hosts")

        os.makedirs(ssh_dir, mode=0o700, exist_ok=True)

        if not os.path.exists(known_hosts):
            open(known_hosts, "a").close()
            os.chmod(known_hosts, 0o644)

        # Check whether bitbucket.org is already present
        result = subprocess.run(
            ["ssh-keygen", "-F", "bitbucket.org", "-f", known_hosts],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            logging.info("bitbucket.org already exists in known_hosts.")
            return

        logging.info("Adding bitbucket.org to known_hosts...")

        result = subprocess.run(
            ["ssh-keyscan", "-H", "bitbucket.org"],
            capture_output=True,
            text=True
        )

        if result.returncode != 0 or not result.stdout.strip():
            raise RuntimeError(
                "Failed to retrieve Bitbucket host key:\n" + result.stderr
            )

        with open(known_hosts, "a") as f:
            f.write(result.stdout)

        logging.info("bitbucket.org added to known_hosts successfully.")

    @staticmethod
    def configure_git_identity():

        logging.info("Checking Git identity...")

        name_result = subprocess.run(
            ["git", "config", "--global", "user.name"],
            capture_output=True,
            text=True
        )

        email_result = subprocess.run(
            ["git", "config", "--global", "user.email"],
            capture_output=True,
            text=True
        )

        user_name = name_result.stdout.strip()
        user_email = email_result.stdout.strip()

        # Both are already configured
        if user_name and user_email:
            logging.info(
                "Git identity already configured: %s <%s>",
                user_name,
                user_email
            )
            return

        # Ask only for missing details
        if not user_name:
            user_name = input("Enter Git user name: ").strip()

        if not user_email:
            user_email = input("Enter Git email: ").strip()

        if not user_name or not user_email:
            raise RuntimeError("Git user name and email cannot be empty.")

        subprocess.run(
            ["git", "config", "--global", "user.name", user_name],
            check=True
        )

        subprocess.run(
            ["git", "config", "--global", "user.email", user_email],
            check=True
        )

        logging.info(
            "Git identity configured: %s <%s>",
            user_name,
            user_email
        )

    @staticmethod
    def setup_ssh():
        """Configure SSH without embedding private credentials in source code.

        Set DTP_BITBUCKET_PRIVATE_KEY and DTP_BITBUCKET_PUBLIC_KEY to the
        key contents, or set DTP_BITBUCKET_PRIVATE_KEY_FILE and
        DTP_BITBUCKET_PUBLIC_KEY_FILE to provision from files. If an existing
        diagtestpi_bitbucket key is already installed, it is reused.
        """
        ssh_dir = os.path.expanduser("~/.ssh")
        private_path = os.path.join(ssh_dir, "diagtestpi_bitbucket")
        # public_path = private_path + ".pub"

        ssh_key_setup.ensure_openssh()
        ssh_key_setup.ensure_ssh_agent()
        ssh_key_setup.ensure_known_host()

        private_content = os.environ.get("DTP_BITBUCKET_PRIVATE_KEY")
        public_content = os.environ.get("DTP_BITBUCKET_PUBLIC_KEY")
        private_file = os.environ.get("DTP_BITBUCKET_PRIVATE_KEY_FILE")
        public_file = os.environ.get("DTP_BITBUCKET_PUBLIC_KEY_FILE")

        if private_file and os.path.exists(private_file):
            with open(private_file, "r", encoding="utf-8") as file:
                private_content = file.read()
        if public_file and os.path.exists(public_file):
            with open(public_file, "r", encoding="utf-8") as file:
                public_content = file.read()

        if private_content and public_content:
            private_path = ssh_key_setup.ensure_keys(
                "~/.ssh", private_content, public_content
            )
        elif not os.path.exists(private_path):
            raise RuntimeError(
                "Bitbucket SSH key is not provisioned. Set "
                "DTP_BITBUCKET_PRIVATE_KEY_FILE and "
                "DTP_BITBUCKET_PUBLIC_KEY_FILE (or the corresponding "
                "environment variables)."
            )

        ssh_key_setup.add_key_to_agent(private_path)
        ssh_key_setup.configure_git_identity()
        logging.info("SSH setup completed successfully.")


class ServiceInstaller:

    @staticmethod
    def install():

        home = os.path.expanduser("~")
        service_dir = os.path.join(home, ".config", "systemd", "user")
        os.makedirs(service_dir, exist_ok=True)

        service_path = os.path.join(service_dir, "uds.service")

        # Get executable path
        if getattr(sys, "frozen", False):
            exe_path = os.path.realpath(sys.executable)
        else:
            exe_path = os.path.realpath(sys.argv[0])

        working_dir = os.path.dirname(exe_path)
        uid = os.getuid()  # type: ignore[attr-defined]
        username = pwd.getpwuid(uid).pw_name  # type: ignore[attr-defined]

        service_text = f"""[Unit]
Description=UDS Diagnostics
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory={working_dir}
ExecStart={exe_path}

Restart=always
RestartSec=5

Environment=PYTHONUNBUFFERED=1
Environment=XDG_RUNTIME_DIR=/run/user/{uid}
Environment=DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/{uid}/bus

[Install]
WantedBy=default.target
"""

        try:
            # Only write the service if it's new or has changed
            write_service = True

            if os.path.exists(service_path):
                with open(service_path, "r") as f:
                    if f.read() == service_text:
                        write_service = False

            if write_service:
                logging.info("Installing/Updating uds.service...")

                with open(service_path, "w") as f:
                    f.write(service_text)

                subprocess.run(
                    ["systemctl", "--user", "daemon-reload"],
                    check=True
                )

                subprocess.run(
                    ["systemctl", "--user", "enable", "uds.service"],
                    check=True
                )

                logging.info("uds.service installed successfully.")
            else:
                logging.info("uds.service already up-to-date.")

            # Enable linger (ignore failure)
            result = subprocess.run(
                ["sudo", "loginctl", "enable-linger", username],
                capture_output=True,
                text=True
            )

            if result.returncode == 0:
                logging.info("User lingering enabled.")
            else:
                logging.warning(
                    f"Could not enable lingering: {result.stderr.strip()}"
                )

        except Exception as e:
            logging.error(f"Service installation failed: {e}")


class SystemHandler(ABC):
    @abstractmethod
    def initialize(self):
        raise NotImplementedError


class RaspberryPiSystemHandler(SystemHandler):
    def __init__(self):
        self.interface = interface()

    def initialize(self):
        self.interface.initialize()

    def setup_ssh(self):
        ssh_key_setup.setup_ssh()

    def install_service(self):
        ServiceInstaller.install()
