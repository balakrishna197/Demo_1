#!/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

"$PROJECT_DIR/build_on_pi.sh"
"$PROJECT_DIR/run_on_pi.sh"
