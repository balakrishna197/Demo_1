# DTP-CAN v6.2.1 Raspberry Pi Build

## Why the previous build failed

Debian/Raspberry Pi OS can mark the system Python installation as an
`EXTERNALLY-MANAGED` environment (PEP 668). Therefore this is unsafe:

```bash
python3 -m pip install -r requirements.txt
```

The build script now creates `.venv` and installs everything inside it.

## First-time Raspberry Pi setup

If `python3 -m venv` is unavailable:

```bash
sudo apt update
sudo apt install -y python3-venv python3-full
```

Then:

```bash
chmod +x build_on_pi.sh run_on_pi.sh build_and_run.sh clean_build.sh
./build_on_pi.sh
```

Run:

```bash
./run_on_pi.sh
```

Or:

```bash
./build_and_run.sh
```

## What the build script does

1. Validates `main.py`, `drivers/`, `config/config.json`, and requirements.
2. Checks Python venv support.
3. Creates `.venv/`.
4. Updates pip/setuptools/wheel inside `.venv`.
5. Installs requirements inside `.venv`.
6. Removes old `build/` and `dist/`.
7. Runs PyInstaller using the venv Python.
8. Collects `drivers`, `isotp`, and `udsoncan` submodules.
9. Creates `dist/uds_diagnostics`.
10. Leaves `config/config.json` outside the executable.

## Final runtime layout

```text
project/
├── main.py
├── config/
│   └── config.json
├── drivers/
├── supportfiles/
├── output/
├── .venv/
└── dist/
    └── uds_diagnostics
```

Do not use `os.getcwd()` to locate configuration or runtime folders.
Use `ApplicationPaths`.
