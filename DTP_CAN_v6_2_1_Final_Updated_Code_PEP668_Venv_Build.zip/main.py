"""DTP-CAN v6.2.1 composition root."""

from drivers.config import ApplicationPaths, ConfigLoader


def main() -> None:
    paths = ApplicationPaths()
    paths.create_runtime_directories()

    config = ConfigLoader(paths).load(paths.config_file)

    print("DTP-CAN v6.2.1 - modular application")
    print(f"Project root : {paths.project_root}")
    print(f"Config file  : {paths.config_file}")
    print("Configuration loaded successfully.")

    # Wire the remaining production services here during migration:
    # - ConnectivityService
    # - GitRepository
    # - TestcaseRepository
    # - CAN interface/logger
    # - DiagnosticExecutor
    # - ReportManager
    # - UI router


if __name__ == "__main__":
    main()
