#!/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

rm -rf \
    "$PROJECT_DIR/build" \
    "$PROJECT_DIR/dist" \
    "$PROJECT_DIR/__pycache__"

find "$PROJECT_DIR/drivers" -type d -name "__pycache__" -prune -exec rm -rf {} +

echo "DTP-CAN build artifacts cleaned."
