# DTP-CAN Runtime Path Management

Expected layout:

```text
project/
├── main.py
├── config/
│   └── config.json
├── drivers/
├── supportfiles/
├── output/
│   ├── can_logs/
│   ├── html_reports/
│   └── logs/
└── dist/
    └── uds_diagnostics
```

`drivers/config/paths.py` resolves the project root in both modes:

- Python source mode: based on `__file__`
- PyInstaller mode: based on `sys.executable`

Do not use `os.getcwd()` for application resources.

Use:

```python
from drivers.config import ApplicationPaths

paths = ApplicationPaths()
paths.config_file
paths.output_dir
paths.can_logs_dir
paths.html_reports_dir
paths.logs_dir
```

The external `config/config.json` is intentionally not embedded in the executable so it can be changed without rebuilding.
