# DTP-CAN v6.2.1 - Modular Refactoring Scaffold

## Runtime compatibility

The refactored application intentionally keeps the previous project convention:

- `main.py` remains at the project root.
- `drivers/` remains the Python package boundary.
- Functional modules live below `drivers/`.
- `build_on_pi.sh` builds the PyInstaller executable.
- `dist/uds_diagnostics` is the generated executable.
- `run_on_pi.sh` executes the built application.
- `build_and_run.sh` performs both operations.

## Module layout

```text
drivers/
  application/
  config/
  network/       # Wi-Fi + UDP
  repository/    # Git
  testcase/      # testcase parsing/models
  diagnostic/    # UDS/ISO-TP/execution/verification
  can/           # CAN interface/logger
  reporting/     # ASC/reporting
  ui/            # terminal/OLED/buttons
  system/        # SSH/USB/service
```

## Raspberry Pi build

```bash
chmod +x build_on_pi.sh run_on_pi.sh build_and_run.sh
./build_on_pi.sh
./run_on_pi.sh
```

Or:

```bash
./build_and_run.sh
```

The build script retains the previous Raspberry Pi dependencies and adds
`--collect-submodules drivers` so all modular driver packages are available to
PyInstaller.

## Important migration note

This is an architecture/refactoring scaffold. The existing v6.2.1 production
implementation must be moved into the corresponding modules incrementally.
Do not replace the working UDS/CAN transport behavior until request/response,
ISO-TP timing, CAN IDs, security access, logging and report outputs have been
validated against the v6.2.1 baseline.
