"""shared module."""
