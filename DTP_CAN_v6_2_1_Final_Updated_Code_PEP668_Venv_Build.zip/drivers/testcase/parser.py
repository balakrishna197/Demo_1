import csv
from pathlib import Path
from .models import TestcaseStep

class TestcaseParser:
    """Converts CSV/TXT testcase rows into domain objects."""
    def load(self, path: str | Path) -> list[TestcaseStep]:
        result=[]
        with Path(path).open(newline="", encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                request=bytes.fromhex((row.get("Request") or row.get("request") or "").replace(" ",""))
                expected_text=(row.get("Expected Response") or row.get("expected_response") or "").strip()
                expected=bytes.fromhex(expected_text.replace(" ","")) if expected_text else None
                result.append(TestcaseStep(
                    testcase_id=row.get("Testcase ID") or row.get("Testcase") or row.get("TC_ID") or "UNKNOWN",
                    description=row.get("Description") or row.get("description") or "",
                    request=request, expected_response=expected,
                    addressing=row.get("Addressing") or "physical"))
        return result
