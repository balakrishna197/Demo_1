from dataclasses import dataclass

@dataclass(frozen=True)
class TestcaseStep:
    testcase_id: str
    description: str
    request: bytes
    expected_response: bytes | None = None
    addressing: str = "physical"
