from dataclasses import dataclass, field
from typing import Any

@dataclass(frozen=True)
class NetworkConfig:
    wifi_enabled: bool = True
    saved_ssid: str | None = None
    udp_ip: str | None = None
    udp_port: int | None = None
    udp_timeout: float = 2.0
    expected_key_length: int = 0

@dataclass(frozen=True)
class CanConfig:
    channel: str = "can0"
    interface: str = "socketcan"
    bitrate: int = 500000
    data_bitrate: int | None = None
    fd: bool = False

@dataclass(frozen=True)
class AppConfig:
    raw: dict[str, Any] = field(default_factory=dict)
    network: NetworkConfig = field(default_factory=NetworkConfig)
    can: CanConfig = field(default_factory=CanConfig)
    testcase_path: str | None = None
    report_dir: str = "output/html_reports"
