class ServiceInstaller:
    def install(self):
        raise NotImplementedError("Wrap current install_service.py implementation")
