class SshSetup:
    def setup(self):
        """Move existing ssh_key_setup() implementation here."""
        raise NotImplementedError
