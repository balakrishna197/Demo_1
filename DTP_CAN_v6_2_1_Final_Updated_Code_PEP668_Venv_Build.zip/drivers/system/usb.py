class UsbTransfer:
    def copy(self, source, destination):
        raise NotImplementedError("Wrap current transfer_file.py implementation")
