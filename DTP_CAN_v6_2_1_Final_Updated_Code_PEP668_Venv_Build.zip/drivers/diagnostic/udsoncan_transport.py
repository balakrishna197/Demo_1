"""Optional real UDS/ISO-TP adapter. Keep third-party imports here, not in application services."""
try:
    import isotp
    import can
    from udsoncan.client import Client
    from udsoncan.connections import PythonIsoTpConnection
except ImportError:  # allows unit tests/scaffold use without Pi packages
    isotp=can=Client=PythonIsoTpConnection=None

class UdsoncanTransport:
    def __init__(self, bus_config: dict, isotp_config: dict, address_config: dict):
        self.bus_config=bus_config; self.isotp_config=isotp_config; self.address_config=address_config
        self._client=None; self._bus=None; self._connection=None
    def connect(self):
        if any(x is None for x in (isotp,can,Client,PythonIsoTpConnection)):
            raise RuntimeError("Install python-can, isotp and udsoncan for real ECU execution")
        # Move the existing UDSClient._create_connection logic here during migration.
        raise NotImplementedError("Wire existing v6.2.1 CAN/ISO-TP connection creation here")
    def send(self, request: bytes, addressing: str="physical") -> bytes:
        raise NotImplementedError("Move existing _send_request_and_wait logic here")
    def close(self):
        if self._connection and hasattr(self._connection,"close"): self._connection.close()
        if self._bus and hasattr(self._bus,"shutdown"): self._bus.shutdown()
