"""diagnostic module."""
