from dataclasses import dataclass
from datetime import datetime

@dataclass(frozen=True)
class DiagnosticResult:
    testcase_id: str
    status: str
    request: bytes
    response: bytes
    reason: str = ""

@dataclass
class TestRunResult:
    results: list[DiagnosticResult]
    started_at: datetime
    finished_at: datetime | None = None
    can_log_path: str | None = None
