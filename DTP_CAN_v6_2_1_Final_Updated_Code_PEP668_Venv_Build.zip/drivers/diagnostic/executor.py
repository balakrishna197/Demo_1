from datetime import datetime
from .models import DiagnosticResult, TestRunResult
from .ports import DiagnosticTransport, ResponseVerifier
from ..testcase.models import TestcaseStep

class TestcaseExecutor:
    """Application service: controls testcase execution but knows no CAN/UDP implementation."""
    def __init__(self, transport: DiagnosticTransport, verifier: ResponseVerifier):
        self.transport=transport; self.verifier=verifier
    def run(self, steps: list[TestcaseStep]) -> TestRunResult:
        started=datetime.now(); results=[]
        self.transport.connect()
        try:
            for step in steps:
                response=self.transport.send(step.request, step.addressing)
                ok,reason=self.verifier.verify(step,response)
                results.append(DiagnosticResult(step.testcase_id,"PASS" if ok else "FAIL",step.request,response,reason))
        finally:
            self.transport.close()
        return TestRunResult(results, started, datetime.now())
