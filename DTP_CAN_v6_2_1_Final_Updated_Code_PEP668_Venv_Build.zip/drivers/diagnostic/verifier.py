from ..testcase.models import TestcaseStep

class DefaultResponseVerifier:
    def verify(self, step: TestcaseStep, response: bytes) -> tuple[bool,str]:
        if step.expected_response is None: return True, "No expected response"
        if response == step.expected_response: return True, "Matched"
        return False, f"Expected {step.expected_response.hex(' ')}, got {response.hex(' ')}"
