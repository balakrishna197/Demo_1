from ..reporting.models import ReportContext

class RunDiagnosticUseCase:
    def __init__(self, ui, network, testcase_repo, diagnostic, reporting):
        self.ui=ui; self.network=network; self.testcase_repo=testcase_repo
        self.diagnostic=diagnostic; self.reporting=reporting

    def execute(self, testcase_path, asc_path=None, json_path=None):
        self.ui.show("Loading testcase...")
        steps=self.testcase_repo.load(testcase_path)
        self.ui.show(f"Executing {len(steps)} testcase steps...")
        result=self.diagnostic.run(steps)
        result.can_log_path=asc_path
        report=self.reporting.generate(ReportContext(result,asc_path,testcase_path,json_path))
        self.ui.show(f"Report: {report.html_path}")
        return result, report
