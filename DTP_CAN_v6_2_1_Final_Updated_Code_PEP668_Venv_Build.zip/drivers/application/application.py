from .use_cases import RunDiagnosticUseCase

class Application:
    """Thin orchestration layer. It knows workflow, not infrastructure details."""
    def __init__(self, ui, network, repository, testcase_repo, diagnostic, reporting, can_interface=None):
        self.ui=ui; self.network=network; self.repository=repository
        self.testcase_repo=testcase_repo; self.diagnostic=diagnostic; self.reporting=reporting
        self.can_interface=can_interface

    def run_testcase(self, testcase_path: str, asc_path: str | None=None, json_path: str | None=None):
        return RunDiagnosticUseCase(
            ui=self.ui, network=self.network, testcase_repo=self.testcase_repo,
            diagnostic=self.diagnostic, reporting=self.reporting
        ).execute(testcase_path, asc_path, json_path)
