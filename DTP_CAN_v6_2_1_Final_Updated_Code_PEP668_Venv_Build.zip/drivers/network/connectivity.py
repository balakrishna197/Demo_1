from dataclasses import dataclass
from .wifi import WiFiManager
from .udp_client import UdpSeedKeyClient

@dataclass(frozen=True)
class ConnectivityStatus:
    wifi_ok: bool
    udp_ok: bool | None

class ConnectivityService:
    def __init__(self, wifi: WiFiManager, udp: UdpSeedKeyClient | None=None):
        self.wifi=wifi; self.udp=udp
    def check(self, ssid: str | None=None) -> ConnectivityStatus:
        wifi_ok=self.wifi.is_connected(ssid)
        udp_ok=None if self.udp is None else self.udp.check_server()
        return ConnectivityStatus(wifi_ok, udp_ok)
