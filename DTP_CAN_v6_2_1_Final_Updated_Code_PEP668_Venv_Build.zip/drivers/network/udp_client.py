import socket
from dataclasses import dataclass

class UdpServerError(RuntimeError): pass

@dataclass(frozen=True)
class SeedKeyResult:
    key: bytes

class UdpSeedKeyClient:
    """Owns only UDP seed/key communication."""
    def __init__(self, host: str, port: int, timeout: float=2.0, expected_key_length: int=0):
        self.host=host; self.port=port; self.timeout=timeout; self.expected_key_length=expected_key_length

    def check_server(self, probe: bytes=b"1234567890abcdef") -> bool:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.settimeout(self.timeout); sock.sendto(probe,(self.host,self.port)); data,_=sock.recvfrom(4096)
                return bool(data)
        except OSError:
            return False

    def request_key(self, seed: bytes) -> SeedKeyResult:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.settimeout(self.timeout); sock.sendto(seed,(self.host,self.port)); key,_=sock.recvfrom(4096)
        except OSError as exc:
            raise UdpServerError(str(exc)) from exc
        if not key: raise UdpServerError("Empty key received")
        if self.expected_key_length and len(key) != self.expected_key_length:
            raise UdpServerError(f"Unexpected key length: {len(key)}")
        return SeedKeyResult(key)
