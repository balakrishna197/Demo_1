import subprocess
import threading
import time
from dataclasses import dataclass
from collections.abc import Callable

@dataclass(frozen=True)
class WifiNetwork:
    ssid: str

class WiFiError(RuntimeError): pass

class WiFiManager:
    """Owns Linux NetworkManager/nmcli details. No UI logic belongs here."""
    def __init__(self, command_runner=subprocess.run, poll_seconds: float=5.0):
        self._run=command_runner
        self._poll_seconds=poll_seconds
        self._stop=threading.Event()
        self._thread=None

    def scan(self) -> list[WifiNetwork]:
        r=self._run(["nmcli","-t","-f","SSID","dev","wifi"], capture_output=True, text=True, check=False)
        if r.returncode != 0: raise WiFiError(r.stderr.strip() or "Wi-Fi scan failed")
        seen=[]
        for line in r.stdout.splitlines():
            ssid=line.strip()
            if ssid and ssid not in seen: seen.append(ssid)
        return [WifiNetwork(x) for x in seen]

    def connect(self, ssid: str, password: str) -> bool:
        r=self._run(["nmcli","dev","wifi","connect",ssid,"password",password], capture_output=True, text=True, check=False)
        return r.returncode == 0

    def connect_saved(self, ssid: str) -> bool:
        r=self._run(["nmcli","connection","up",ssid], capture_output=True, text=True, check=False)
        return r.returncode == 0

    def is_connected(self, ssid: str | None=None) -> bool:
        r=self._run(["nmcli","-t","-f","ACTIVE,SSID","dev","wifi"], capture_output=True, text=True, check=False)
        if r.returncode != 0: return False
        for line in r.stdout.splitlines():
            active,current=(line.split(":",1)+[""])[:2]
            if active == "yes" and (ssid is None or current == ssid): return True
        return False

    def disconnect(self, ssid: str) -> bool:
        r=self._run(["nmcli","connection","down",ssid], capture_output=True, text=True, check=False)
        return r.returncode == 0

    def start_monitor(self, on_change: Callable[[bool],None], ssid: str | None=None) -> None:
        self._stop.clear()
        def loop():
            previous=None
            while not self._stop.is_set():
                state=self.is_connected(ssid)
                if state != previous:
                    previous=state; on_change(state)
                self._stop.wait(self._poll_seconds)
        self._thread=threading.Thread(target=loop, daemon=True, name="wifi-monitor")
        self._thread.start()

    def stop_monitor(self) -> None:
        self._stop.set()
        if self._thread and self._thread.is_alive(): self._thread.join(timeout=2)
