from dataclasses import dataclass
from pathlib import Path
from ..diagnostic.models import TestRunResult

@dataclass(frozen=True)
class ReportContext:
    test_run: TestRunResult
    asc_path: str | None
    testcase_path: str | None
    json_path: str | None
    branch_name: str | None = None
    branch_url: str | None = None

@dataclass(frozen=True)
class ReportResult:
    html_path: str
