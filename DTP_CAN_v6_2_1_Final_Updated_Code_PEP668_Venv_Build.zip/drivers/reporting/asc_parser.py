from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class CanMessage:
    timestamp: float
    direction: str
    can_id: str
    data: bytes

class AscParser:
    """Pure-ish ASC parsing boundary. Expand with current parse_line/parse_data_bytes logic."""
    def parse(self, path: str | Path) -> list[CanMessage]:
        messages=[]
        for line in Path(path).read_text(encoding="utf-8",errors="ignore").splitlines():
            parts=line.split()
            if len(parts) < 4: continue
            try: ts=float(parts[0])
            except ValueError: continue
            direction="Tx" if "Tx" in parts else "Rx" if "Rx" in parts else ""
            ids=[p for p in parts if p.startswith("0x") or all(c in "0123456789ABCDEFabcdef" for c in p) and len(p) in (3,8)]
            if not ids: continue
            messages.append(CanMessage(ts,direction,ids[0],b""))
        return messages
