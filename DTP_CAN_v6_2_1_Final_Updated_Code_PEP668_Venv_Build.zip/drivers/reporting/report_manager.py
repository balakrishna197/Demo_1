from html import escape
from pathlib import Path
from .models import ReportContext, ReportResult

class ReportManager:
    """Application-facing reporting service. Parser and renderer are injected."""
    def __init__(self, parser, renderer): self.parser=parser; self.renderer=renderer
    def generate(self, context: ReportContext) -> ReportResult:
        messages=self.parser.parse(context.asc_path) if context.asc_path else []
        return self.renderer.render(context,messages)

class HtmlReportRenderer:
    def render(self, context, messages) -> ReportResult:
        out=Path(context.test_run.can_log_path or "output")
        out=out.parent / (out.stem + ".html")
        out.parent.mkdir(parents=True,exist_ok=True)
        rows="".join(f"<tr><td>{escape(r.testcase_id)}</td><td>{r.status}</td><td>{escape(r.reason)}</td></tr>" for r in context.test_run.results)
        html=f"<html><body><h1>DTP-CAN Test Report</h1><table><tr><th>Testcase</th><th>Status</th><th>Reason</th></tr>{rows}</table></body></html>"
        out.write_text(html,encoding="utf-8")
        return ReportResult(str(out))
