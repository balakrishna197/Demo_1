class ButtonInput:
    def read(self): return None
