class TerminalUI:
    def show(self, message: str) -> None: print(message)
    def error(self, message: str) -> None: print(f"ERROR: {message}")
