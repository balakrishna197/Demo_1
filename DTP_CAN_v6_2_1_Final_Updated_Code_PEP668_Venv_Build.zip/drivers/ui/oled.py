class OledUI:
    def show(self, message: str) -> None: pass
