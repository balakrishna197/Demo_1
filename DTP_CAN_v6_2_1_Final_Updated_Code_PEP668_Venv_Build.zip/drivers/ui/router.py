class UIRouter:
    def __init__(self, displays): self.displays=displays
    def show(self, message):
        for display in self.displays: display.show(message)
