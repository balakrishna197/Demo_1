import subprocess

class CanInterfaceManager:
    """Owns Linux SocketCAN setup only."""
    def __init__(self, runner=subprocess.run): self.runner=runner
    def bring_up(self, channel="can0", bitrate=500000, fd=False, data_bitrate=None):
        self.runner(["ip","link","set",channel,"down"], capture_output=True, text=True, check=False)
        cmd=["ip","link","set",channel,"up","type","can","bitrate",str(bitrate)]
        if fd and data_bitrate: cmd += ["dbitrate",str(data_bitrate),"fd","on"]
        r=self.runner(cmd,capture_output=True,text=True,check=False)
        if r.returncode != 0: raise RuntimeError(r.stderr.strip() or "CAN bring-up failed")
