from pathlib import Path
from datetime import datetime

class CanLogger:
    """Port/adapter boundary for CAN logging. Replace implementation with current CANLogger."""
    def start(self, output_path: str | Path) -> None:
        raise NotImplementedError("Inject the existing python-can CANLogger adapter here")
    def stop(self) -> None: raise NotImplementedError
    def path(self) -> str | None: raise NotImplementedError
