"""DTP-CAN modular architecture reference implementation."""
