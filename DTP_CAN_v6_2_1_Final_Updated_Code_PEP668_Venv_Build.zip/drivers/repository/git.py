import subprocess
from dataclasses import dataclass

@dataclass(frozen=True)
class RepositorySelection:
    branch: str
    commit: str | None
    testcase_path: str | None
    config_path: str | None

class GitRepository:
    """Git CLI adapter. Business selection logic stays outside this class."""
    def __init__(self, base_dir: str): self.base_dir=base_dir
    def list_remote_branches(self):
        r=subprocess.run(["git","-C",self.base_dir,"branch","-r"],capture_output=True,text=True,check=False)
        if r.returncode: raise RuntimeError(r.stderr.strip() or "Git branch listing failed")
        return [x.strip() for x in r.stdout.splitlines() if x.strip()]
    def current_commit(self):
        r=subprocess.run(["git","-C",self.base_dir,"rev-parse","HEAD"],capture_output=True,text=True,check=False)
        return r.stdout.strip() if r.returncode==0 else None
