#!/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXECUTABLE="$PROJECT_DIR/dist/uds_diagnostics"
CONFIG="$PROJECT_DIR/config/config.json"

if [[ ! -f "$CONFIG" ]]; then
    echo "ERROR: config file not found:"
    echo "  $CONFIG"
    exit 1
fi

if [[ ! -x "$EXECUTABLE" ]]; then
    echo "ERROR: executable not found:"
    echo "  $EXECUTABLE"
    echo
    echo "Build it first with:"
    echo "  ./build_on_pi.sh"
    exit 1
fi

cd "$PROJECT_DIR"

echo "Starting DTP-CAN v6.2.1..."
echo "Project root: $PROJECT_DIR"
echo "Config      : $CONFIG"
echo

exec "$EXECUTABLE"
