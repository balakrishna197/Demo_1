#!/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON="$PROJECT_DIR/.venv/bin/python"

if [[ ! -x "$PYTHON" ]]; then
    echo "ERROR: .venv does not exist. Run ./build_on_pi.sh first."
    exit 1
fi

cd "$PROJECT_DIR"

echo "Running source smoke test..."
"$PYTHON" main.py

echo
echo "Source smoke test passed."

if [[ -x "$PROJECT_DIR/dist/uds_diagnostics" ]]; then
    echo
    echo "Running executable smoke test..."
    "$PROJECT_DIR/dist/uds_diagnostics"
    echo
    echo "Executable smoke test passed."
else
    echo
    echo "Executable not present; only source smoke test was run."
fi
