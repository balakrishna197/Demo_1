#!/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$PROJECT_DIR/.venv"
PYTHON_BIN="python3"

echo "============================================================"
echo " DTP-CAN v6.2.1 - Raspberry Pi Build"
echo "============================================================"
echo "Project directory: $PROJECT_DIR"
echo

cd "$PROJECT_DIR"

# ------------------------------------------------------------
# 1. Validate source tree
# ------------------------------------------------------------
if [[ ! -f "$PROJECT_DIR/main.py" ]]; then
    echo "ERROR: main.py not found."
    exit 1
fi

if [[ ! -d "$PROJECT_DIR/drivers" ]]; then
    echo "ERROR: drivers/ package not found."
    exit 1
fi

if [[ ! -f "$PROJECT_DIR/config/config.json" ]]; then
    echo "ERROR: config/config.json not found."
    exit 1
fi

if [[ ! -f "$PROJECT_DIR/requirements.txt" ]]; then
    echo "ERROR: requirements.txt not found."
    exit 1
fi

# ------------------------------------------------------------
# 2. Verify that Python venv support is installed
# ------------------------------------------------------------
if ! "$PYTHON_BIN" -m venv --help >/dev/null 2>&1; then
    echo "ERROR: Python virtual-environment support is not installed."
    echo
    echo "On Debian/Raspberry Pi OS, run:"
    echo "  sudo apt update"
    echo "  sudo apt install -y python3-venv python3-full"
    echo
    echo "Then run this script again."
    exit 1
fi

# ------------------------------------------------------------
# 3. Create isolated virtual environment
#    This avoids PEP 668 'externally-managed-environment'.
# ------------------------------------------------------------
if [[ ! -x "$VENV_DIR/bin/python" ]]; then
    echo "[1/6] Creating virtual environment..."
    "$PYTHON_BIN" -m venv "$VENV_DIR"
else
    echo "[1/6] Reusing virtual environment: $VENV_DIR"
fi

VENV_PYTHON="$VENV_DIR/bin/python"
VENV_PIP="$VENV_DIR/bin/pip"

echo
echo "[2/6] Python version:"
"$VENV_PYTHON" --version

# ------------------------------------------------------------
# 4. Upgrade packaging tools INSIDE the venv only
# ------------------------------------------------------------
echo
echo "[3/6] Updating pip/setuptools/wheel inside venv..."
"$VENV_PIP" install --upgrade pip setuptools wheel

# ------------------------------------------------------------
# 5. Install application dependencies INSIDE the venv
# ------------------------------------------------------------
echo
echo "[4/6] Installing requirements..."
"$VENV_PIP" install -r "$PROJECT_DIR/requirements.txt"

# ------------------------------------------------------------
# 6. Clean and build PyInstaller executable
# ------------------------------------------------------------
echo
echo "[5/6] Cleaning previous PyInstaller output..."
rm -rf "$PROJECT_DIR/build" "$PROJECT_DIR/dist"
mkdir -p "$PROJECT_DIR/dist"

echo
echo "[6/6] Building executable..."
"$VENV_PYTHON" -m PyInstaller \
    --clean \
    --noconfirm \
    --onefile \
    --name uds_diagnostics \
    --collect-submodules drivers \
    --collect-submodules isotp \
    --collect-submodules udsoncan \
    "$PROJECT_DIR/main.py"

# ------------------------------------------------------------
# Final validation
# ------------------------------------------------------------
EXECUTABLE="$PROJECT_DIR/dist/uds_diagnostics"

if [[ ! -f "$EXECUTABLE" ]]; then
    echo
    echo "ERROR: PyInstaller finished but executable was not created."
    exit 1
fi

chmod +x "$EXECUTABLE"

echo
echo "============================================================"
echo " BUILD SUCCESSFUL"
echo "============================================================"
echo "Executable:"
echo "  $EXECUTABLE"
echo
echo "Configuration:"
echo "  $PROJECT_DIR/config/config.json"
echo
echo "Run:"
echo "  ./run_on_pi.sh"
echo
echo "Or directly:"
echo "  ./dist/uds_diagnostics"
echo "============================================================"
