from pathlib import Path
import sys


class PathConfig:
    """Centralized application path management.

    All application paths are owned by this object instead of being stored
    as module-level global variables.
    """

    def __init__(self, base_dir=None):
        self.base_dir = Path(base_dir) if base_dir else self._detect_base_dir()

        self.logs_dir = self.base_dir / "logs"
        self.output_dir = self.base_dir / "output"
        self.can_logs_dir = self.output_dir / "can_logs"
        self.html_reports_dir = self.output_dir / "html_reports"
        self.supportfiles_dir = self.base_dir / "supportfiles"
        self.selected_testcase_file = self.base_dir / "selected_testcase.txt"

    @staticmethod
    def _detect_base_dir():
        if getattr(sys, "frozen", False):
            return Path(sys.executable).resolve().parent
        return Path(__file__).resolve().parent.parent

    def create_directories(self):
        for directory in (
            self.logs_dir,
            self.output_dir,
            self.can_logs_dir,
            self.html_reports_dir,
            self.supportfiles_dir,
        ):
            directory.mkdir(parents=True, exist_ok=True)
