import logging


class AppLogger:
    """Application logging configuration.

    Keeps Python application logging separate from CAN/ASC trace logging.
    """

    def __init__(self, log_file):
        self.log_file = str(log_file)

    def configure(self, level=logging.DEBUG):
        root = logging.getLogger()
        root.setLevel(level)

        # Avoid adding duplicate handlers when USB re-initialization or
        # application reinitialization calls this more than once.
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(message)s"
        )

        file_handler = None
        stream_handler = None

        for handler in root.handlers:
            if isinstance(handler, logging.FileHandler) and getattr(handler, "baseFilename", "") == self.log_file:
                file_handler = handler
            if isinstance(handler, logging.StreamHandler) and not isinstance(handler, logging.FileHandler):
                stream_handler = handler

        if file_handler is None:
            file_handler = logging.FileHandler(self.log_file, mode="w")
            file_handler.setFormatter(formatter)
            root.addHandler(file_handler)

        if stream_handler is None:
            stream_handler = logging.StreamHandler()
            stream_handler.setFormatter(formatter)
            root.addHandler(stream_handler)

        return root
