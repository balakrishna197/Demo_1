class AppConfig:
    """Typed access to the JSON application configuration.

    The raw dictionary remains available through ``raw`` so existing
    configuration-dependent code can be migrated incrementally.
    """

    def __init__(self, raw_config):
        self.raw = raw_config

    @property
    def uds(self):
        return self.raw.get("uds", {})

    @property
    def can(self):
        return self.uds.get("can", {})

    @property
    def isotp(self):
        return self.uds.get("isotp", {})

    @property
    def timing(self):
        return self.uds.get("timing", {})

    @property
    def addressing_modes(self):
        return self.uds.get("addressing_modes", {})

    @property
    def target_ecu(self):
        return self.uds.get("target_ecu", "Unknown ECU")

    @property
    def udp_server(self):
        return self.uds.get("udp_server", {})

    @property
    def gpio(self):
        return self.raw.get("gpio", {})
