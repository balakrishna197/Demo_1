class ApplicationContext:
    """Runtime service container for the DTP-CAN application.

    This object replaces the need for module-level mutable state. It is kept
    deliberately small; long-lived services are added by the application
    during initialization.
    """

    def __init__(self, paths, config=None):
        self.paths = paths
        self.config = config
        self.git = None
        self.uds = None
        self.usb = None
        self.report_manager = None
        self.test_runner = None
