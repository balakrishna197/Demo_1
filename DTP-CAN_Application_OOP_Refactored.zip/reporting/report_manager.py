import os
from drivers.report_generator import generate_report


class ReportManager:
    """Owns report file location and report-generator invocation."""

    def __init__(self, paths):
        self.paths = paths
        self.paths.html_reports_dir.mkdir(parents=True, exist_ok=True)

    def create_report_path(self, base_name, timestamp):
        return str(self.paths.html_reports_dir / f"{base_name}_{timestamp}.html")

    def generate(self, **kwargs):
        report_path = kwargs.pop("output_html_file", None)
        if report_path is None:
            base_name = kwargs.pop("base_name")
            timestamp = kwargs.pop("timestamp")
            report_path = self.create_report_path(base_name, timestamp)

        generate_report(output_html_file=report_path, **kwargs)
        return report_path
