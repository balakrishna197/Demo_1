import json
from pathlib import Path


def load_config(config_path, base_path=None):
    """Load a JSON configuration file using an explicit base path."""
    path = Path(config_path)
    if not path.is_absolute():
        root = Path(base_path) if base_path else Path(__file__).resolve().parent
        path = root / path

    if not path.exists():
        raise FileNotFoundError(f"Configuration file not found:\n{path}")

    try:
        with path.open("r", encoding="utf-8") as file:
            return json.load(file)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"Invalid JSON format in:\n{path}\n\n{exc}"
        ) from exc
    except OSError as exc:
        raise OSError(
            f"Failed to load configuration:\n{path}\n\n{exc}"
        ) from exc


if __name__ == "__main__":
    print(load_config("config.json"))
