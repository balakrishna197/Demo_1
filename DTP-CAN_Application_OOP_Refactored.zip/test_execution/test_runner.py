class TestCaseRunner:
    """Application-level facade for testcase execution.

    The existing UDSClient still owns the detailed UDS service execution so
    behavior is preserved. This facade gives the application a clear boundary
    and is the migration point for extracting individual service handlers.
    """

    def __init__(self, uds_client):
        self.uds_client = uds_client

    def run(self, display, tester_name="N/A"):
        return self.uds_client.run_testcase(display, tester_name=tester_name)

    def read_ecu_information(self, display):
        return self.uds_client.get_ecu_information(display)
