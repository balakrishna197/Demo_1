from application.uds_application import UDSApplication


def main():
    app = UDSApplication()
    app.main_menu()


if __name__ == "__main__":
    main()
