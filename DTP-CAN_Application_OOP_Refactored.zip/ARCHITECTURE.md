# DTP-CAN Application - OOP Refactoring

## Objective

The updated project keeps the existing DTP-CAN behavior while introducing clearer object ownership and reducing module-level/global state.

## Main structure

```text
main.py
  |
  v
UDSApplication
  |
  +-- PathConfig
  +-- AppLogger
  +-- AppConfig
  +-- ApplicationContext
  +-- GitManager
  +-- UDSClient
  |     +-- CANManager
  |     +-- IsoTpConnectionManager
  |     +-- CANLogger
  |     +-- ReportManager
  |
  +-- TestCaseRunner
  +-- USBTransfer
  +-- Hardware/UI services
```

## Responsibilities

### `core/path_config.py`
Owns application paths such as `logs`, `output`, `can_logs`, `html_reports`, `supportfiles`, and `selected_testcase.txt`.

### `core/app_logger.py`
Owns Python application logging configuration. This is separate from CAN/ASC logging.

### `core/app_config.py`
Provides structured access to the JSON configuration while retaining the original dictionary through `raw` for incremental migration.

### `core/application_context.py`
Holds long-lived runtime services. This replaces the need for module-level mutable state.

### `communication/can_manager.py`
Owns creation and cleanup of `python-can` buses.

### `communication/isotp_manager.py`
Owns ISO-TP address, CAN stack, and `PythonIsoTpConnection` creation.

### `reporting/report_manager.py`
Owns HTML report output location and calls `generate_report()`.

### `test_execution/test_runner.py`
Provides the application-level testcase execution boundary. The detailed UDS execution remains in `UDSClient` in this release to minimize behavioral changes.

### `drivers/uds_client.py`
Remains the UDS execution engine, but its infrastructure dependencies are now injected/owned by dedicated classes. CAN/ISO-TP construction and report generation are no longer implemented directly in the UDS communication methods.

## Global-state changes

The former `BASE_DIR`, `LOG_DIR`, and `LOG_FILE` globals were removed from the application startup path. Runtime paths are supplied through `PathConfig`.

`config_loader.load_config()` no longer depends on a module-level `BASE_PATH`; callers can explicitly provide `base_path`.

`USBTransfer` now receives `PathConfig` instead of calculating its own base directory.

## Execution flow

```text
main()
  -> UDSApplication()
  -> PathConfig / AppLogger
  -> initialize_dependencies()
  -> UI + Wi-Fi + Git setup
  -> load selected JSON configuration
  -> create ReportManager
  -> create UDSClient
       -> CANManager
       -> IsoTpConnectionManager
       -> CANLogger
  -> create TestCaseRunner
  -> main_menu()
       -> ECU information
       -> testcase execution
            -> UDSClient
            -> CAN/ISO-TP
            -> ASC CAN log
            -> ReportManager
            -> HTML report
       -> Bitbucket push
       -> shutdown
```

## Migration strategy

The refactoring is intentionally incremental. The large UDS service implementation in `UDSClient.run_testcase()` has not been rewritten into separate service classes in this release. This avoids changing UDS behavior while establishing the OOP boundaries needed for the next stage.
