import can
import logging


class CANManager:
    """Owns creation and cleanup of python-can bus instances."""

    def __init__(self, config):
        self.config = config

    def create_bus(self, can_filters=None, receive_own_messages=False):
        kwargs = {
            "channel": self.config["channel"],
            "bustype": self.config["interface"],
            "can_filters": can_filters,
            "fd": self.config.get("can_fd", True),
        }

        if receive_own_messages:
            try:
                return can.interface.Bus(**kwargs, receive_own_messages=True)
            except TypeError:
                logging.warning(
                    "CAN backend does not support receive_own_messages; using default bus"
                )

        return can.interface.Bus(**kwargs)

    @staticmethod
    def shutdown(bus):
        if bus is not None:
            try:
                bus.shutdown()
            except Exception as exc:
                logging.warning("CAN bus shutdown warning: %s", exc)
