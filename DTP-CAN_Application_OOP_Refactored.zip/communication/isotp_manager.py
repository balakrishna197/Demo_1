import isotp
from udsoncan.connections import PythonIsoTpConnection


class IsoTpConnectionManager:
    """Creates UDS ISO-TP connections without mixing them with UDS service logic."""

    def __init__(self, can_manager, isotp_config):
        self.can_manager = can_manager
        self.isotp_config = isotp_config

    def create_connection(self, addr_cfg, mode_name):
        if not addr_cfg:
            return None

        tx_id = int(addr_cfg["tx_id"], 16)
        rx_id = int(addr_cfg["rx_id"], 16)
        is_extended = addr_cfg.get("is_extended", False)

        address = isotp.Address(
            addressing_mode=(
                isotp.AddressingMode.Normal_29bits
                if is_extended
                else isotp.AddressingMode.Normal_11bits
            ),
            txid=tx_id,
            rxid=rx_id,
        )

        rx_mask = 0x1FFFFFFF if is_extended else 0x7FF
        can_filter = [{
            "can_id": rx_id,
            "can_mask": rx_mask,
            "extended": is_extended,
        }]

        bus = self.can_manager.create_bus(can_filter)
        sniffer_bus = self.can_manager.create_bus(can_filter)

        stack = isotp.CanStack(
            bus=bus,
            address=address,
            params=self.isotp_config,
        )
        connection = PythonIsoTpConnection(stack)

        return {
            "conn": connection,
            "bus": bus,
            "sniffer_bus": sniffer_bus,
            "addr_cfg": addr_cfg,
            "tx_id": tx_id,
            "rx_id": rx_id,
            "is_extended": is_extended,
            "mode_name": mode_name,
        }
