# DTP-CAN — Software Architecture and Design

| | |
|---|---|
| Product | DTP-CAN portable UDS diagnostic tester (Raspberry Pi) |
| Baseline analysed | V6.2.1 (`main.py` + `drivers/`, 8,530 lines) |
| This document describes | the refactored code base (`dtp_can/` package) |
| Python | 3.9 – 3.13 (suite executed on 3.9.25, 3.11.18, 3.13.18) |
| Status | Functionally equivalent to V6.2.1, verified against a recorded golden master; hardware paths not yet re-verified on a Pi (see §J.6) |

---

## A. System Overview

### A.1 Purpose

DTP-CAN is a pocket-sized UDS-on-CAN tester. A Raspberry Pi with an MCP251xFD CAN-FD HAT, a 128×64 OLED and four push buttons:

1. pulls a test campaign (TXT testcase file + JSON configuration) from a Bitbucket branch,
2. executes the UDS requests against an ECU,
3. records all CAN traffic as a Vector-compatible **ASC** log,
4. evaluates the ASC log offline and produces an **HTML report**,
5. pushes logs and reports back to the same branch.

### A.2 Functional overview

| Function | Operator entry point | Main modules |
|---|---|---|
| Wi-Fi selection and monitoring | start-up | `app.workflows.wifi_setup`, `platform.wifi` |
| Campaign selection (Employee / Variant / Type / Stage / Date branch) | start-up | `app.workflows.session_setup`, `vcs.*` |
| Seed/key server probe | start-up | `diagnostics.seed_key` |
| Read ECU information (ECU_INFO rows) | menu 1 | `diagnostics.ecu_info` |
| Run test cases + ASC log + HTML report | menu 2 | `diagnostics.runner`, `diagnostics.services.*`, `reporting.*` |
| Shut down | menu 3 | `platform.power` |
| Push reports to Bitbucket | menu 4 | `vcs.report_tracker`, `vcs.git_client` |
| USB import/export (optional) | menu, if enabled | `platform.usb_storage` |
| Auto-start service | start-up | `platform.service_installer` |

### A.3 Technology stack

| Concern | Technology |
|---|---|
| Language | Python ≥ 3.9 (was effectively ≥ 3.12, see B-02) |
| CAN | SocketCAN via `python-can` ≥ 4.3, MCP251xFD (CAN FD) |
| Transport | ISO 15765-2 via `can-isotp`; plus raw-frame reassembly |
| Diagnostics | ISO 14229 via `udsoncan` (client, session control, TesterPresent) |
| Display / input | SSD1306 via Adafruit Blinka + Pillow; GPIO via `RPi.GPIO` (`python3-rpi-lgpio`); POSIX terminal |
| OS integration | `nmcli`, `ip`/`ifconfig`, `/boot/firmware/config.txt`, `systemd --user`, `ssh-agent`, `git` |
| Packaging | PyInstaller one-file binary (`build_on_pi.sh`) |
| Tests | `pytest`, python-can virtual bus + ECU simulator |

### A.4 Architectural objectives

1. **Extend, don't rewrite.** New UDS services, menu entries, start-up steps, report formats and key providers are added as new modules and registered. Existing modules are not edited.
2. **Behavioural equivalence.** Same bytes on the bus, same report, same screens, unless a change is a documented bug fix.
3. **Testable without hardware.** Every hardware or OS boundary sits behind an injectable seam.
4. **Configuration over code.** Everything V6.2.1 hard-coded is now in `app_settings.json`, with the old values as defaults.
5. **Enforced boundaries.** Layer rules are executable tests, not conventions.

---

## B. Existing Architecture Assessment (V6.2.1)

### B.1 Original architecture

A procedural application with one dominant class:

```
main.py                    UDSApp: start-up, UI widgets, Wi-Fi, Git workflow, CAN bring-up, menu (1,296 lines)
drivers/uds_client.py      UDSClient: connections, ISO-TP, timing, all UDS services, ECU info, run loop (2,113 lines)
drivers/report_generator.py  ASC parsing, matching, verdicts, ECU info, HTML (3,068 lines)
drivers/git_manager.py     git CLI + branch filters + report tracking (442 lines)
drivers/Parse_handler.py   TXT parser with module-global state (202 lines)
drivers/*                  small drivers (OLED, buttons, terminal, CAN logger, SSH, USB, service, interfaces)
```

```mermaid
flowchart LR
    subgraph main.py
        U[UDSApp<br/>god class]
    end
    U --> GM[git_manager] --> U
    U --> UC[uds_client.UDSClient]
    UC --> PH[Parse_handler<br/>global state]
    UC --> RG[report_generator<br/>3,068 lines]
    UC --> CL[can_logger]
    RG --> PH
    U --> OLED[oled_display] & BTN[button_input] & TUI[terminal_ui]
    U --> SSH[ssh_setup<br/>embedded private key] & SI[install_service] & II[initialize_interfaces] & USB[transfer_file]
```

Note the cycle: `GitManager` receives the whole `UDSApp` (`GitManager(self, BASE_DIR)`) and calls back into its UI.

### B.2 Identified limitations

| # | Finding | Evidence | Impact |
|---|---|---|---|
| L-01 | God classes | `UDSApp` combined 9 responsibilities. `UDSClient.run_testcase` was **908 lines**, `generate_html_report` 792. | Any change risks unrelated behaviour. Not unit-testable. |
| L-02 | Per-service logic in one `if/elif` chain | Adding SID 0x31 meant editing the run loop. SIDs with no branch were silently not sent. | Violates open/closed. Hidden gaps. |
| L-03 | Duplicated logic | 5 copy-pasted branch filters (`get_employee_ids` … `get_dates`), each calling `git ls-remote`. Hex cleaning re-implemented ~10 times. `SecurityAccess` checked `response is None` 3× and `isinstance(bytes)` 4×. | Divergent behaviour, 6 network round-trips per selection. |
| L-04 | Global mutable state | `Parse_handler.grouped_cases` / `ordered_testcases` module globals. `report_generator.DESCRIPTION_MAP` plus function attributes used as state. | Not re-entrant. Order-dependent. |
| L-05 | Hard-coded configuration | GPIO pins, OLED size, repo URL, CAN init bit rates, boot overlays, retry counts, menu layout, app version. | Hardware variants need code changes. |
| L-06 | Inconsistent paths | `BASE_DIR` computed in 4 modules. `main.py` = project root, `uds_client`/`transfer_file`/`config_loader` = `drivers/`. | Works only in the frozen build (B-01). |
| L-07 | Secret in source | Bitbucket **private key** literal in `ssh_setup.py`, therefore in every zip and binary. | Credential exposure (S-01). |
| L-08 | No abstraction over OS/hardware | `subprocess`, `RPi.GPIO`, `board` imported and called directly everywhere. | Cannot run or test off-target. |
| L-09 | Dead code | v1 ASC parser, `get_description`, `DESCRIPTION_*`, `file_transfer_menu` (unreachable), commented-out methods, unused `ecu_info_lines`, `waiting_after_pending`. About 15 % of the report module. | Noise, misleading readers. |
| L-10 | Error handling | Any exception in a menu action terminated the process. systemd restarted it and the operator repeated Wi-Fi and Git selection. Errors raised as bare `Exception`. | Poor field robustness. |
| L-11 | No tests | No test suite or fixtures. | Every refactor was blind. |

### B.3 Error handling and logging (as found)

Logging went to `logs/uds_debug.log` plus console. That is kept. Errors were mostly `raise Exception("...")` with string messages and broad `except Exception` blocks. The live run used **two different verdict notions**: the display shows `Pass` unless an exception escapes, while the report verdict is computed offline from the ASC log. This dual model is preserved (Q-07) and now documented.

### B.4 Refactoring rationale

The tool is about to grow (more services such as RoutineControl, more ECU variants, more output formats). Each growth step in V6.2.1 meant editing the 900-line run loop or the 3,000-line report module. The refactor introduces **registries** at exactly those growth points: UDS services, menu features, start-up steps, report generators and key providers. It also moves every hardware or OS dependency behind a seam so the logic can be verified on a PC.

---

## C. Proposed Architecture

### C.1 Overall architecture and style

A **layered architecture with ports and adapters at the edges and plugin registries at the growth points**, wired in one **composition root**. This is a deliberately light design that fits an embedded Python application. It uses no DI framework, no message broker and no async rewrite.

```mermaid
flowchart TB
    subgraph APP["app — composition root & orchestration"]
        BOOT[bootstrap.py<br/>composition root]
        PIPE[startup.py<br/>StartupPipeline + steps]
        MENU[menu.py<br/>MainMenu]
        FEAT[features/*<br/>MenuFeature plugins]
        WF[workflows/*<br/>Wi-Fi, session setup]
        CTX[context.py<br/>AppContext DI container]
        EV[events.py<br/>EventBus]
    end
    subgraph DOMAIN["feature layers"]
        DIAG[diagnostics<br/>transport · services · runner · ECU info · logger · seed/key]
        REP[reporting<br/>ASC parser · matcher · verdict · ECU header · HTML]
    end
    subgraph INFRA["infrastructure adapters"]
        UI[ui<br/>OLED · buttons · terminal · widgets]
        PLAT[platform<br/>shell · Wi-Fi · CAN/boot · SSH · systemd · USB · power]
        VCS[vcs<br/>git client · branch catalog · report tracker]
    end
    subgraph BASE["foundation"]
        TC[testcases<br/>parser · metadata · discovery · workspace]
        CFG[config<br/>AppSettings · UdsConfig · JSON]
        CORE[core<br/>models · hex · ISO-TP · NRC · DID decode · errors]
    end
    APP --> DOMAIN & INFRA & BASE
    DIAG --> REP
    DIAG --> TC & CFG & CORE
    REP --> TC & CORE
    UI --> CFG & CORE
    PLAT --> CFG & CORE
    VCS --> PLAT & CORE
    TC --> CFG & CORE
    CFG --> CORE
```

**Why this style.** The domain is a pipeline (select → execute → log → evaluate → publish) running on a small device with a single operator. A layered design with explicit seams gives testability and extension points without hexagonal ceremony. Registries were chosen over inheritance hierarchies because extension happens by *adding* entries (a SID, a menu item), not by specialising behaviour.

### C.2 Layer responsibilities

| Layer | Responsibility | May import |
|---|---|---|
| `core` | Pure value logic: `TestStep`/`WaitStep`, hex parsing, ISO-TP PCI helpers, NRC table, DID decoding, error types, disk probe. No I/O except the disk probe. | — |
| `config` | Device settings (`AppSettings`), typed view of the test JSON (`UdsConfig`), JSON loading. | core |
| `testcases` | TXT format: parsing, header metadata, discovery in a repo, on-device workspace. | core, config |
| `reporting` | Offline evaluation: ASC parsing, request↔testcase matching, verdicts, ECU header, HTML rendering, `ReportGenerator` port. | core, testcases |
| `diagnostics` | Online execution: CAN/ISO-TP transport, UDS service handlers and registry, test runner, ECU-info reader, CAN logger, seed/key port. | core, config, testcases, reporting |
| `ui` | Display/input ports and adapters, interaction widgets, UI factory. | core, config |
| `platform` | Every external command and OS integration (only layer allowed to use `subprocess`). | core, config |
| `vcs` | Git CLI wrapper, branch catalogue, report tracking. | core, platform |
| `app` | Composition root, DI context, start-up pipeline, workflows, menu and features, event bus. | everything |

### C.3 Module boundaries

Each package exposes a small public surface (see §D). Callers use these classes and functions only:

* `config`: `AppSettings`, `load_settings`, `UdsConfig`, `load_json`
* `testcases`: `parse_testcase_file`, `load_testcase_sequence`, `load_testcases`, `TestcaseWorkspace`, `find_testcases_and_configs`, metadata getters
* `diagnostics`: `build_diagnostics → DiagnosticsStack`, `ServiceHandler`, `ServiceRegistry`, `SeedKeyProvider`, `ReportContext`
* `reporting`: `ReportGenerator`, `HtmlReportGenerator`, `ReportRequest`, `generate_report`
* `ui`: `Display`/`ButtonPad`/`KeyInput` protocols, `UserInterface`, `build_user_interface`
* `platform`: `CommandRunner`, `WifiManager`, `WifiMonitor`, `HardwareInterfaceSetup`, `CanInterface`, `SshSetup`, `ServiceInstaller`, `UsbStorage`, `shutdown`, `gpio_cleanup`
* `vcs`: `GitClient`, `BranchCatalog`, `ReportTracker`
* `app`: `AppContext`, `EventBus`, `MenuFeature`/`register_feature`, `StartupStep`/`register_step`, `main`

### C.4 Dependency management

* **Direction is enforced** by `tests/unit/test_architecture.py`, which parses every module's imports and fails on any edge not allowed in §C.2. It also fails on any module-level import cycle, any `subprocess` outside `platform`, any top-level hardware import, and any private key text in the tree.
* **Construction happens in one place.** `app/bootstrap.py` (`build_context`, `main`) plus `diagnostics/factory.py` (`build_diagnostics`). Consumers receive collaborators through constructors.
* **External libraries are pinned at the edges.** `udsoncan`, `isotp` and `can` are used only in `diagnostics` (and the test simulator). `RPi.GPIO`, `board` and `busio` are imported lazily inside `ui/oled.py`, `ui/buttons.py` and `platform/power.py`.
* Runtime dependencies are unchanged (`requirements.txt`). **No new third-party dependency** was introduced.

---

## D. Module-Level Documentation

Format per module: **Purpose · Responsibilities · Internal components · Public interface · Inputs → Outputs · Dependencies · Interactions · Extension**.

### D.1 `core`
* **Purpose.** Shared, side-effect-free primitives.
* **Components.** `models` (`TestStep`, `WaitStep`, `PASS`/`FAIL`), `hexutil`, `isotp_frames`, `nrc`, `did_decoder`, `errors`, `disk`.
* **Public interface.** `TestStep` (an 11-field `NamedTuple`, positionally compatible with the V6.2.1 tuple); `hex_field_to_bytes`, `split_hex_pairs`, `parse_hex_byte_list`, `trim_trailing`, `looks_like_did`; `frame_type`, `extract_payload_tokens`, `build_display_frame`, `stmin_to_seconds`, `is_response_pending`; `describe_nrc`; `decode_special_did_value`; `DtpError` and subclasses.
* **Inputs → outputs.** Strings/ints → normalised values.
* **Dependencies.** Standard library only.
* **Extension.** Add NRCs to `NRC_DESCRIPTIONS`. Add special DID decoders in `did_decoder`.

### D.2 `config`
* **Purpose.** All configuration access.
* **Components.**
  * `settings.AppSettings` is a dataclass tree: `ui`, `git`, `ssh`, `hardware`, `wifi`, `diagnostics`, `service`, `report`, `menu`, `startup`, `extensions`.
  * `load_settings(base_dir, environ, path)` merges defaults, `app_settings.json` and the `DTP_UI_MODE` environment variable. Unknown keys are logged and ignored; type errors raise `ConfigError`.
  * `uds_config.UdsConfig` validates the test JSON (`uds.can/isotp/timing/udp_server/addressing_modes` required) and exposes typed properties: `allowed_tx_ids`, `uds_can_filters()`, `step_delay_for(sid)` and so on.
  * `json_loader.load_json`.
* **Inputs → outputs.** Files and environment → immutable-by-convention objects.
* **Interactions.** Read by every layer above. Never writes.
* **Extension.** Add a field with a default to the relevant dataclass. Third-party modules use `settings.extensions[...]`.

### D.3 `testcases`
* **Purpose.** Everything about the TXT campaign format.
* **Components.**
  * `parser.parse_testcase_file` returns `ParsedTestcases(grouped, sequence, error)`. It handles header detection, column aliases, re-joining descriptions that contain commas, and `WAIT,<hex ms>` rows.
  * `metadata`: author, generation time, ECU_INFO field names.
  * `discovery.find_testcases_and_configs(repo)`.
  * `workspace.TestcaseWorkspace`: `supportfiles/` plus the `selected_testcase.txt` marker. Methods `install_testcase`, `add_testcase`, `active_testcase`.
* **Behaviour notes.** Parsing errors keep V6.2.1 semantics: the grouped view is empty, the sequence keeps the parsed prefix, and a message is printed and logged.
* **Extension.** New column alias: edit `HEADER_ALIASES`. New row kinds (for example `LOOP`): add a model in `core.models` and a branch in the parser.

### D.4 `diagnostics`
* **Purpose.** Execute campaigns on the bus.
* **Components and interfaces.**
  * `transport.UdsTransport(config, bus_factory, client_factory, sleep)` is the V6.2.1 connection logic, unchanged on the bus.
    * It keeps one ISO-TP stack plus a *sniffer* bus per addressing mode, with lazy switching via `switch_mode`.
    * Responses are read from raw frames with its own flow control, falling back to the udsoncan stack.
    * It handles 0x78 pending with P2/P2\* and a pending limit, and an STmin-derived inter-request guard.
    * Its `RunClock` holds the first-request and last-response times.
    * API: `open_client()`, `send_request_and_wait(...)`, `drain`, `reset_connections`, `prepare_ecu_before_logged_run`, `prepare_execution_start`, `try_basic_communication`, `close`.
  * `services.base.ServiceHandler` declares `service_id` and `execute(ctx) -> Optional[StepOutcome]`. `StepContext` carries the step, parsed expected and write bytes, client, transport, display, cross-step `state` (seeds/keys), the seed/key provider, and helpers `send()`, `show()`, `verify()`.
  * `services/*`: one handler per SID — `10, 11, 14, 19, 22, 27, 28, 2E, 2F, 3E, 85` — plus `BareServiceHandler` (empty sub-function sends `[SID]`) and `UnsupportedServiceHandler` (sends nothing and logs a warning).
  * `services.registry.ServiceRegistry` provides `register`, `resolve(sid, step)`, `load_plugins(["pkg.mod:Class"])`. `default_registry()` returns it pre-loaded.
  * `runner.TestRunner.run(display, tester_name) -> RunResult` performs, in order: storage check, ECU preparation, CAN logging, the step walk (WAIT, addressing switch, handler resolution, display/delay), stop logging, then `ReportGenerator`.
  * `ecu_info.EcuInfoReader.read(display)` returns `{field: value}`.
  * `can_logger.CanLogger` is the ASC writer. It now always releases its bus (B-03).
  * `seed_key.SeedKeyProvider` is the port. `UdpSeedKeyProvider` speaks the existing PC protocol: an ASCII-hex seed out, raw key bytes back, 3 retries, 5 s timeout.
  * `live_verify.verify_response` is the console/log verdict and drives the SecurityAccess flow.
  * `factory.build_diagnostics(...) -> DiagnosticsStack` is the only wiring point.
* **Inputs → outputs.** `UdsConfig` plus the active testcase → bus traffic, ASC file, HTML report path, `RunResult`.
* **Dependencies.** `can`, `isotp`, `udsoncan`, plus `reporting` through the `ReportGenerator` port only.
* **Extension.** A new SID is a new `ServiceHandler` (§H.1). A new key source is a new `SeedKeyProvider` (§H.4).

### D.5 `reporting`
* **Purpose.** Offline evaluation of an ASC log against the TXT campaign. The output is byte-identical to V6.2.1.
* **Components.**
  * `asc_parser`: `parse_line`, `parse_asc_log` (request/response pairing and reassembly), `scan_actual_did_responses`, `get_asc_measurement_window`.
  * `matcher`: `build_testcase_definitions`, `TestcaseMatcher` (exact match, then dynamic-key match for 0x27 even sub-functions; never matches on a partial prefix), placeholders for unobserved rows.
  * `verdict.get_status`: exact compare with padding variants; NRC naming.
  * `ecu_info`: DID label map, value formatting, `build_ecu_header`.
  * `html_renderer`: `generate_html_report`, built from `order_messages`, `compute_time_window`, `render_case_block`, `REPORT_CSS` and `CHART_SCRIPT_TEMPLATE`.
  * `generator`: `ReportGenerator` (port), `HtmlReportGenerator`, `ReportRequest`, and the legacy-signature `generate_report(...)`.
* **Inputs → outputs.** ASC + TXT + metadata → HTML file.
* **Extension.** Implement `ReportGenerator` (§H.5).

### D.6 `ui`
* **Purpose.** Operator I/O independent of the device.
* **Components.**
  * `ports`: `Display`, `ButtonPad`, `KeyInput` protocols and `NullDisplay`.
  * `oled.OLEDDisplay` and `buttons.GpioButtons`, both with lazy hardware imports.
  * `terminal.TerminalDisplay` and `TerminalInput`. The latter uses an fd-level buffered reader (B-08).
  * `router.DisplayRouter` mirrors output to several displays.
  * `interaction.UserInterface` provides `select_from_list`, `enter_text`, `enter_password`, `choose_menu_option`, `show`, `show_for` and `print_instructions`.
  * `factory.build_user_interface(settings)` resolves `auto`, `hardware` or `terminal` mode, producing `hybrid` when both are present.
* **Extension.** Any object satisfying `Display`/`ButtonPad`/`KeyInput` can be injected (§H.6).

### D.7 `platform`
* **Purpose.** All OS and hardware side effects.
* **Components.**
  * `shell.CommandRunner` (`run`, `output`) and the `RecordingRunner` test double.
  * `wifi.WifiManager` (nmcli) and `WifiMonitor`, a thread that publishes `W+`, `W~` or `W-`.
  * `hardware_setup.HardwareInterfaceSetup` handles boot overlays, reboot and initial CAN FD bring-up. `CanInterface` handles the test-config bring-up.
  * `ssh.SshSetup` installs a provisioned key, starts the agent, records the known host and sets the git identity.
  * `service_installer.ServiceInstaller`.
  * `usb_storage.UsbStorage`, which takes a `notify` callback and does no UI itself.
  * `power.shutdown` and `power.gpio_cleanup`.
* **Extension.** A new external integration is a new module here that receives `CommandRunner` (§H.7).

### D.8 `vcs`
* **Components.**
  * `GitClient`: `list_remote_branches`, `clone`, `pull`, `head_commit`, `branch_url`, `add_all`, `commit`, `push`.
  * `BranchCatalog(branches, levels)`: `options(prefix)`, `match`, `require_match`. The levels come from `git.branch_levels`.
  * `ReportTracker(output_dir)`: `start`, `finish`, `copy_to(repo)`.
* **Behaviour.** Commands, branch naming rules and the "tolerate empty commit" rule are unchanged.

### D.9 `app`
* `paths.AppPaths`: one base directory. Properties `logs_dir`, `support_dir`, `selection_file`, `output_dir`, `can_log_dir`.
* `context.AppContext`: the DI container holding settings, paths, events, runner, workspace, tracker, service registry, report generator, plus slots filled by start-up (`ui`, `wifi`, `git`, `session`, `diagnostics`, `usb`) and an open `services` dict. `SessionInfo` is the selection result.
* `events.EventBus`: synchronous publish/subscribe. Topics: `wifi.status`, `session.ready`, `test.run.started`, `test.run.finished`, `reports.pushed`.
* `startup.StartupPipeline`: an ordered list of `StartupStep`s named in `settings.startup` (default = V6.2.1 order).
* `workflows.WifiSetupWorkflow`, `workflows.SessionSetupWorkflow`, and `offline_session` for bench mode.
* `features.MenuFeature` with the `FEATURES` registry. Built-ins: `ecu_info`, `run_tests`, `shutdown`, `push_reports`, `usb_transfer`.
* `menu.MainMenu`: renders the V6.2.1 OLED and console menu. Button *n* selects entry *n*. More than four entries switch to list navigation. A failing feature is contained (B-12).
* `bootstrap.main(argv)`: the CLI (`--settings`, `--ui`, `--offline --config --testcase`, `--version`).

---

## E. Architecture Diagrams

### E.1 High-level system architecture

```mermaid
flowchart LR
    OP((Operator)) -->|"buttons / keyboard"| PI
    PI -->|"OLED / console"| OP
    subgraph PI[Raspberry Pi — DTP-CAN]
        APP[dtp_can]
    end
    PI <-->|"CAN FD (MCP251xFD, SocketCAN)"| ECU[(ECU under test)]
    PI <-->|"UDP seed to key"| PC[PC key server]
    PI <-->|"SSH git clone/pull/push"| BB[(Bitbucket<br/>campaign branches)]
    PI <-->|nmcli| WIFI[Wi-Fi AP]
    PI -->|USB| STICK[(USB stick)]
```

### E.2 Module dependency diagram (package level, enforced by tests)

```mermaid
flowchart BT
    core
    config --> core
    testcases --> config & core
    reporting --> testcases & core
    diagnostics --> reporting & testcases & config & core
    ui --> config & core
    platform --> config & core
    vcs --> platform & core
    app --> diagnostics & reporting & testcases & config & core & ui & platform & vcs
```

### E.3 Component interaction (test execution)

```mermaid
flowchart LR
    RF[RunTestsFeature] --> RT[ReportTracker]
    RF --> UI[UserInterface]
    RF --> RUN[TestRunner]
    RUN --> WS[TestcaseWorkspace]
    RUN --> P[testcases.parser]
    RUN --> T[UdsTransport]
    RUN --> L[CanLogger]
    RUN --> REG[ServiceRegistry]
    REG --> H[ServiceHandler 0xNN]
    H --> T
    H -. 0x27 .-> SK[SeedKeyProvider]
    RUN --> RG[[ReportGenerator port]]
    RG --> HTML[HtmlReportGenerator]
    RF --> EB[(EventBus)]
```

### E.4 Data flow

```mermaid
flowchart LR
    BB[(Bitbucket branch)] -->|clone/pull| REPO[repo checkout]
    REPO -->|.txt| WS[supportfiles/]
    REPO -->|.json| CFG[UdsConfig]
    WS --> PARSE[parser → TestStep*]
    PARSE --> EXEC[TestRunner + handlers]
    CFG --> EXEC
    EXEC -->|UDS requests| BUS((CAN bus))
    BUS -->|all frames| ASC[output/can_logs/*.asc]
    ASC --> REP[reporting]
    PARSE --> REP
    REP --> HTML[repo/output/html_reports/*.html]
    ASC -->|ReportTracker copy| REPO
    REPO -->|commit + push| BB
```

### E.5 Initialization and execution flow

```mermaid
flowchart TD
    A[main argv] --> B[AppPaths.detect + ensure] --> C[configure_logging] --> D[load_settings]
    D --> E[build_context: registries, EventBus, workspace, tracker]
    E --> F{--offline?}
    F -- yes --> G[offline_session, skip ssh/wifi steps]
    F -- no --> H
    G --> H
    subgraph H["StartupPipeline — default order"]
        s1[gpio_cleanup] --> s2[hardware_interfaces<br/>may reboot] --> s3[ssh_setup] --> s4[user_interface]
        s4 --> s5[wifi_setup] --> s6[wifi_monitor] --> s7[test_session] --> s8[diagnostics + UDP probe]
        s8 --> s9[can_readiness] --> s10[usb_storage] --> s11[service_install]
    end
    H --> M[MainMenu.run_forever]
    M --> X{choice}
    X --> F1[ecu_info] & F2[run_tests] & F3[shutdown] & F4[push_reports]
    F1 & F2 & F4 --> M
```

### E.6 Sequence — run test cases

```mermaid
sequenceDiagram
    actor Op as Operator
    participant RF as RunTestsFeature
    participant RT as ReportTracker
    participant R as TestRunner
    participant T as UdsTransport
    participant L as CanLogger
    participant REG as ServiceRegistry
    participant H as ServiceHandler
    participant ECU
    participant RG as ReportGenerator
    Op->>RF: menu 2
    RF->>RT: start()
    RF->>Op: enter_text("Tester Name")
    RF->>R: run(display, tester)
    R->>R: check_storage()
    R->>T: prepare_ecu_before_logged_run() [10 01, fresh sockets]
    R->>L: start(<tc>_<ts>.asc)
    loop each step
        alt WAIT row
            R->>R: countdown on display
        else UDS row
            R->>T: switch_mode(addressing)
            R->>REG: resolve(sid, step)
            R->>H: execute(ctx)
            H->>T: send_request_and_wait(raw)
            T->>ECU: ISO-TP request
            ECU-->>T: response (0x78 pending handled)
            R->>R: display status + configured delay
        end
    end
    R->>L: stop()
    R->>RG: generate(ReportRequest)
    RG-->>R: html path
    RF->>RT: finish()
    RF->>RF: publish test.run.finished
```

### E.7 Sequence — SecurityAccess (0x27)

```mermaid
sequenceDiagram
    participant H as SecurityAccessHandler
    participant T as UdsTransport
    participant ECU
    participant SK as SeedKeyProvider (UDP)
    participant PC as PC key server
    H->>T: 27 01
    T->>ECU: 27 01
    ECU-->>T: 67 01 <seed>
    H->>H: verify, store state["seed_1"]
    alt provider unavailable
        H->>SK: check_server()
    end
    H->>SK: request_key(seed)
    SK->>PC: "12345678" (ASCII hex)
    PC-->>SK: key bytes
    H->>H: state["key_2"] = key
    Note over H: next row (27 02)
    H->>T: 27 02 <key>
    T->>ECU: 27 02 <key>
    ECU-->>T: 67 02
    H-->>H: StepOutcome(skip_post_step_delay)
```

### E.8 Sequence — push reports

```mermaid
sequenceDiagram
    participant F as PushReportsFeature
    participant RT as ReportTracker
    participant G as GitClient
    F->>RT: copy_to(session.repo_path)
    F->>G: add_all() → git -C repo add .
    F->>G: commit() → git commit -m "Updated Reports" (non-zero tolerated)
    F->>G: push() → git push -u origin <branch>
    F->>F: publish reports.pushed
```

### E.9 Modular diagram (layers and their modules)

Each box is a package with its modules; arrows are the only imports allowed (§C.2).

```mermaid
flowchart TB
    APP["<b>app</b> — composition root<br/>bootstrap · context · events · startup · menu<br/>features/ (5 menu plugins) · workflows/ (wifi, session)"]
    DIAG["<b>diagnostics</b><br/>transport · runner · ecu_info<br/>can_logger · seed_key · live_verify · factory<br/>services/ — 11 SID handlers + registry"]
    REP["<b>reporting</b><br/>asc_parser · matcher · verdict<br/>ecu_info · formatting · html_renderer<br/>generator (ReportGenerator port)"]
    UI["<b>ui</b><br/>ports · oled · buttons<br/>terminal · router<br/>interaction · factory"]
    PLAT["<b>platform</b><br/>shell · wifi · ssh<br/>hardware_setup · power<br/>usb_storage · service_installer"]
    VCS["<b>vcs</b><br/>git_client<br/>branch_catalog<br/>report_tracker"]
    TC["<b>testcases</b><br/>parser · metadata<br/>discovery · workspace"]
    CFG["<b>config</b><br/>settings (AppSettings)<br/>uds_config · json_loader"]
    CORE["<b>core</b> — pure, no I/O<br/>models · hexutil · isotp_frames · nrc · did_decoder · errors · disk"]

    APP --> DIAG & REP & UI & PLAT & VCS
    DIAG -->|ReportGenerator port| REP
    VCS --> PLAT
    DIAG --> TC & CFG
    REP --> TC
    UI & PLAT --> CFG
    TC --> CFG
    TC & CFG & DIAG & REP & UI & PLAT & VCS --> CORE

    classDef app fill:#EEEDFE,stroke:#534AB7,color:#26215C
    classDef domain fill:#E1F5EE,stroke:#0F6E56,color:#04342C
    classDef adapter fill:#F1EFE8,stroke:#5F5E5A,color:#2C2C2A
    classDef base fill:#FFFFFF,stroke:#888780,color:#2C2C2A
    class APP app
    class DIAG,REP domain
    class UI,PLAT,VCS adapter
    class TC,CFG,CORE base
```

Purple: orchestration · teal: diagnostics/reporting · gray: hardware/OS/Git adapters · white: foundation. Every arrow is an allowed import; `tests/unit/test_architecture.py` fails on any other.

### E.10 Class communication — start-up wiring

`main()` builds the long-lived services, the start-up steps fill the remaining `AppContext` slots, and menu features read their collaborators from the context instead of creating them.

```mermaid
flowchart TB
    MAIN["main()<br/>entry point"] --> BC["build_context()<br/>creates services"] --> CTX["AppContext<br/>DI container"]
    MAIN --> SP["StartupPipeline<br/>11 named steps"]
    SP --> UI["UserInterface<br/>OLED + console"]
    SP --> WM["WifiMonitor<br/>link status"]
    SP --> SI["SessionInfo<br/>branch, config"]
    SP --> DS["DiagnosticsStack<br/>transport, runner"]
    UI & WM & SI & DS -. stored in .-> CTX
    MAIN --> MM["MainMenu<br/>button n → feature n"]
    MM -->|show / choose| UI
    MM -->|run| MF["MenuFeature plugins<br/>ecu_info · run_tests · shutdown · push_reports"]
    MF -. reads collaborators .-> CTX
```

### E.11 Class communication — one test run

What happens after "Run Test Cases" is pressed. `TestRunner` contains no per-service logic; it resolves a `ServiceHandler` for each step.

```mermaid
flowchart TB
    RTF["RunTestsFeature<br/>menu option 2"]
    RTF -->|start / finish| RT["ReportTracker<br/>snapshot output/"]
    RTF -->|enter_text| UI["UserInterface<br/>tester name"]
    RTF -->|"run(display, tester)"| TR["TestRunner<br/>walks every step"]
    TR -->|active_testcase| WS["TestcaseWorkspace + parser<br/>TXT → TestStep list"]
    TR -->|"resolve(sid, step)"| REG["ServiceRegistry<br/>SID → handler"]
    TR -->|start / stop| LOG["CanLogger<br/>writes ASC log"]
    REG --> SH["ServiceHandler<br/>execute(StepContext)"]
    SH -->|0x27 only| SK["SeedKeyProvider<br/>UDP key server"]
    SH -->|send_request_and_wait| TP["UdsTransport<br/>ISO-TP send / wait"]
    TP <-->|CAN FD frames| ECU[("ECU")]
    LOG -->|ASC file| RG["ReportGenerator<br/>ASC + TXT → HTML"]
    TR -->|generate| RG
```

### E.12 Class communication — events

Producers publish to the `EventBus` without knowing their listeners; handlers run in the publisher's thread and a failing handler cannot affect the others.

```mermaid
flowchart LR
    WMON["WifiMonitor<br/>polls nmcli"] -->|wifi.status| BUS(["EventBus<br/>publish / subscribe"])
    FEAT["Features & workflows"] -->|"session.ready<br/>test.run.started / finished<br/>reports.pushed"| BUS
    BUS -->|set_wifi_status| UIF["UserInterface<br/>W+ / W~ / W-"]
    BUS --> EXT["Extension modules<br/>subscribe to topics"]
```

### E.13 Class communication — Git session and report push

`CommandRunner` is the only class that runs OS commands (git, nmcli, ip, systemctl); everything else reaches the OS through it.

```mermaid
flowchart TB
    SS["SessionSetupWorkflow<br/>operator picks branch"] -->|install_testcase| WSP["TestcaseWorkspace<br/>active testcase"]
    SS -->|options per level| CAT["BranchCatalog<br/>5-level branch menu"]
    SS -->|list / clone / pull| GC["GitClient<br/>ls-remote · clone · pull · push"]
    PR["PushReportsFeature<br/>menu option 4"] -->|add · commit · push| GC
    PR -->|copy_to repo| TRK["ReportTracker<br/>files of this run"]
    GC --> CR["CommandRunner<br/>only subprocess user"]
```

## F. Directory Structure

```
dtp-can/
├── main.py                      # entry point (PyInstaller target): dtp_can.app.bootstrap.main
├── build_on_pi.sh               # Pi build; now --collect-submodules dtp_can, never bundles keys
├── requirements.txt             # runtime deps (unchanged set)
├── requirements-dev.txt         # + pytest, flake8
├── setup.cfg / pytest.ini       # lint + test configuration
├── config/
│   └── app_settings.example.json  # every setting with its default; copy to <app>/app_settings.json
├── credentials/README.md        # where to provision the Bitbucket key on a device (never committed)
├── dtp_can/
│   ├── core/                    # pure primitives (no hardware, no OS)
│   ├── config/                  # AppSettings, UdsConfig, JSON loader
│   ├── testcases/               # TXT parser, metadata, discovery, workspace
│   ├── diagnostics/             # transport, CAN logger, runner, ECU info, seed/key
│   │   └── services/            # one module per UDS service family + registry
│   ├── reporting/               # ASC parser, matcher, verdict, ECU header, HTML renderer, generator port
│   ├── ui/                      # ports, OLED, buttons, terminal, router, widgets, factory
│   ├── platform/                # shell, Wi-Fi, boot/CAN, SSH, systemd, USB, power
│   ├── vcs/                     # git client, branch catalog, report tracker
│   └── app/                     # bootstrap, context, events, startup, menu, workflows/, features/
├── tests/
│   ├── unit/                    # fast tests incl. executable architecture rules
│   ├── integration/             # app flow on the ECU simulator
│   ├── regression/              # golden master vs V6.2.1 + capture script
│   ├── support/                 # ECU simulator, SocketCAN-like virtual bus, fakes
│   └── fixtures/                # sim testcase/config + golden/ artefacts recorded from V6.2.1
└── SOFTWARE_ARCHITECTURE_AND_DESIGN.md
```

**Runtime layout on the device** (unchanged; relative to the executable's folder):

```
<app>/uds_diagnostics      <app>/app_settings.json (optional)   <app>/credentials/ (optional, first install)
<app>/logs/uds_debug.log   <app>/supportfiles/<active>.txt      <app>/selected_testcase.txt
<app>/output/can_logs/*.asc                                      <app>/<branch_with_underscores>/ (checkout)
<checkout>/output/html_reports/*.html                           <checkout>/output/can_logs/*.asc (after push)
```

What belongs where: hardware and OS calls go in `platform` (or `ui` for operator I/O). The meaning of bytes, frames and files goes in `core`, `testcases` and `reporting`. Anything that coordinates several of these goes in `app`.

---

## G. Dependency and Communication Model

### G.1 Who depends on whom

See §C.2 and §E.2. The rules are executable: `pytest tests/unit/test_architecture.py`.

### G.2 How modules communicate

| Mechanism | Used for | Example |
|---|---|---|
| Constructor injection | all collaborators | `TestRunner(config, transport, can_logger, registry, workspace, report_generator, seed_key, …)` |
| Ports (ABC / Protocol) | swappable implementations | `ReportGenerator`, `SeedKeyProvider`, `ServiceHandler`, `Display`, `ButtonPad`, `KeyInput`, `CommandRunner` |
| Registries | extension by addition | `ServiceRegistry`, `FEATURES`, start-up step registry |
| Event bus (sync pub/sub) | one-to-many notifications | `WifiMonitor` publishes `wifi.status` → `UserInterface.set_wifi_status` |
| Callbacks | UI-agnostic progress | `UsbStorage(notify=ui.show)` |
| Return values / dataclasses | results | `RunResult`, `SessionInfo`, `DiagnosticsStack` |

### G.3 How dependencies are injected

`bootstrap.build_context()` creates the long-lived services. Start-up steps fill the remaining `AppContext` slots in order. `DiagnosticsStep` calls `diagnostics.factory.build_diagnostics()` with the session's `UdsConfig`. Tests inject alternatives through the same seams:

* `bus_factory` puts the transport and logger on a virtual bus;
* `RecordingRunner` replaces every OS command;
* `ScriptedButtons` and `ScriptedKeys` replace operator input;
* `FakeTransport` and `FakeSeedKey` support handler tests;
* `sleep` removes waits.

### G.4 How circular dependencies are prevented

1. The layer table only allows downward edges, and the test fails on any upward import.
2. A graph test fails on any module-level cycle. It resolves `from pkg import submodule` correctly; I verified that it catches an injected cycle.
3. Callbacks and the event bus replace back-references. V6.2.1's `GitManager(UDSApp)` back-pointer is gone: `vcs` knows nothing about the UI, and the workflow in `app` drives both.
4. The only deferred import is `registry.default_registry()` → `services.builtin`, so the `services` package `__init__` can re-export the registry.

### G.5 How new modules integrate

Write the module in the right layer, depend only on allowed layers, expose a class implementing an existing port, then register it:

* in code, in the composition root; or
* declaratively in `app_settings.json`:

```json
"extensions": {
  "service_handlers": ["mobase_ext.routine:RoutineControlHandler"],
  "feature_modules":  ["mobase_ext.features"],
  "startup_modules":  ["mobase_ext.startup"]
},
"menu":    ["ecu_info", "run_tests", "shutdown", "push_reports", "usb_transfer"],
"startup": ["gpio_cleanup", "hardware_interfaces", "ssh_setup", "user_interface", "wifi_setup",
            "wifi_monitor", "test_session", "diagnostics", "can_readiness", "usb_storage",
            "service_install", "my_new_step"]
```

---

## H. Extensibility Guidelines

### H.1 Add a UDS service — RoutineControl 0x31 (closes gap Q-01)

```python
# dtp_can/diagnostics/services/routine_control.py   (new file)
from dtp_can.core.hexutil import hex_field_to_bytes
from dtp_can.diagnostics.services.base import ServiceHandler, StepContext


class RoutineControlHandler(ServiceHandler):
    service_id = 0x31
    name = "RoutineControl"

    def execute(self, ctx: StepContext):
        # TXT: SubService_ID = "01FF00" (start routine FF00), Write_Data = option record
        raw = bytes([0x31]) + hex_field_to_bytes(ctx.step.subfunction) \
            + hex_field_to_bytes(ctx.step.write_data)
        response = ctx.send(raw, expected_bytes=ctx.expected_bytes)
        if response:
            ctx.verify(response)
```

Register it by adding `RoutineControlHandler()` to `services/builtin.all_handlers()`, or without touching built-ins via `"extensions": {"service_handlers": ["dtp_can.diagnostics.services.routine_control:RoutineControlHandler"]}`. No change to the runner, transport or report is needed: the report matcher already knows SID `31`. Add a test row to `test_services.py`'s parametrised table.

### H.2 Add a menu feature

```python
# mobase_ext/features.py
from dtp_can.app.features import MenuFeature, register_feature


@register_feature
class ClearDtcQuickAction(MenuFeature):
    feature_id = "clear_dtcs"
    oled_label = "Clear DTCs"
    terminal_label = "Clear all DTCs (14 FF FF FF)"

    def run(self):
        diag = self.context.require_diagnostics()
        with diag.transport.open_client() as client:
            resp = diag.transport.send_request_and_wait(client, bytes([0x14, 0xFF, 0xFF, 0xFF]),
                                                        "MENU", "Clear DTCs")
        self.context.ui.show_for("DTCs cleared" if resp and resp[0] == 0x54 else "Clear failed", 2)
```

Enable it with `"extensions": {"feature_modules": ["mobase_ext.features"]}` and add `"clear_dtcs"` to `"menu"`. With more than four entries the menu switches to list navigation automatically.

### H.3 Introduce a new module (start-up step example)

```python
# mobase_ext/startup.py
import logging
from dtp_can.app.startup import StartupStep, register_step


@register_step
class AnnounceIpStep(StartupStep):
    name = "announce_ip"

    def run(self, ctx):
        ip = ctx.runner.run("hostname -I", shell=True).stdout.split()[0]
        logging.info("Device IP %s", ip)
        ctx.ui.show_for(f"IP\n{ip}", 2)
```

Add `"startup_modules": ["mobase_ext.startup"]` and insert `"announce_ip"` in `"startup"`.

### H.4 Replace an implementation — local seed/key algorithm instead of the UDP PC server

```python
from dtp_can.diagnostics.seed_key import SeedKeyProvider


class XorSeedKey(SeedKeyProvider):
    def __init__(self, mask: bytes):
        self.mask = mask

    def check_server(self):
        return True

    def request_key(self, seed: bytes) -> bytes:
        return bytes(s ^ m for s, m in zip(seed, self.mask))
```

Wire it in `DiagnosticsStep` (or a replacement step): `build_diagnostics(..., seed_key=XorSeedKey(b"\x5A\xA5\x5A\xA5"))`. `SecurityAccessHandler` is unchanged.

### H.5 Add an output format (JSON summary next to the HTML)

```python
import json
from dtp_can.reporting import HtmlReportGenerator, ReportGenerator


class HtmlPlusJsonReport(ReportGenerator):
    def __init__(self, html: HtmlReportGenerator):
        self.html = html

    def generate(self, request):
        path = self.html.generate(request)
        with open(path.replace(".html", ".json"), "w") as fh:
            json.dump({"testcase": request.txt_file_path, "asc": request.asc_file_path,
                       "tester": request.tester_name, "branch": request.branch_name}, fh)
        return path
```

Pass it as `report_generator=` in `bootstrap.build_context`. The `ReportTracker` picks up any new file under `output/` automatically.

### H.6 Add a display or input device

Implement the `Display` protocol (`set_wifi_status`, `clear`, `display_text`, `display_centered_text`) and/or `ButtonPad` (`get_pressed_nonblocking`). Then pass a factory to `build_user_interface(settings, oled_factory=MyDisplay, buttons_factory=MyPad)`. All workflows and features keep working.

### H.7 Add an external integration (for example a CAN-log upload to a server)

Create `dtp_can/platform/<name>.py` that takes a `CommandRunner` (for CLI tools) or plain sockets/HTTP. Expose a small class. Subscribe it to `test.run.finished` in a start-up step:

```python
ctx.events.subscribe("test.run.finished", lambda result: uploader.upload(result.can_log))
```

### H.8 Modify an existing module safely

1. Run `pytest` before you start: everything must be green.
2. Change one module. If its public interface changes, update the callers in the same commit (the architecture test confirms nobody else imports internals).
3. For anything touching bus traffic or the report, run `pytest tests/regression`. If a change *intends* to alter output, regenerate the golden master with `tests/regression/capture_legacy_golden.py` (against the previous release) and review the diff.

---

## I. Coding Standards and Design Guidelines

| Topic | Convention |
|---|---|
| Naming | `snake_case` functions/modules, `PascalCase` classes, `UPPER_CASE` constants. Handlers are named after the ISO 14229 service (`ReadDataByIdentifierHandler`). Feature ids are `snake_case`. |
| File organisation | One responsibility per module; place it by layer (§F). A module over ~400 lines or a function over ~60 lines is a signal to split. The HTML template and the ASC state machine are the documented exceptions (§J.7). |
| Interfaces | Ports are ABCs (`abc.ABC`) when implementations share helpers, otherwise `typing.Protocol`. Constructors take collaborators. Never instantiate infrastructure inside domain code. |
| Imports | Absolute (`from dtp_can.x import y`). Hardware libraries only inside functions. `subprocess` only in `platform`. |
| Error handling | Raise `DtpError` subclasses (`ConfigError`, `SessionSetupError`, `SetupCancelled`, `SeedKeyError`, `TestcaseFormatError`) for expected failures. Catch at workflow or feature boundaries (`MainMenu.run_once`, start-up step). Within `ServiceHandler`s keep the documented per-SID policy (§D.4). Never swallow silently: log with `logging.exception` or an explicit message. |
| Logging | `logging` module only (root logger configured in `app.logging_setup`). `INFO` for operator-relevant events, `WARNING` for recoverable anomalies, `ERROR` for failed actions, `DEBUG` for payload dumps. `print` is reserved for the console echo of operator messages that V6.2.1 printed. |
| Configuration | Device behaviour goes in `AppSettings` (with a default equal to current behaviour). Test campaign behaviour goes in the test JSON (`UdsConfig`). Do not read files or the environment outside `config`. |
| Documentation | Module docstring stating purpose and any preserved V6.2.1 quirk. `BUGFIX (B-xx)` comments where behaviour intentionally differs. Keep this document's §D and §J in step with code. |
| Testing | Every new handler, feature or step needs a unit test using the fakes in `tests/support`. Anything that changes traffic or reports needs the regression suite green. Keep tests hardware-free. Use `bus_factory=virtual_bus.create_bus` with `EcuSimulator` for bus-level tests. |
| Style | flake8, max line 110 (`setup.cfg`). Python 3.9-compatible syntax (`from __future__ import annotations`). |

---

## J. Migration and Change Summary

### J.1 Files

**Created:** the whole `dtp_can/` package (81 modules), `tests/` (unit, integration, regression, support, fixtures), `config/app_settings.example.json`, `credentials/README.md`, `requirements*.txt`, `setup.cfg`, `pytest.ini`, `.gitignore`, `README.md`, this document.

**Modified:** `main.py` (now an 8-line entry point), `build_on_pi.sh` (Python ≥ 3.9 check, `requirements.txt`, `--collect-submodules dtp_can` instead of 14 `drivers.*` hidden imports, settings example copied to `dist/`, no key bundling).

**Removed** (each replaced as shown; no duplicate implementations left):

| V6.2.1 | Replaced by |
|---|---|
| `drivers/uds_client.py` | `diagnostics/transport.py`, `services/*`, `runner.py`, `ecu_info.py`, `seed_key.py`, `live_verify.py`, `factory.py` |
| `drivers/report_generator.py` | `reporting/*` (dead v1 parser and globals dropped) |
| `drivers/Parse_handler.py` | `testcases/parser.py` (+ `metadata.py`) |
| `drivers/git_manager.py` | `vcs/git_client.py`, `vcs/branch_catalog.py`, `vcs/report_tracker.py`, `testcases/discovery.py`, `app/workflows/session_setup.py` |
| `drivers/terminal_ui.py` | `ui/terminal.py`, `ui/router.py` |
| `drivers/oled_display.py`, `button_input.py` | `ui/oled.py`, `ui/buttons.py` |
| `drivers/config_loader.py` | `config/json_loader.py` |
| `drivers/can_logger.py` | `diagnostics/can_logger.py` |
| `drivers/did_decoder.py` | `core/did_decoder.py` (unchanged logic) |
| `drivers/initialize_interfaces.py` | `platform/hardware_setup.py` |
| `drivers/ssh_setup.py` | `platform/ssh.py` (**no embedded key**) |
| `drivers/install_service.py` | `platform/service_installer.py` |
| `drivers/transfer_file.py` | `platform/usb_storage.py` + `usb_transfer` feature |
| `UDSApp` (main.py) | `app/*`, `ui/interaction.py`, `ui/factory.py`, `platform/wifi.py` |

### J.2 Architectural changes

God classes are split by responsibility. Per-SID logic moved into a handler registry. Start-up became a configurable pipeline, and the menu a feature registry. All hard-coded values moved into `AppSettings`. The single path authority is `AppPaths`. All OS calls go through `CommandRunner`. An event bus carries status updates. The report module was cut into parser, matcher, verdict, ECU header and renderer, with `ReportGenerator` as a port. Architecture rules are now tests.

### J.3 Bug fixes (behaviour intentionally changed)

| ID | Defect in V6.2.1 | Fix | Verified by |
|---|---|---|---|
| **B-01** | `BASE_DIR` differs between modules in source mode: the testcase was copied to `<root>/supportfiles` but read from `<root>/drivers/supportfiles`. | `AppPaths` single source. | Integration tests run from source. |
| **B-02** | `report_generator.py` uses a 3.12-only nested multi-line f-string and **fails to compile on Python 3.11**, the Raspberry Pi OS Bookworm default. | Pre-rendered rows; 3.9+ syntax throughout. | `py_compile` of the legacy file on 3.11 fails; full suite passes on 3.9 / 3.11 / 3.13. |
| **B-03** | `CANLogger.stop()` writes to the file that `ASCWriter.stop()` already closed. The exception skips `bus.shutdown()`, so **one CAN socket leaks per test run** (observed as "I/O operation on closed file"). | Close order fixed; bus always released. ASC content unchanged. | `test_can_logger_releases_bus`, byte-identical report. |
| **B-04** | `parse_asc_file_v2` falls through after finalising an incomplete multi-frame response and calls `finalize_message(None)`, so `AttributeError` **aborts report generation**. Reproduced on the original file with a crafted ASC log. | `continue` after finalising. | `test_incomplete_multiframe_followed_by_single_frame_does_not_crash` (legacy crashes on the same input); golden output unchanged. |
| **B-05** | CAN-readiness loop builds a new `UDSClient` (two sockets) per attempt and never closes it. | Re-uses and resets the main transport. | `test_can_readiness_brings_up_can_and_reuses_transport`. |
| **B-06** | Re-initialisation (USB import path) started a second Wi-Fi monitor thread. | `WifiMonitor.start()` is idempotent. | `test_wifi_monitor_start_is_idempotent`. |
| **B-07** | "Read ECU Info" showed "Run Test cases" on the OLED. | Shows "Reading / ECU Info". | Integration test. |
| **B-08** | Console input read the buffered `sys.stdin` after `select()` on the fd: **arrow keys decoded as ESC** (cancel/submit) and typed-ahead or pasted characters were lost. Reproduced on the original file: ↑ `a` `b` → `['ESC']`. | fd-level reader with own buffer and UTF-8 decoder. | `test_terminal_input.py` (real pty); end-to-end pty drive. |
| B-09 | Log line `Test start time: .6f` (datetime formatted with `.6f`). | ISO timestamp. | — |
| B-10 | Missing git identity triggers `input()` under systemd (no TTY), giving `EOFError` and a restart loop. | Identity from `git.user_name/user_email` settings; clear `ConfigError` when neither a setting nor a TTY is available. | `test_ssh_git_identity_from_settings`. |
| B-11 | `display.address` was passed around but never given to the SSD1306 driver. | Address passed (default `0x3C` = previous library default). | — |
| **B-12** | Any exception in a menu action killed the process. systemd restarted it and the operator had to redo Wi-Fi and Git selection. | `MainMenu.run_once` contains the failure, shows "<feature> Failed" and returns to the menu. | `test_feature_registry_and_menu`. |

### J.4 Security change

**S-01 — embedded private key removed.** The Bitbucket deploy key was a string literal in `drivers/ssh_setup.py`. It was therefore present in every copy of the source zip and every PyInstaller binary, and it was re-written to `~/.ssh` on every start. `SshSetup` now uses `~/.ssh/diagtestpi_bitbucket` if present, which is the case on every device that already ran V6.2.1. Otherwise it installs the key from `<app>/credentials/`, or fails with an actionable message. `test_no_private_key_material_in_tree` keeps keys out of the repository. **Action required:** treat the old key as compromised, rotate it in Bitbucket, and deploy the new one via `credentials/`.

### J.5 Breaking changes and compatibility

| ID | Change | Who is affected | Mitigation |
|---|---|---|---|
| BC-01 | Key no longer bundled (S-01). | Fresh devices only. | Put the key in `<app>/credentials/` once. |
| BC-02 | `drivers.*` import paths removed. | Only code importing internals; none in the repo. | Use `dtp_can.*`. `dtp_can.reporting.generate_report` keeps the V6.2.1 signature. |
| BC-03 | Source-mode runtime files now live in the project root (as in the frozen build). | Developers running `python main.py`. | None needed; matches production. |
| BC-04 | Menu-action exceptions no longer restart the app (B-12). | Operators (improvement). | — |
| BC-05 | Unreachable `file_transfer_menu` and its GPIO-combination input removed. Test-JSON keys `gpio.buttons`, `menu_combinations` and `file_transfer_submenu_combinations` are ignored. They were already without effect: the button pins were hard-coded before the JSON was read. | Nobody in practice. | USB import/export is now the `usb_transfer` feature, enabled via `"menu"`. |

**Unchanged and compatible:**

* TXT testcase format;
* test JSON schema;
* request bytes on the bus;
* ASC file content;
* HTML report (byte-identical);
* branch naming;
* git commands and commit message;
* runtime folder layout;
* systemd unit text;
* `DTP_UI_MODE`;
* the four-entry menu and button mapping;
* OLED and console texts (except B-07).

### J.6 Verification performed

**Golden master.** The original V6.2.1 `drivers/` code was executed against a deterministic UDS ECU simulator. The simulator runs on a python-can virtual bus patched to behave like SocketCAN: kernel-side filtering, and locally sent frames reported as `Tx`. Request traces, ECU-info results, the ASC log and the HTML report were recorded in `tests/fixtures/golden/`. The fixture covers:

* sessions 10 01 / 10 03;
* a WAIT row;
* TesterPresent physical and functional;
* SecurityAccess seed/key over UDP;
* a multi-frame WriteDataByIdentifier;
* ReadDTCInformation (0x19), ClearDiagnosticInformation (0x14), ControlDTCSetting (0x85), CommunicationControl (0x28), InputOutputControl (0x2F);
* a 0x78 pending response;
* an NRC, a no-response row and a mismatch;
* an unsupported SID (0x31), an ECU reset, an empty sub-function;
* a description containing a comma;
* Ascii and Decimal formats.

**Tests executed.** All passed, 272 / 272, on each of Python **3.9.25, 3.11.18, 3.13.18**:

| Suite | Count | What it proves |
|---|---|---|
| `unit/test_services.py` | 47 | Exact request bytes for every SID branch incl. quirks; error policy per SID; registry order; plugin loading. |
| `unit/test_core_and_parser.py` | 13 | Hex/ISO-TP helpers, NRC, DID decoder, parser (aliases, comma merge, WAIT, errors), metadata, discovery, workspace. |
| `unit/test_config.py` | 8 | Settings defaults equal V6.2.1 hard-coded values; overrides; validation; `UdsConfig`. |
| `unit/test_reporting_units.py` | 6 | Verdict rules, ASC line parsing, matcher (no prefix stealing, dynamic key), live verify, B-04 crash path. |
| `unit/test_vcs_and_platform.py` | 11 | Branch catalogue, git command lines, report tracker, Wi-Fi manager/monitor, boot/CAN commands identical to V6.2.1, SSH provisioning, systemd unit. |
| `unit/test_ui_and_app.py` | 11 | Widgets (buttons + keyboard), UI factory modes, event bus, feature registry, menu text identical to V6.2.1, start-up pipeline. |
| `unit/test_terminal_input.py` | 3 | Key decoding on a real pty (B-08). |
| `unit/test_architecture.py` | 166 | Layer rules and isolated import for each of 81 modules (2 × 81), plus no cycles, subprocess confinement, no top-level hardware imports, no key material. |
| `integration/test_app_flow.py` | 4 | Composition root + start-up steps + ECU-info/run/push features on the simulator; session workflow with branch selection; CAN readiness bring-up. |
| `regression/test_golden_master.py` | 3 | **Report byte-identical** to V6.2.1 for the same ASC. **Live run sends the identical request sequence** (24 requests) and the same seeds as V6.2.1. ECU info identical. Report verdicts and response rows identical to V6.2.1's own report. Logger releases its bus. |

**Additional checks:**

* `flake8` and `pyflakes` clean.
* A differential check of old vs new HTML renderer on synthetic edge cases (error frame, empty frame, PreCondition-only, unmatched ASC traffic, response note, empty report): identical.
* **End-to-end run of the real `main()`** under a pseudo-terminal in offline mode, with real `TerminalInput` and `TerminalDisplay`: menu → tester name → full run producing ASC and HTML → ECU info → Ctrl-C with exit status 0.

**Not verified here** (no hardware or network in the build environment):

* OLED/GPIO on a Pi;
* MCP251xFD/SocketCAN with a real ECU;
* `nmcli` Wi-Fi;
* `systemd`;
* Bitbucket SSH clone/push;
* the PyInstaller build (`build_on_pi.sh` was only syntax-checked).

These code paths keep the V6.2.1 commands (asserted by unit tests), but **a bench run on a Pi with a real ECU is required before release.**

### J.7 Preserved quirks, known limitations and technical debt

These were kept unchanged on purpose (equivalence first) and are candidates for follow-up:

| ID | Behaviour (unchanged from V6.2.1) | Recommendation |
|---|---|---|
| Q-01 | SIDs without a handler and with a non-empty sub-function (for example **0x31 RoutineControl**) are **not sent**; the report shows "Testcase not observed in ASC log". | Add `RoutineControlHandler` (§H.1). |
| Q-02 | 0x3E with an empty sub-function sends nothing (now logged as a warning). | Decide: bare `3E` or reject at parse time. |
| Q-03 | 0x28 with an empty Communication_Type repeats the last sub-function byte (`28 03` → `28 03 03`). | Make the column mandatory. |
| Q-04 | `WAIT,<n>` is **hex** milliseconds (`WAIT,64` = 100 ms). | Document in the campaign template, or accept a `ms` suffix. |
| Q-05 | ECU header: a later non-ECU_INFO read of a configured DID overwrites the ECU_INFO value (in the fixture, a Decimal-formatted read turns "SN0042" into "83 78 48 48 52 50"). | Let ECU_INFO rows win. |
| Q-06 | Report verdict is an exact compare (with padding variants). An expected value shorter than the response fails ("62 F1 90" vs full VIN). | Optional prefix-match column. |
| Q-07 | The live display shows `Pass` unless an exception escapes; the authoritative verdict comes from the ASC. | Show the live `verify_response` result instead. |
| Q-08 | A successful 0x27 key send skips the post-step status screen and delay. | Harmonise. |
| Q-09 | USB-imported JSON is copied to the app folder but the active config always comes from the Git session. | Let `usb_transfer` start an offline session. |
| Q-10 | HTML reports are written straight into the checkout; ASC logs go to `<app>/output` and are copied only at push time. | One output root per session. |
| Q-11 | Start-up first brings `can0` up at 1 M/8 M (settings), then optionally re-configures with the test JSON rates. | Single bring-up from the test JSON. |
| Q-12 | The HTML report loads Chart.js from a CDN; offline viewing loses the pie chart. | Inline the script. |
| TD-1 | `reporting/asc_parser.parse_asc_log` is still a 285-line state machine (kept verbatim; its edge paths are only partly covered by golden data). | Extract an `IsoTpReassembler` class, with targeted ASC fixtures first. |
| TD-2 | `html_renderer` page header is a large f-string template (verbatim for byte-identity). | Move to a template file once byte-identity is no longer required. |
| TD-3 | Golden data covers one ECU behaviour profile. | Capture more ASC fixtures from real bench runs (11-bit/29-bit, CAN classic, long DTC lists). |
| TD-4 | Mixed-language log strings and the `busyRepeatReques` NRC spelling are kept because they appear in existing reports. | Clean up in a release that accepts report diffs. |

### J.8 Future improvement opportunities

1. RoutineControl (0x31), RequestDownload/TransferData (0x34/0x36/0x37) as handlers, which opens up ECU flashing.
2. Machine-readable result export (JUnit XML or JSON) via a second `ReportGenerator`, for CI dashboards.
3. Campaign validation at selection time (unknown SIDs, malformed hex), shown on the OLED before execution.
4. Signed/versioned campaign branches and a release tag in the report header (`report.app_version` is already configurable).
5. Pi-in-the-loop CI job: run `tests/regression` on a real Pi with a loop-back ECU simulator over `vcan0`.
