"""DTP-CAN entry point (PyInstaller target and ``python main.py``)."""

import sys

from dtp_can.app.bootstrap import main

if __name__ == "__main__":
    sys.exit(main())
