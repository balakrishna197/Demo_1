# credentials/

Put the Bitbucket deploy key here **on the device only** - never commit it.

    credentials/diagtestpi_bitbucket       (private key, mode 0600)
    credentials/diagtestpi_bitbucket.pub   (optional)

On start-up `ssh_setup` copies it to `~/.ssh/diagtestpi_bitbucket` if that
file does not exist yet. Devices that already ran V6.2.1 have the key in
`~/.ssh` and need nothing here.

The key that used to be embedded in `drivers/ssh_setup.py` was distributed
inside every source zip and every PyInstaller binary. Treat it as exposed:
generate a new deploy key, register it in Bitbucket, remove the old one.
