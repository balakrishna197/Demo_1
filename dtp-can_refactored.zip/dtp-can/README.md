# DTP-CAN — portable UDS diagnostic tester

Raspberry Pi + CAN-FD HAT + OLED/buttons tool that pulls a test campaign from Bitbucket, runs UDS
requests against an ECU, logs CAN traffic (ASC), generates an HTML report and pushes results back.

Architecture, module reference, extension guide and the full V6.2.1 → refactor change log:
**[SOFTWARE_ARCHITECTURE_AND_DESIGN.md](SOFTWARE_ARCHITECTURE_AND_DESIGN.md)**.

## Run

```bash
./build_on_pi.sh                      # on the Pi: builds dist/uds_diagnostics
python3 main.py                       # from source (same behaviour as the binary)
python3 main.py --ui terminal         # console only (also: DTP_UI_MODE=terminal)
python3 main.py --offline --config bench.json --testcase cases.txt   # bench mode, no Wi-Fi/Git
```

First install on a new device: copy the Bitbucket deploy key to `credentials/diagtestpi_bitbucket`
(see `credentials/README.md`). Optional device settings: copy `config/app_settings.example.json`
to `app_settings.json` next to the executable and edit; every default equals V6.2.1 behaviour.

## Test (no hardware needed)

```bash
pip install -r requirements-dev.txt
pytest                      # 272 tests: unit, architecture rules, simulator integration, golden master
pytest tests/regression     # bus traffic + report identical to V6.2.1
```
