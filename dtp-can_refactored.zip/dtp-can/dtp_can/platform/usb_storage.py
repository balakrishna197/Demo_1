"""USB stick import/export (testcase + config in, output folder out).

UI-agnostic: progress is reported through a ``notify(text)`` callback, so the
same logic works with the OLED, the console, or no display at all.
"""

from __future__ import annotations

import logging
import os
import shutil
import time
from datetime import datetime
from typing import Callable, Optional

EXCLUDED_JSON = "git_credentials.json"


class UsbStorage:
    def __init__(
        self,
        output_dir: str,
        workspace,
        config_dir: str,
        notify: Callable[[str], None] = lambda text: None,
        usb_root: str = "/media",
        sleep: Callable[[float], None] = time.sleep,
    ):
        self.output_dir = output_dir
        self.workspace = workspace
        self.config_dir = config_dir
        self.notify = notify
        self.usb_root = usb_root
        self._sleep = sleep

    def _progress(self, base_msg: str, duration: float = 3, interval: float = 0.5) -> None:
        for i in range(int(duration / interval)):
            self.notify(f"{base_msg}{'.' * ((i % 3) + 1)}")
            self._sleep(interval)

    def find_mount(self) -> Optional[str]:
        logging.info(f"Looking for USB under: {self.usb_root}")
        try:
            for user in os.listdir(self.usb_root):
                user_path = os.path.join(self.usb_root, user)
                if os.path.isdir(user_path):
                    for device in os.listdir(user_path):
                        mount_path = os.path.join(user_path, device)
                        if os.path.ismount(mount_path):
                            logging.info(f"USB mount found at: {mount_path}")
                            return mount_path
        except Exception as e:
            logging.error(f"Error while scanning USB: {e}")
        return None

    def import_testcase_and_config(self) -> bool:
        self.notify("Searching for USB...")
        self._sleep(1)
        mount = self.find_mount()
        if not mount:
            self.notify("No USB device found.")
            self._sleep(2)
            logging.warning("No USB mount path found.")
            return False
        try:
            logging.info(f"Scanning USB at: {mount}")
            self.notify("USB found.\nSearching files...")
            self._sleep(1)
            testcase_copied = json_copied = False
            self.workspace.ensure()
            for root, _dirs, files in os.walk(mount):
                for file in files:
                    lower = file.lower()
                    if lower.endswith(".txt"):
                        self.workspace.add_testcase(os.path.join(root, file))
                        logging.info(f"Copied {file}")
                        self._progress(f"Copying {file}")
                        testcase_copied = True
                    elif lower.endswith(".json") and file != EXCLUDED_JSON:
                        shutil.copy(os.path.join(root, file), os.path.join(self.config_dir, file))
                        logging.info(f"Copied {file}")
                        json_copied = True
            if testcase_copied and json_copied:
                self.notify("Files updated\nfrom USB.")
                self._sleep(2)
                return True
            self.notify("Files not found\non USB.")
            self._sleep(2)
            return False
        except Exception:
            logging.exception("Error copying files from USB")
            return False

    def export_outputs(self) -> int:
        """Copy the output folder to ``UDS_Backup_<ts>/Outputs``; returns file count."""
        try:
            self.notify("Searching for USB...")
            logging.info("Starting transfer...")
            self._sleep(1)
            mount = self.find_mount()
            if not mount:
                self.notify("No USB device found.")
                logging.warning("No USB device mounted")
                self._sleep(2)
                return 0
            backup_folder = os.path.join(
                mount, f"UDS_Backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            )
            os.makedirs(backup_folder, exist_ok=True)
            logging.info(f"Backup folder created on USB: {backup_folder}")
            self.notify("USB Found.\nCopying Data...")
            self._sleep(2)
            self._progress("Transferring...", duration=3)
            destination = os.path.join(backup_folder, "Outputs")
            shutil.copytree(self.output_dir, destination)
            file_count = sum(len(files) for _, _, files in os.walk(destination))
            self.notify(f"Transfer Done\n{file_count} files")
            logging.info(f"Transfer complete. Files copied: {file_count}")
            self._sleep(2)
            return file_count
        except Exception as e:
            self.notify("Error")
            logging.error(f"Error during USB transfer: {e}")
            self._sleep(3)
            return 0
