"""SSH key provisioning for Bitbucket access + git identity.

SECURITY CHANGE (see SOFTWARE_ARCHITECTURE_AND_DESIGN.md, section J):
V6.2.1 embedded the Bitbucket private key in source code (and therefore in
the zip and the PyInstaller binary) and rewrote ``~/.ssh`` from it at every
start.  The key is now *never* part of the code base.  It is taken from:

1. ``<ssh_dir>/<key_name>`` - already present on every device that ever ran
   V6.2.1, so existing installations keep working unchanged;
2. ``<search path>/<key_name>`` for each ``ssh.key_search_paths`` entry
   (default ``<app>/credentials/``) - copied into ``ssh_dir`` with 0600.

If neither exists, start-up fails with an actionable message.
"""

from __future__ import annotations

import logging
import os
import shutil
import sys
from typing import Callable, Optional

from dtp_can.config.settings import GitSettings, SshSettings
from dtp_can.core.errors import ConfigError
from dtp_can.platform.shell import CommandRunner


def _interactive_prompt(message: str) -> str:
    if not sys.stdin or not sys.stdin.isatty():
        raise ConfigError(
            "Git identity is not configured and no terminal is available. "
            "Set git.user_name / git.user_email in app_settings.json."
        )
    return input(message).strip()


class SshSetup:
    def __init__(
        self,
        ssh: SshSettings,
        git: GitSettings,
        base_dir: str,
        runner: Optional[CommandRunner] = None,
        prompt: Callable[[str], str] = _interactive_prompt,
        environ=os.environ,
    ):
        self.ssh = ssh
        self.git = git
        self.base_dir = base_dir
        self.runner = runner or CommandRunner()
        self.prompt = prompt
        self.environ = environ

    @property
    def ssh_dir(self) -> str:
        return os.path.expanduser(self.ssh.ssh_dir)

    @property
    def private_key_path(self) -> str:
        return os.path.join(self.ssh_dir, self.ssh.key_name)

    # ------------------------------------------------------------------
    def ensure_openssh(self) -> None:
        logging.info("Checking openssh-client...")
        if self.runner.run("which ssh-agent", shell=True).returncode != 0:
            logging.info("Installing openssh-client...")
            self.runner.run(
                "sudo apt update && sudo apt install -y openssh-client", shell=True, check=True
            )
        else:
            logging.info("openssh-client already installed.")

    def ensure_ssh_agent(self) -> None:
        if "SSH_AUTH_SOCK" in self.environ:
            logging.info("ssh-agent already running.")
            return
        logging.info("Starting ssh-agent...")
        agent = self.runner.run(["ssh-agent", "-s"], check=True)
        for line in agent.stdout.splitlines():
            if "=" in line and ";" in line:
                key, value = line.split(";", 1)[0].split("=", 1)
                self.environ[key] = value
        logging.info("ssh-agent started successfully.")

    def ensure_known_host(self) -> None:
        host = self.ssh.known_host
        known_hosts = os.path.join(self.ssh_dir, "known_hosts")
        os.makedirs(self.ssh_dir, mode=0o700, exist_ok=True)
        if not os.path.exists(known_hosts):
            open(known_hosts, "a").close()
            os.chmod(known_hosts, 0o644)
        if self.runner.run(["ssh-keygen", "-F", host, "-f", known_hosts]).returncode == 0:
            logging.info(f"{host} already exists in known_hosts.")
            return
        logging.info(f"Adding {host} to known_hosts...")
        result = self.runner.run(["ssh-keyscan", "-H", host])
        if result.returncode != 0 or not result.stdout.strip():
            raise RuntimeError(f"Failed to retrieve {host} host key:\n{result.stderr}")
        with open(known_hosts, "a") as f:
            f.write(result.stdout)
        logging.info(f"{host} added to known_hosts successfully.")

    def ensure_keys(self) -> str:
        os.makedirs(self.ssh_dir, mode=0o700, exist_ok=True)
        target = self.private_key_path
        if not os.path.exists(target):
            source = self._find_provisioned_key()
            if source is None:
                searched = [self._expand(p) for p in self.ssh.key_search_paths]
                raise ConfigError(
                    f"SSH private key '{self.ssh.key_name}' not found in {self.ssh_dir} "
                    f"or {searched}. Copy the Bitbucket deploy key there (see README)."
                )
            logging.info("Installing SSH key from %s", source)
            shutil.copyfile(source, target)
            if os.path.exists(source + ".pub"):
                shutil.copyfile(source + ".pub", target + ".pub")
        os.chmod(target, 0o600)
        if os.path.exists(target + ".pub"):
            os.chmod(target + ".pub", 0o644)

        logging.info("Validating private key...")
        result = self.runner.run(["ssh-keygen", "-lf", target])
        if result.returncode != 0:
            raise RuntimeError("Invalid private key:\n" + result.stderr)
        logging.info("Private key validated successfully.")
        return target

    def _expand(self, path: str) -> str:
        return os.path.expanduser(path.replace("{base_dir}", self.base_dir))

    def _find_provisioned_key(self) -> Optional[str]:
        for folder in self.ssh.key_search_paths:
            candidate = os.path.join(self._expand(folder), self.ssh.key_name)
            if os.path.isfile(candidate):
                return candidate
        return None

    def add_key_to_agent(self, private_key_path: str) -> None:
        logging.info("Checking existing keys in ssh-agent...")
        listed = self.runner.run(["ssh-add", "-l"])
        if private_key_path in (listed.stdout or ""):
            logging.info("Key already present in ssh-agent.")
            return
        logging.info("Adding key to ssh-agent...")
        result = self.runner.run(["ssh-add", private_key_path])
        if result.returncode != 0:
            raise RuntimeError("Failed to add SSH key:\n" + result.stderr)
        logging.info("SSH key added successfully.")

    def configure_git_identity(self) -> None:
        logging.info("Checking Git identity...")
        user_name = self.runner.run(["git", "config", "--global", "user.name"]).stdout.strip()
        user_email = self.runner.run(["git", "config", "--global", "user.email"]).stdout.strip()
        if user_name and user_email:
            logging.info("Git identity already configured: %s <%s>", user_name, user_email)
            return
        user_name = user_name or (self.git.user_name or "") or self.prompt("Enter Git user name: ")
        user_email = user_email or (self.git.user_email or "") or self.prompt("Enter Git email: ")
        if not user_name or not user_email:
            raise RuntimeError("Git user name and email cannot be empty.")
        self.runner.run(["git", "config", "--global", "user.name", user_name], check=True)
        self.runner.run(["git", "config", "--global", "user.email", user_email], check=True)
        logging.info("Git identity configured: %s <%s>", user_name, user_email)

    def setup(self) -> None:
        self.ensure_openssh()
        self.ensure_ssh_agent()
        self.ensure_known_host()
        self.add_key_to_agent(self.ensure_keys())
        self.configure_git_identity()
        logging.info("SSH setup completed successfully.")
