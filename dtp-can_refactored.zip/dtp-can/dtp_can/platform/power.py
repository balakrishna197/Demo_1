"""Power and GPIO housekeeping."""

from __future__ import annotations

import logging
from typing import Optional

from dtp_can.platform.shell import CommandRunner


def shutdown(runner: Optional[CommandRunner] = None) -> None:
    (runner or CommandRunner()).run("sudo poweroff", shell=True)


def gpio_cleanup() -> bool:
    """Release GPIO state left by a previous (crashed) instance."""
    try:
        import RPi.GPIO as GPIO  # type: ignore[import-not-found]
    except ImportError:
        logging.info("RPi.GPIO not available - GPIO cleanup skipped")
        return False
    GPIO.cleanup()
    return True
