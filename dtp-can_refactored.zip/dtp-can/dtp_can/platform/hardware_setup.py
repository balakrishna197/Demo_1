"""Raspberry Pi peripheral enablement and CAN interface control.

``HardwareInterfaceSetup`` is the former ``drivers/initialize_interfaces``
(``/boot/firmware/config.txt`` SPI/I2C/MCP251xFD overlays, reboot when the
boot config changed, initial CAN FD bring-up).  ``CanInterface`` is the
config-driven ``can0`` bring-up that lived in ``main.py``.  Commands are
unchanged; all values come from ``AppSettings``.
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
from typing import Callable, Optional

from dtp_can.config.settings import HardwareSettings
from dtp_can.platform.shell import CommandRunner


class HardwareInterfaceSetup:
    def __init__(
        self,
        settings: HardwareSettings,
        runner: Optional[CommandRunner] = None,
        path_exists: Callable[[str], bool] = os.path.exists,
        exit_process: Callable[[int], None] = sys.exit,
    ):
        self.settings = settings
        self.runner = runner or CommandRunner()
        self.config_file = settings.boot_config
        self.reboot_required = False
        self._exists = path_exists
        self._exit = exit_process

    # -- helpers ----------------------------------------------------------
    def _run(self, cmd: str) -> str:
        logging.info(f"-> {cmd}")
        result = self.runner.run(cmd, shell=True)
        if result.returncode != 0:
            logging.error(f"x {result.stderr.strip()}")
        return result.stdout.strip()

    def _append_line_root(self, line: str) -> bool:
        check = self.runner.run(f"grep -qxF '{line}' {self.config_file}", shell=True)
        if check.returncode == 0:
            return False
        self._run(f"echo '{line}' | sudo tee -a {self.config_file} > /dev/null")
        return True

    # -- SPI / I2C / CAN FD overlays -------------------------------------
    def enable_spi(self) -> None:
        if self._exists("/dev/spidev0.0"):
            logging.info("SPI already enabled")
            return
        logging.info("Enabling SPI...")
        if self._append_line_root("dtparam=spi=on"):
            self.reboot_required = True
            logging.info("SPI enabled (reboot required)")

    def enable_i2c(self) -> None:
        if self._exists("/dev/i2c-1"):
            logging.info("I2C already enabled")
            return
        logging.info("Enabling I2C...")
        if self._append_line_root("dtparam=i2c_arm=on"):
            self.reboot_required = True
            logging.info("I2C enabled (reboot required)")

    def canfd_configured(self) -> bool:
        return self.runner.run(f"grep -q mcp251xfd {self.config_file}", shell=True).returncode == 0

    def enable_canfd(self) -> None:
        if self.canfd_configured():
            logging.info("CAN FD already configured")
            return
        logging.info("Enabling CAN FD...")
        changes = False
        for line in ["# CAN FD Setup", "dtparam=spi=on", *self.settings.canfd_overlays]:
            changes |= self._append_line_root(line)
        if changes:
            self.reboot_required = True
            logging.info("CAN FD config added (reboot required)")

    # -- initial CAN FD bring-up ----------------------------------------
    def bringup_canfd(self) -> None:
        can = self.settings.can_init
        if not self._exists(f"/sys/class/net/{can.channel}"):
            logging.error("CAN FD interface not found (reboot needed)")
            return
        if "UP" in self._run(f"ip link show {can.channel}"):
            logging.info("CAN FD already UP")
            return
        logging.info("Bringing up CAN FD...")
        self._run(f"sudo ip link set {can.channel} down")
        self._run(
            f"sudo ip link set {can.channel} up type can bitrate {can.bitrate} "
            f"dbitrate {can.dbitrate} "
            f"restart-ms {can.restart_ms} berr-reporting on fd on"
        )
        self._run(f"sudo ifconfig {can.channel} txqueuelen {can.txqueuelen}")
        self._run(f"sudo ip link set {can.channel} up")
        if "UP" in self._run(f"ip link show {can.channel}"):
            logging.info("CAN FD is UP")
        else:
            logging.error("CAN FD bring-up failed")

    def handle_reboot(self) -> None:
        if self.reboot_required and self.settings.reboot_when_required:
            logging.warning("Reboot required. Rebooting...")
            sys.stdout.flush()
            self.runner.run("sudo reboot", shell=True)
            self._exit(0)
        elif self.reboot_required:
            logging.warning("Reboot required but disabled by settings")
        else:
            logging.info("No reboot required")

    def initialize(self) -> None:
        logging.info("===== HARDWARE INIT =====")
        if self.settings.enable_spi:
            self.enable_spi()
        if self.settings.enable_i2c:
            self.enable_i2c()
        self.enable_canfd()
        self.handle_reboot()
        logging.info("--- CAN FD Bring-up ---")
        self.bringup_canfd()
        logging.info("===== DONE =====")


class CanInterface:
    """Bring the SocketCAN interface up with the *test configuration* rates."""

    def __init__(self, channel: str = "can0", runner: Optional[CommandRunner] = None):
        self.channel = channel
        self.runner = runner or CommandRunner()

    def is_present(self) -> bool:
        result = self.runner.run(f"ip link show {self.channel}", shell=True)
        return self.channel in (result.stdout or "")

    def bring_up(self, bitrate: int, dbitrate: int, restart_ms: int) -> bool:
        try:
            logging.info(f"Bringing up CAN interface {self.channel}...")
            self.runner.run(["sudo", "ip", "link", "set", self.channel, "down"], check=True)
            self.runner.run(
                ["sudo", "ip", "link", "set", self.channel, "up", "type", "can",
                 "bitrate", str(bitrate), "dbitrate", str(dbitrate),
                 "restart-ms", str(restart_ms), "berr-reporting", "on", "fd", "on"],
                check=True,
            )
            self.runner.run(["sudo", "ifconfig", self.channel, "up"], check=True)
            logging.info(f"CAN interface {self.channel} successfully brought up.")
            return True
        except subprocess.CalledProcessError as e:
            logging.error(f"CAN bringup failed: {e}")
            return False
