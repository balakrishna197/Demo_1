"""Installs/updates the systemd *user* service that auto-starts the tester."""

from __future__ import annotations

import logging
import os
import pwd
import sys
from typing import Optional

from dtp_can.config.settings import ServiceSettings
from dtp_can.platform.shell import CommandRunner

SERVICE_TEMPLATE = """[Unit]
Description={description}
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory={working_dir}
ExecStart={exe_path}

Restart=always
RestartSec=5

Environment=PYTHONUNBUFFERED=1
Environment=XDG_RUNTIME_DIR=/run/user/{uid}
Environment=DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/{uid}/bus

[Install]
WantedBy=default.target
"""


def current_executable() -> str:
    if getattr(sys, "frozen", False):
        return os.path.realpath(sys.executable)
    return os.path.realpath(sys.argv[0])


class ServiceInstaller:
    def __init__(
        self,
        settings: ServiceSettings,
        runner: Optional[CommandRunner] = None,
        home: Optional[str] = None,
        exe_path: Optional[str] = None,
        uid: Optional[int] = None,
    ):
        self.settings = settings
        self.runner = runner or CommandRunner()
        self.home = home or os.path.expanduser("~")
        self.exe_path = exe_path or current_executable()
        self.uid = os.getuid() if uid is None else uid

    def render(self) -> str:
        return SERVICE_TEMPLATE.format(
            description=self.settings.description,
            working_dir=os.path.dirname(self.exe_path),
            exe_path=self.exe_path,
            uid=self.uid,
        )

    def install(self) -> bool:
        """Returns True when the unit file was (re)written."""
        service_dir = os.path.join(self.home, ".config", "systemd", "user")
        service_path = os.path.join(service_dir, self.settings.name)
        service_text = self.render()
        written = False
        try:
            os.makedirs(service_dir, exist_ok=True)
            current = None
            if os.path.exists(service_path):
                with open(service_path, "r") as f:
                    current = f.read()
            if current != service_text:
                logging.info(f"Installing/Updating {self.settings.name}...")
                with open(service_path, "w") as f:
                    f.write(service_text)
                self.runner.run(["systemctl", "--user", "daemon-reload"], check=True)
                self.runner.run(["systemctl", "--user", "enable", self.settings.name], check=True)
                written = True
                logging.info(f"{self.settings.name} installed successfully.")
            else:
                logging.info(f"{self.settings.name} already up-to-date.")

            username = pwd.getpwuid(self.uid).pw_name
            result = self.runner.run(["sudo", "loginctl", "enable-linger", username])
            if result.returncode == 0:
                logging.info("User lingering enabled.")
            else:
                logging.warning(f"Could not enable lingering: {result.stderr.strip()}")
        except Exception as e:
            logging.error(f"Service installation failed: {e}")
        return written
