"""Single choke point for running external commands.

Every OS integration receives a ``CommandRunner`` instead of calling
``subprocess`` directly, so tests can substitute ``RecordingRunner`` and
assert on the exact commands without touching the machine.
"""

from __future__ import annotations

import logging
import subprocess
from typing import List, Sequence, Union

Command = Union[str, Sequence[str]]


class CommandRunner:
    def run(
        self,
        cmd: Command,
        check: bool = False,
        capture: bool = True,
        shell: bool = False,
    ) -> subprocess.CompletedProcess:
        logging.debug("exec: %s", cmd)
        return subprocess.run(
            cmd,
            shell=shell,
            check=check,
            capture_output=capture,
            text=True,
        )

    def output(self, cmd: Command, shell: bool = False) -> str:
        """stdout of a command that must succeed (raises CalledProcessError)."""
        return subprocess.check_output(cmd, shell=shell, text=True)


class RecordingRunner(CommandRunner):
    """Test double: records commands and replays canned results."""

    def __init__(self, responses=None, default_returncode: int = 0, default_stdout: str = ""):
        self.calls: List[Command] = []
        self.responses = responses or {}
        self.default_returncode = default_returncode
        self.default_stdout = default_stdout

    def _key(self, cmd: Command) -> str:
        return cmd if isinstance(cmd, str) else " ".join(cmd)

    def run(self, cmd, check=False, capture=True, shell=False):
        self.calls.append(cmd)
        rc, out, err = self.responses.get(self._key(cmd), (self.default_returncode, self.default_stdout, ""))
        if callable(rc):
            rc, out, err = rc(cmd)
        if check and rc != 0:
            raise subprocess.CalledProcessError(rc, cmd, out, err)
        return subprocess.CompletedProcess(cmd, rc, out, err)

    def output(self, cmd, shell=False):
        result = self.run(cmd, check=True)
        return result.stdout
