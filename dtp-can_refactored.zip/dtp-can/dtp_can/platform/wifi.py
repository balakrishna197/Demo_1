"""Wi-Fi management through NetworkManager's ``nmcli`` + background monitor."""

from __future__ import annotations

import logging
import threading
from typing import Callable, List, Optional

from dtp_can.platform.shell import CommandRunner

STATUS_CONNECTED = "W+"
STATUS_RECONNECTING = "W~"
STATUS_DISCONNECTED = "W-"


class WifiManager:
    def __init__(self, runner: Optional[CommandRunner] = None, connect_wait_s: int = 15):
        self.runner = runner or CommandRunner()
        self.connect_wait_s = connect_wait_s
        self.current_ssid: Optional[str] = None
        self.connected = False

    def scan(self) -> List[str]:
        try:
            result = self.runner.output(["nmcli", "-t", "-f", "SSID", "dev", "wifi"])
        except Exception as e:
            logging.error(f"WiFi Scan Error: {e}")
            return []
        networks: List[str] = []
        for ssid in result.splitlines():
            ssid = ssid.strip()
            if ssid and ssid not in networks:
                networks.append(ssid)
        return networks

    def saved_connections(self) -> List[str]:
        result = self.runner.run(["nmcli", "-t", "-f", "NAME", "connection", "show"])
        return result.stdout.splitlines()

    def is_connected(self, ssid: str) -> bool:
        result = self.runner.run(["nmcli", "-t", "-f", "ACTIVE,SSID", "device", "wifi"])
        return any(line == f"yes:{ssid}" for line in result.stdout.splitlines())

    def try_saved_connection(self, ssid: str) -> bool:
        return self.runner.run(["nmcli", "connection", "up", ssid]).returncode == 0

    def delete_connection(self, ssid: str) -> None:
        self.runner.run(["nmcli", "connection", "delete", ssid])

    def connect(self, ssid: str, password: str) -> bool:
        result = self.runner.run(
            ["nmcli", "--wait", str(self.connect_wait_s), "device", "wifi", "connect",
             ssid, "password", password]
        )
        logging.info(result.stdout)
        if result.stderr:
            logging.error(result.stderr)
        return result.returncode == 0

    def mark_connected(self, ssid: str) -> None:
        self.current_ssid = ssid
        self.connected = True

    def reconnect(self) -> bool:
        if not self.current_ssid:
            return False
        logging.info("Trying WiFi reconnect...")
        self.connected = self.try_saved_connection(self.current_ssid)
        return self.connected


class WifiMonitor:
    """Polls the link and publishes ``W+``/``W~``/``W-`` status changes."""

    def __init__(
        self,
        wifi: WifiManager,
        publish: Callable[[str], None],
        interval_s: float = 10.0,
    ):
        self.wifi = wifi
        self.publish = publish
        self.interval_s = interval_s
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_ok = True

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return  # V6.2.1 started a second thread on re-initialisation
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="wifi-monitor", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def check_once(self) -> str:
        connected = bool(self.wifi.current_ssid) and self.wifi.is_connected(self.wifi.current_ssid)
        if connected:
            if not self._last_ok:
                logging.info("WiFi Reconnected")
            self._last_ok = True
            self.publish(STATUS_CONNECTED)
            return STATUS_CONNECTED
        if self._last_ok:
            logging.warning("WiFi Lost")
        self._last_ok = False
        self.publish(STATUS_RECONNECTING)
        if self.wifi.reconnect():
            self._last_ok = True
            logging.info("WiFi Reconnected")
            self.publish(STATUS_CONNECTED)
            return STATUS_CONNECTED
        self.publish(STATUS_DISCONNECTED)
        return STATUS_DISCONNECTED

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.check_once()
            except Exception:
                logging.exception("WiFi monitor iteration failed")
            self._stop.wait(self.interval_s)
