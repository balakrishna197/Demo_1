"""Configuration management: device settings + per-test JSON configuration."""
