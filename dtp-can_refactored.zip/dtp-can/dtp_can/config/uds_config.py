"""Typed, validated view over the per-test JSON configuration (``uds`` key).

The JSON schema is unchanged from V6.2.1; this class only centralises key
access, defaults and hex parsing that used to be scattered through
``UDSClient``.  ``raw`` keeps the original dictionary for code that needs it.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from dtp_can.core.errors import ConfigError

REQUIRED_SECTIONS = ("can", "isotp", "timing", "udp_server", "addressing_modes")


class UdsConfig:
    def __init__(self, config: Dict[str, Any], path: Optional[str] = None):
        if not isinstance(config, dict) or "uds" not in config:
            raise ConfigError("Test configuration has no 'uds' section")
        uds = config["uds"]
        missing = [key for key in REQUIRED_SECTIONS if key not in uds]
        if missing:
            raise ConfigError(
                f"Test configuration 'uds' section is missing: {', '.join(missing)}"
            )
        self.raw = config
        self.path = path
        self.uds: Dict[str, Any] = uds

    # -- sections ---------------------------------------------------------
    @property
    def can(self) -> Dict[str, Any]:
        return self.uds["can"]

    @property
    def isotp(self) -> Dict[str, Any]:
        return self.uds["isotp"]

    @property
    def timing(self) -> Dict[str, Any]:
        return self.uds.get("timing", {})

    @property
    def addressing_modes(self) -> Dict[str, Any]:
        return self.uds["addressing_modes"]

    # -- scalar values ----------------------------------------------------
    @property
    def target_ecu(self) -> str:
        return self.uds.get("target_ecu", "Unknown ECU")

    @property
    def channel(self) -> str:
        return self.can["channel"]

    @property
    def interface(self) -> str:
        return self.can["interface"]

    @property
    def can_fd(self) -> bool:
        return self.can.get("can_fd", True)

    @property
    def bitrate(self) -> int:
        return self.can.get("bitrate", 500000)

    @property
    def dbitrate(self) -> int:
        return self.can.get("dbitrate", 2000000)

    @property
    def restart_ms(self) -> int:
        return self.can.get("restart_ms", 1000)

    @property
    def bringup_on_startup(self) -> bool:
        return self.can.get("bringup_on_startup", False)

    @property
    def udp_ip(self) -> str:
        return self.uds["udp_server"]["ip"]

    @property
    def udp_port(self) -> int:
        return self.uds["udp_server"]["port"]

    @property
    def expected_key_length(self) -> int:
        return self.uds["udp_server"]["expected_key_length"]

    @property
    def default_session(self) -> int:
        return int(self.uds.get("default_session", "0x01"), 16)

    @property
    def extended_session(self) -> int:
        return int(self.uds["extended_session"], 16)

    @property
    def immediate_mode(self) -> bool:
        return self.uds.get("immediate_mode", False)

    @property
    def info_dids(self) -> Dict[str, Any]:
        return self.uds.get("ecu_information_dids", {})

    @property
    def decode_dids(self) -> Dict[str, Any]:
        return self.uds.get("decoding_dids", {})

    @property
    def write_data(self) -> Dict[str, Any]:
        return self.uds.get("write_data", {})

    @property
    def step_delays(self) -> Dict[str, Any]:
        return self.uds.get("delays", {})

    @property
    def default_delay(self) -> float:
        return self.step_delays.get("default", 0.5)

    @property
    def logging_filters_enabled(self) -> bool:
        return self.uds.get("logging", {}).get("filters", False)

    # -- addressing -------------------------------------------------------
    def _mode_id(self, mode: str, key: str) -> int:
        return int(self.addressing_modes.get(mode, {}).get(key, "0"), 16)

    @property
    def allowed_tx_ids(self) -> List[int]:
        return [self._mode_id("physical", "tx_id"), self._mode_id("functional", "tx_id")]

    @property
    def allowed_rx_ids(self) -> List[int]:
        return [self._mode_id("physical", "rx_id"), self._mode_id("functional", "rx_id")]

    def uds_can_filters(self) -> Optional[List[Dict[str, Any]]]:
        """CAN logger filters: ``None`` (log everything) unless enabled."""
        if not self.logging_filters_enabled:
            return None
        return [
            {"can_id": self._mode_id(mode, key), "can_mask": 0x7FF, "extended": False}
            for mode, key in (
                ("physical", "tx_id"),
                ("physical", "rx_id"),
                ("functional", "tx_id"),
                ("functional", "rx_id"),
            )
        ]

    def step_delay_for(self, service_text: str) -> float:
        return float(self.step_delays.get(service_text.upper(), self.default_delay))
