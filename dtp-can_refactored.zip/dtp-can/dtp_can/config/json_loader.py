"""Generic JSON configuration loader (replaces drivers/config_loader.py)."""

from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional

from dtp_can.core.errors import ConfigError


def load_json(config_path: str, base_dir: Optional[str] = None) -> Dict[str, Any]:
    """Load a JSON file; relative paths are resolved against ``base_dir``.

    Raises ``ConfigError`` (a subclass of ``Exception``) with the same
    messages as before for missing / malformed files.
    """
    if not os.path.isabs(config_path) and base_dir:
        config_path = os.path.join(base_dir, config_path)

    if not os.path.exists(config_path):
        raise ConfigError(f"Configuration file not found:\n{config_path}")

    try:
        with open(config_path, "r") as file:
            return json.load(file)
    except json.JSONDecodeError as exc:
        raise ConfigError(
            f"Invalid JSON format in:\n{config_path}\n\n{exc}"
        ) from exc
    except Exception as exc:  # pragma: no cover - defensive
        raise ConfigError(
            f"Failed to load configuration:\n{config_path}\n\n{exc}"
        ) from exc
