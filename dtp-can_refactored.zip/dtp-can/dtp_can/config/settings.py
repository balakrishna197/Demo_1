"""Device-level application settings (``app_settings.json``).

Everything that V6.2.1 hard-coded in source (GPIO pins, OLED geometry,
repository URL, CAN init bit rates, retry counts, menu layout, ...) lives
here.  Every default equals the old hard-coded value, so the file is
optional and an existing installation behaves exactly as before without it.

Resolution order (later wins):
  1. defaults in this module
  2. ``<base_dir>/app_settings.json`` (or the path in ``$DTP_SETTINGS``)
  3. environment overrides (``DTP_UI_MODE`` - kept for backward compatibility)
"""

from __future__ import annotations

import copy
import json
import logging
import os
from dataclasses import dataclass, field, fields, is_dataclass
from typing import Any, Dict, List, Mapping, Optional

from dtp_can.core.errors import ConfigError

SETTINGS_FILENAME = "app_settings.json"


@dataclass
class DisplaySettings:
    width: int = 128
    height: int = 64
    address: str = "0x3C"


@dataclass
class ButtonSettings:
    first: int = 12
    second: int = 16
    enter: int = 20
    power: int = 21

    def pins(self) -> List[int]:
        return [self.first, self.second, self.enter, self.power]


@dataclass
class UiSettings:
    mode: str = "auto"  # auto | hardware | terminal
    display: DisplaySettings = field(default_factory=DisplaySettings)
    buttons: ButtonSettings = field(default_factory=ButtonSettings)
    poll_interval_s: float = 0.15


@dataclass
class GitSettings:
    repo_url: str = "git@bitbucket.org:mobase-rnd/dtp-can.git"
    commit_message: str = "Updated Reports"
    branch_levels: List[str] = field(
        default_factory=lambda: ["Employee", "Variant", "Type", "Stage", "Date"]
    )
    user_name: Optional[str] = None
    user_email: Optional[str] = None


@dataclass
class SshSettings:
    enabled: bool = True
    ssh_dir: str = "~/.ssh"
    key_name: str = "diagtestpi_bitbucket"
    # Additional places to look for the private key when it is not yet in
    # ``ssh_dir`` (``{base_dir}`` is replaced with the application folder).
    key_search_paths: List[str] = field(
        default_factory=lambda: ["{base_dir}/credentials"]
    )
    known_host: str = "bitbucket.org"


@dataclass
class CanInitSettings:
    channel: str = "can0"
    bitrate: int = 1000000
    dbitrate: int = 8000000
    restart_ms: int = 1000
    txqueuelen: int = 65536


@dataclass
class HardwareSettings:
    enabled: bool = True
    boot_config: str = "/boot/firmware/config.txt"
    enable_spi: bool = True
    enable_i2c: bool = True
    canfd_overlays: List[str] = field(
        default_factory=lambda: [
            "dtoverlay=mcp251xfd, spi0-0, interrupt=25",
            "dtoverlay=mcp251xfd, spi1-0, interrupt=24",
        ]
    )
    can_init: CanInitSettings = field(default_factory=CanInitSettings)
    reboot_when_required: bool = True


@dataclass
class WifiSettings:
    enabled: bool = True
    monitor_interval_s: float = 10.0
    connect_wait_s: int = 15


@dataclass
class DiagnosticsSettings:
    udp_check_retries: int = 3
    can_ready_timeout_s: int = 60
    min_free_disk_mb: int = 50


@dataclass
class ServiceSettings:
    install: bool = True
    name: str = "uds.service"
    description: str = "UDS Diagnostics"


@dataclass
class ReportSettings:
    app_version: str = "DTP-CAN Diagnostic Application V6.2.1"


DEFAULT_MENU = ["ecu_info", "run_tests", "shutdown", "push_reports"]
DEFAULT_STARTUP = [
    "gpio_cleanup",
    "hardware_interfaces",
    "ssh_setup",
    "user_interface",
    "wifi_setup",
    "wifi_monitor",
    "test_session",
    "diagnostics",
    "can_readiness",
    "usb_storage",
    "service_install",
]


@dataclass
class AppSettings:
    ui: UiSettings = field(default_factory=UiSettings)
    git: GitSettings = field(default_factory=GitSettings)
    ssh: SshSettings = field(default_factory=SshSettings)
    hardware: HardwareSettings = field(default_factory=HardwareSettings)
    wifi: WifiSettings = field(default_factory=WifiSettings)
    diagnostics: DiagnosticsSettings = field(default_factory=DiagnosticsSettings)
    service: ServiceSettings = field(default_factory=ServiceSettings)
    report: ReportSettings = field(default_factory=ReportSettings)
    menu: List[str] = field(default_factory=lambda: list(DEFAULT_MENU))
    startup: List[str] = field(default_factory=lambda: list(DEFAULT_STARTUP))
    # Free-form section for third-party feature modules.
    extensions: Dict[str, Any] = field(default_factory=dict)


def _apply(target: Any, overrides: Mapping[str, Any], path: str = "") -> None:
    """Recursively apply a JSON mapping onto a dataclass instance."""
    known = {f.name: f for f in fields(target)}
    for key, value in overrides.items():
        dotted = f"{path}{key}"
        if key not in known:
            logging.warning("Unknown setting ignored: %s", dotted)
            continue
        current = getattr(target, key)
        if is_dataclass(current):
            if not isinstance(value, Mapping):
                raise ConfigError(f"Setting '{dotted}' must be an object")
            _apply(current, value, dotted + ".")
        else:
            setattr(target, key, copy.deepcopy(value))


def resolve_ui_mode(requested: str) -> str:
    requested = (requested or "auto").strip().lower()
    if requested in {"oled", "hardware"}:
        return "hardware"
    if requested in {"terminal", "console"}:
        return "terminal"
    return "auto"


def load_settings(
    base_dir: str,
    environ: Optional[Mapping[str, str]] = None,
    path: Optional[str] = None,
) -> AppSettings:
    environ = os.environ if environ is None else environ
    settings = AppSettings()
    path = path or environ.get("DTP_SETTINGS") or os.path.join(base_dir, SETTINGS_FILENAME)

    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except json.JSONDecodeError as exc:
            raise ConfigError(f"Invalid JSON format in:\n{path}\n\n{exc}") from exc
        if not isinstance(data, Mapping):
            raise ConfigError(f"{path} must contain a JSON object")
        _apply(settings, data)
        logging.info("Application settings loaded from %s", path)
    else:
        logging.info("No %s found - using built-in defaults", SETTINGS_FILENAME)

    if "DTP_UI_MODE" in environ:
        settings.ui.mode = environ["DTP_UI_MODE"]
    settings.ui.mode = resolve_ui_mode(settings.ui.mode)
    return settings
