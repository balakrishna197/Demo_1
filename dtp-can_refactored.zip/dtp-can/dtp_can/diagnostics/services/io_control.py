"""0x2F InputOutputControlByIdentifier."""

from __future__ import annotations

import logging

from dtp_can.diagnostics.services.base import ServiceHandler, StepContext


class InputOutputControlHandler(ServiceHandler):
    service_id = 0x2F
    name = "InputOutputControlByIdentifier"

    def execute(self, ctx: StepContext):
        step = ctx.step
        try:
            if not step.subfunction:
                self.send_bare(ctx)
                return
            did = int(step.subfunction, 16)
            control_type_val = step.control_type.strip()
            control_type = int(control_type_val, 16) if control_type_val else 0x00
            raw_request = bytes([0x2F, (did >> 8) & 0xFF, did & 0xFF, control_type])
            if step.write_data:
                raw_request += bytes.fromhex(step.write_data.strip())
            logging.info(f"{ctx.tc_id} - {ctx.desc}: Sending raw request {raw_request.hex().upper()}")
            ctx.send(raw_request)
        except Exception as e:
            logging.error(f"{ctx.tc_id} - Error handling 0x2F: {e}")
