"""DTC services: 0x19 ReadDTCInformation, 0x14 ClearDiagnosticInformation,
0x85 ControlDTCSetting."""

from __future__ import annotations

import logging

from dtp_can.core.hexutil import hex_field_to_bytes, is_hex, parse_hex_byte_list
from dtp_can.diagnostics.services.base import ServiceHandler, StepContext


class ReadDtcInformationHandler(ServiceHandler):
    service_id = 0x19
    name = "ReadDTCInformation"

    def execute(self, ctx: StepContext):
        step = ctx.step
        raw_request = (
            bytes([0x19])
            + hex_field_to_bytes(step.subfunction)
            + hex_field_to_bytes(step.status_mask)
            + hex_field_to_bytes(step.write_data)
        )
        logging.info(f"{ctx.tc_id} - {ctx.desc}: Sending {raw_request.hex().upper()}")
        response = ctx.send(raw_request, expected_bytes=ctx.expected_bytes)
        if response:
            ctx.verify(response)
        else:
            logging.warning(f"{ctx.tc_id} - No response received")


class ClearDtcHandler(ServiceHandler):
    service_id = 0x14
    name = "ClearDiagnosticInformation"

    def execute(self, ctx: StepContext):
        subfunc = ctx.step.subfunction
        if subfunc != "":
            clean = (
                subfunc.strip().replace("0x", "").replace("0X", "").replace(",", " ")
                .replace("  ", " ").replace(" ", "")
            )
            if not is_hex(clean):
                raise ValueError(f"Invalid hex in subfunction: {subfunc}")
            if len(clean) % 2 != 0:
                clean = "0" + clean
            raw_request = bytes([0x14]) + bytes.fromhex(clean)
            logging.info(f"{ctx.tc_id} - {ctx.desc}: Sending {raw_request.hex().upper()}")
            response = ctx.send(raw_request, expected_bytes=ctx.expected_bytes)
            if response:
                ctx.verify(response)
            else:
                logging.warning(f"{ctx.tc_id} - No response received")
            return

        raw_request = bytearray([0x14])
        logging.info(f"{ctx.tc_id} - {ctx.desc}: Sending {raw_request.hex().upper()}")
        response = ctx.send(raw_request, expected_bytes=ctx.expected_bytes)
        if response:
            ctx.log_received(response)
            ctx.verify(response)
        else:
            logging.warning(f"{ctx.tc_id} - No response received")


class ControlDtcSettingHandler(ServiceHandler):
    service_id = 0x85
    name = "ControlDTCSetting"

    def execute(self, ctx: StepContext):
        tc_id, desc, expected = ctx.tc_id, ctx.desc, ctx.step.expected
        try:
            raw_request = (
                bytes([0x85])
                + hex_field_to_bytes(ctx.step.subfunction)
                + hex_field_to_bytes(ctx.step.write_data)
            )
            logging.info(f"{tc_id} - {desc}: Sending {raw_request.hex().upper()}")
            response = ctx.send(raw_request, post_wait=0.05)
            if response:
                ctx.log_received(response)
                if expected:
                    expected_bytes = parse_hex_byte_list(expected)
                    if response[: len(expected_bytes)] == bytes(expected_bytes):
                        logging.info(f"{tc_id} - {desc} -> PASS")
                    else:
                        logging.warning(f"{tc_id} - {desc} -> FAIL - Response mismatch")
                else:
                    logging.info(f"{tc_id} - No expected response to validate")
            else:
                logging.warning(f"{tc_id} - No response received")
        except ValueError as ve:
            logging.error(f"{tc_id} - Invalid hex in 0x85 request fields: {ve}")
        except Exception as e:
            logging.error(f"{tc_id} - Exception: {type(e).__name__} - {e}")
