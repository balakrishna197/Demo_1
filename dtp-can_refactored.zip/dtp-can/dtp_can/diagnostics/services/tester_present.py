"""0x3E TesterPresent."""

from __future__ import annotations

import logging

from dtp_can.diagnostics.services.base import ServiceHandler, StepContext


class TesterPresentHandler(ServiceHandler):
    service_id = 0x3E
    name = "TesterPresent"

    def execute(self, ctx: StepContext):
        if ctx.step.subfunction == "":
            # V6.2.1 sent nothing for an empty 0x3E sub-function; kept as is.
            logging.warning(f"{ctx.tc_id} - 0x3E without sub-function: nothing sent")
            return
        ctx.send(bytes([0x3E, int(ctx.step.subfunction, 16)]))
