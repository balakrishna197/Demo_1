"""Service handler contract.

A *service handler* turns one TXT testcase row into on-bus UDS traffic for a
single service identifier (SID).  Handlers are registered in a
``ServiceRegistry``; the test runner never contains per-SID logic.

Error policy (kept from V6.2.1): an exception that escapes ``execute`` marks
the step ``Fail`` on the live display; handlers that swallowed errors in the
original implementation still swallow them (they only log).  The report's
verdict is always derived from the ASC log, independently of this.
"""

from __future__ import annotations

import abc
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from dtp_can.core.models import TestStep
from dtp_can.diagnostics.live_verify import verify_response


@dataclass
class StepOutcome:
    """Optional signals a handler can return to the runner."""

    skip_post_step_delay: bool = False


@dataclass
class StepContext:
    step: TestStep
    sid: int
    expected_bytes: List[int]
    write_bytes: List[int]
    client: Any
    transport: Any  # UdsTransport (duck-typed for testability)
    display: Any = None
    state: Dict[str, Any] = field(default_factory=dict)  # survives across steps
    seed_key: Any = None  # SeedKeyProvider
    sleep: Callable[[float], None] = time.sleep

    # -- convenience -----------------------------------------------------
    @property
    def tc_id(self) -> str:
        return self.step.tc_id

    @property
    def desc(self) -> str:
        return self.step.description

    def send(self, raw_request, post_wait: float = 0.0, expected_bytes=None):
        return self.transport.send_request_and_wait(
            self.client,
            raw_request,
            self.tc_id,
            self.desc,
            post_wait=post_wait,
            expected_bytes=expected_bytes,
        )

    def show(self, message: str, delay: float = 1.5) -> None:
        """Display + console echo + optional pause (V6.2.1 ``oled_show``)."""
        if self.display:
            self.display.display_centered_text(message)
        print(message)
        self.sleep(delay)

    def display_text(self, message: str) -> None:
        if self.display:
            self.display.display_centered_text(message)

    def verify(self, response) -> tuple:
        return verify_response(list(response), self.expected_bytes, self.tc_id, self.desc)

    def log_received(self, response) -> None:
        logging.info(f"{self.tc_id} - Received: {response.hex().upper()}")


class ServiceHandler(abc.ABC):
    """Implement ``execute`` and set ``service_id``; register in a registry."""

    service_id: int = -1
    name: str = ""

    @abc.abstractmethod
    def execute(self, ctx: StepContext) -> Optional[StepOutcome]:
        ...

    # Shared helper: "service byte only" request (empty sub-function column).
    @staticmethod
    def send_bare(ctx: StepContext):
        return ctx.send(bytes([ctx.sid]))

    def __repr__(self) -> str:
        return f"<{type(self).__name__} sid=0x{self.service_id:02X}>"
