"""Fallback handlers used when no SID-specific handler exists."""

from __future__ import annotations

import logging

from dtp_can.diagnostics.services.base import ServiceHandler, StepContext


class BareServiceHandler(ServiceHandler):
    """Empty sub-function column: send ``[SID]`` only (negative tests)."""

    name = "bare"

    def execute(self, ctx: StepContext):
        self.send_bare(ctx)


class UnsupportedServiceHandler(ServiceHandler):
    """No handler for the SID: nothing is transmitted (V6.2.1 behaviour)."""

    name = "unsupported"

    def execute(self, ctx: StepContext):
        logging.warning(
            "%s - %s: no handler registered for service 0x%02X; step not sent",
            ctx.tc_id,
            ctx.desc,
            ctx.sid,
        )
