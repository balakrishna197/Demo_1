"""0x11 ECUReset."""

from __future__ import annotations

from dtp_can.diagnostics.services.base import ServiceHandler, StepContext


class EcuResetHandler(ServiceHandler):
    service_id = 0x11
    name = "ECUReset"
    HARD_RESET = 0x01
    PRE_SEND_DELAY_S = 0.05
    HARD_RESET_SETTLE_S = 1.0

    def execute(self, ctx: StepContext):
        subfunc = ctx.step.subfunction
        if subfunc == "":
            ctx.sleep(self.PRE_SEND_DELAY_S)
            self.send_bare(ctx)
            return
        subfunc_int = int(subfunc, 16)
        raw_request = bytes([0x11, subfunc_int])
        ctx.sleep(self.PRE_SEND_DELAY_S)
        ctx.send(raw_request)
        if subfunc_int == self.HARD_RESET:
            ctx.sleep(self.HARD_RESET_SETTLE_S)
