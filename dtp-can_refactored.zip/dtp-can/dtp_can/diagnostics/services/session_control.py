"""0x10 DiagnosticSessionControl."""

from __future__ import annotations

import logging

from dtp_can.core.hexutil import is_hex
from dtp_can.diagnostics.services.base import ServiceHandler, StepContext


class DiagnosticSessionControlHandler(ServiceHandler):
    service_id = 0x10
    name = "DiagnosticSessionControl"

    def execute(self, ctx: StepContext):
        tc_id, desc, subfunc, expected = ctx.tc_id, ctx.desc, ctx.step.subfunction, ctx.step.expected
        try:
            subfunc_clean = (
                subfunc.strip().replace("0x", "").replace(",", " ").replace("  ", " ").replace(" ", "")
            )
            if subfunc_clean:
                if not is_hex(subfunc_clean):
                    raise ValueError(f"Invalid hex in subfunction: {subfunc_clean}")
                subfunc_bytes = bytes.fromhex(subfunc_clean)
            else:
                subfunc_bytes = b""  # "missing sub-function" negative test

            raw_request = bytearray([0x10]) + subfunc_bytes
            logging.info(f"{tc_id} - {desc}: Sending {raw_request.hex().upper()}")
            if ctx.display:
                ctx.show(f"{tc_id}\nSending", 0)
            response = ctx.send(raw_request)

            if response:
                logging.info(f"{tc_id} - Received: {response.hex().upper()}")
                if expected:
                    expected_bytes = bytes.fromhex(expected.strip().replace(" ", ""))
                    if response.startswith(expected_bytes[: len(response)]):
                        logging.info(f"{tc_id} - {desc} -> PASS")
                    else:
                        logging.warning(f"{tc_id} - {desc} -> FAIL - Unexpected response")
                else:
                    logging.info(f"{tc_id} - {desc} -> PASS (No expected to compare)")
            else:
                logging.warning(f"{tc_id} - No response received")
                ctx.display_text(f"{tc_id}\nNo Response")
        except ValueError as ve:
            logging.error(f"{tc_id} - Hex Error: {ve}")
            if ctx.display:
                ctx.show(f"{tc_id}\nHex Error", 2)
        except Exception as e:
            logging.error(f"{tc_id} - Exception: {type(e).__name__} - {e}")
            ctx.display_text(f"{tc_id}\nError: {str(e)[:16]}")
