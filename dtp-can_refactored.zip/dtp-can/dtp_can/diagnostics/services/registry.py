"""Service-handler registry and plugin loading.

Resolution order for a step (identical to the V6.2.1 if/elif chain):

1. a handler registered for the SID;
2. otherwise, when the sub-function column is empty, ``BareServiceHandler``
   (sends the service byte alone - used for negative tests);
3. otherwise ``UnsupportedServiceHandler`` (nothing is sent; a warning is
   logged and the report later shows "Testcase not observed in ASC log").

Adding a service = subclass ``ServiceHandler`` + ``registry.register(...)``
(or list it under ``extensions.service_handlers`` in app_settings.json).
"""

from __future__ import annotations

import importlib
import logging
from typing import Dict, Iterable, Optional

from dtp_can.core.models import TestStep
from dtp_can.diagnostics.services.base import ServiceHandler
from dtp_can.diagnostics.services.generic import BareServiceHandler, UnsupportedServiceHandler


class ServiceRegistry:
    def __init__(
        self,
        bare: Optional[ServiceHandler] = None,
        unsupported: Optional[ServiceHandler] = None,
    ):
        self._handlers: Dict[int, ServiceHandler] = {}
        self.bare = bare or BareServiceHandler()
        self.unsupported = unsupported or UnsupportedServiceHandler()

    def register(self, handler: ServiceHandler, replace: bool = False) -> None:
        sid = handler.service_id
        if not 0 <= sid <= 0xFF:
            raise ValueError(f"{handler!r} has no valid service_id")
        if sid in self._handlers and not replace:
            raise ValueError(
                f"SID 0x{sid:02X} already handled by {self._handlers[sid]!r}; "
                "pass replace=True to override"
            )
        self._handlers[sid] = handler

    def unregister(self, sid: int) -> None:
        self._handlers.pop(sid, None)

    def get(self, sid: int) -> Optional[ServiceHandler]:
        return self._handlers.get(sid)

    def resolve(self, sid: int, step: TestStep) -> ServiceHandler:
        handler = self._handlers.get(sid)
        if handler is not None:
            return handler
        if step.subfunction == "":
            return self.bare
        return self.unsupported

    @property
    def service_ids(self):
        return sorted(self._handlers)

    def load_plugins(self, dotted_paths: Iterable[str]) -> None:
        """Register handlers given as ``"package.module:ClassName"``."""
        for path in dotted_paths:
            module_name, _, attr = path.partition(":")
            if not attr:
                raise ValueError(f"Invalid handler path '{path}' (expected module:Class)")
            handler_cls = getattr(importlib.import_module(module_name), attr)
            self.register(handler_cls(), replace=True)
            logging.info("Registered service handler plugin %s", path)


def default_registry() -> ServiceRegistry:
    """Registry pre-loaded with every built-in service handler."""
    from dtp_can.diagnostics.services import builtin

    registry = ServiceRegistry()
    for handler in builtin.all_handlers():
        registry.register(handler)
    return registry
