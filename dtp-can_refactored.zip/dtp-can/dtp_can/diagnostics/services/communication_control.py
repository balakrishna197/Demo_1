"""0x28 CommunicationControl."""

from __future__ import annotations

import logging

from dtp_can.core.hexutil import hex_field_to_bytes
from dtp_can.diagnostics.services.base import ServiceHandler, StepContext


class CommunicationControlHandler(ServiceHandler):
    service_id = 0x28
    name = "CommunicationControl"

    def execute(self, ctx: StepContext):
        step = ctx.step
        if step.subfunction == "":
            self.send_bare(ctx)
            return
        try:
            subfunc_bytes = hex_field_to_bytes(step.subfunction)
            communication_type_bytes = hex_field_to_bytes(step.communication_type)
            write_data_bytes = hex_field_to_bytes(step.write_data)
            if not communication_type_bytes and subfunc_bytes:
                # communicationType is mandatory after controlType; V6.2.1
                # re-used the last sub-function byte when the column is empty.
                communication_type_bytes = subfunc_bytes[-1:]
            raw_request = bytes([0x28]) + subfunc_bytes + communication_type_bytes + write_data_bytes
            logging.info(f"{ctx.tc_id} - {ctx.desc}: Sending raw request {raw_request.hex().upper()}")
            ctx.send(raw_request)
        except ValueError as exc:
            logging.error(f"{ctx.tc_id} - Invalid 0x28 request fields: {exc}")
        except Exception as e:
            logging.error(f"{ctx.tc_id} - Error sending CommunicationControl raw request: {e}")
