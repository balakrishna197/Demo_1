"""0x22 ReadDataByIdentifier and 0x2E WriteDataByIdentifier."""

from __future__ import annotations

import logging

from dtp_can.core.hexutil import is_hex, parse_hex_byte_list
from dtp_can.diagnostics.services.base import ServiceHandler, StepContext


class ReadDataByIdentifierHandler(ServiceHandler):
    service_id = 0x22
    name = "ReadDataByIdentifier"

    def execute(self, ctx: StepContext):
        tc_id, desc, subfunc, expected = ctx.tc_id, ctx.desc, ctx.step.subfunction, ctx.step.expected
        try:
            raw_request = bytearray([0x22])
            if subfunc.strip():
                subfunc_clean = subfunc.replace("0x", "").replace(" ", "").strip()
                if not is_hex(subfunc_clean):
                    raise ValueError(f"Invalid hex characters in subfunction: '{subfunc}'")
                if len(subfunc_clean) % 2 != 0:
                    subfunc_clean = "0" + subfunc_clean
                raw_request += bytes.fromhex(subfunc_clean)
            else:
                logging.warning(f"{tc_id} - Subfunction empty: Sending only service byte")

            logging.info(f"{tc_id} - {desc}: Sending request {raw_request.hex().upper()}")
            response = ctx.send(raw_request, post_wait=0.05, expected_bytes=ctx.expected_bytes)

            if response:
                ctx.log_received(response)
                if expected:
                    expected_bytes = parse_hex_byte_list(expected)
                    if response.startswith(bytes(expected_bytes)):
                        logging.info(f"{tc_id} - {desc} -> PASS")
                    else:
                        logging.warning(
                            f"{tc_id} - {desc} -> FAIL - Expected "
                            f"{bytes(expected_bytes).hex().upper()}"
                        )
                else:
                    logging.info(f"{tc_id} - No expected response provided")
            else:
                logging.warning(f"{tc_id} - No response received")
        except ValueError as ve:
            logging.error(f"{tc_id} - Subfunction hex error: {ve}")
            ctx.show(f"{tc_id}\nHex Error", 2)
        except Exception as e:
            logging.error(f"{tc_id} - Unexpected Error: {type(e).__name__} - {e}")
            ctx.display_text(f"{tc_id}\nError: {str(e)[:16]}")


class WriteDataByIdentifierHandler(ServiceHandler):
    service_id = 0x2E
    name = "WriteDataByIdentifier"

    def execute(self, ctx: StepContext):
        did = int(ctx.step.subfunction, 16)
        if not ctx.write_bytes:
            raise ValueError(f"No write data provided in testcase for DID {hex(did)}")
        ctx.send(bytes([0x2E, (did >> 8) & 0xFF, did & 0xFF] + ctx.write_bytes))
