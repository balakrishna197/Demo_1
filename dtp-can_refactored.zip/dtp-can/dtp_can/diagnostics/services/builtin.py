"""Catalogue of the built-in service handlers."""

from __future__ import annotations

from typing import List

from dtp_can.diagnostics.services.base import ServiceHandler
from dtp_can.diagnostics.services.communication_control import CommunicationControlHandler
from dtp_can.diagnostics.services.data_identifier import (
    ReadDataByIdentifierHandler,
    WriteDataByIdentifierHandler,
)
from dtp_can.diagnostics.services.dtc import (
    ClearDtcHandler,
    ControlDtcSettingHandler,
    ReadDtcInformationHandler,
)
from dtp_can.diagnostics.services.ecu_reset import EcuResetHandler
from dtp_can.diagnostics.services.io_control import InputOutputControlHandler
from dtp_can.diagnostics.services.security_access import SecurityAccessHandler
from dtp_can.diagnostics.services.session_control import DiagnosticSessionControlHandler
from dtp_can.diagnostics.services.tester_present import TesterPresentHandler


def all_handlers() -> List[ServiceHandler]:
    return [
        DiagnosticSessionControlHandler(),
        EcuResetHandler(),
        ClearDtcHandler(),
        ReadDtcInformationHandler(),
        ReadDataByIdentifierHandler(),
        SecurityAccessHandler(),
        CommunicationControlHandler(),
        WriteDataByIdentifierHandler(),
        InputOutputControlHandler(),
        TesterPresentHandler(),
        ControlDtcSettingHandler(),
    ]
