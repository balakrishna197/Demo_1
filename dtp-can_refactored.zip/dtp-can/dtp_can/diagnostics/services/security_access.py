"""0x27 SecurityAccess (seed request -> key provider -> key send).

* odd sub-function  : requestSeed. The seed is stored in the run state as
  ``seed_<n>`` and the key obtained from the ``SeedKeyProvider`` is stored as
  ``key_<n+1>``.
* even sub-function : sendKey with the stored ``key_<n>``.
* multi-byte sub-function column: sent verbatim (negative tests).
"""

from __future__ import annotations

import logging

from dtp_can.core.hexutil import hex_field_to_bytes
from dtp_can.diagnostics.services.base import ServiceHandler, StepContext, StepOutcome

POSITIVE_RESPONSE = 0x67
SEED_SETTLE_S = 0.5


class SecurityAccessHandler(ServiceHandler):
    service_id = 0x27
    name = "SecurityAccess"

    def execute(self, ctx: StepContext):
        if ctx.step.subfunction == "":
            self.send_bare(ctx)
            return None
        subfunc_bytes = hex_field_to_bytes(ctx.step.subfunction)
        if len(subfunc_bytes) != 1:
            ctx.send(bytes([0x27]) + subfunc_bytes)
            return None
        level = subfunc_bytes[0]
        if level % 2 == 1:
            self._request_seed(ctx, level)
            return None
        return self._send_key(ctx, level)

    # ------------------------------------------------------------------
    @staticmethod
    def _check_positive(ctx: StepContext, raw_payload, level: int) -> None:
        if raw_payload[0] != POSITIVE_RESPONSE or raw_payload[1] != level:
            failure_reason = f"NRC (key): {raw_payload}"
            logging.warning(f"{ctx.tc_id} {ctx.desc} -> FAIL - {failure_reason}")
            raise Exception(failure_reason)

    def _request_seed(self, ctx: StepContext, level: int) -> None:
        response = ctx.send(bytes([0x27, level]), expected_bytes=ctx.expected_bytes)
        if response is None:
            raise Exception(f"{ctx.tc_id} {ctx.desc} -> No response received")
        if not isinstance(response, bytes):
            raise Exception(f"{ctx.tc_id} {ctx.desc} -> No valid response received")
        raw_payload = list(response)
        logging.debug(f"{ctx.tc_id} {ctx.desc} -> Received payload: {raw_payload}")
        status, failure_reason = ctx.verify(response)
        if status != "Pass" and raw_payload and raw_payload[0] == 0x7F:
            logging.warning(f"{ctx.tc_id} {ctx.desc} -> FAIL - {failure_reason}")
            raise Exception(failure_reason)
        self._check_positive(ctx, raw_payload, level)

        seed = bytes(raw_payload[2:])
        ctx.state[f"seed_{level}"] = seed
        logging.info(f"Received Seed (subfunc {hex(level)}): {seed.hex()}")
        ctx.sleep(SEED_SETTLE_S)

        provider = ctx.seed_key
        if provider is None:
            raise Exception("No seed/key provider configured")
        if not provider.available:
            logging.warning("UDP server unavailable. Rechecking...")
            if provider.check_server():
                logging.info("UDP server reconnected.")
                provider.available = True
            else:
                logging.error("UDP server still unavailable.")
                if ctx.display:
                    ctx.display_text("UDP Server\nUnavailable")
                    ctx.sleep(2)
                raise Exception("UDP Server not available")
        key = provider.request_key(seed)
        ctx.state[f"key_{level + 1}"] = key
        logging.info(f"Received Key (for subfunc {hex(level + 1)}): {key}")

    def _send_key(self, ctx: StepContext, level: int):
        key = ctx.state.get(f"key_{level}")
        if key:
            raw_request = bytes([0x27, level]) + key
        else:
            logging.info(
                f"No key available for subfunction {hex(level)}. "
                "Ensure seed request precedes key send."
            )
            raw_request = bytes([0x27, level])
        response = ctx.send(raw_request, expected_bytes=ctx.expected_bytes)
        if not isinstance(response, bytes):
            raise Exception("No valid response received for key request")
        raw_payload = list(response)
        logging.debug(f"{ctx.tc_id} {ctx.desc} -> Received payload: {raw_payload}")
        status, _reason = ctx.verify(response)
        if status == "Pass":
            # V6.2.1 skipped the post-step delay/status screen here.
            return StepOutcome(skip_post_step_delay=True)
        self._check_positive(ctx, raw_payload, level)
        return None
