"""On-the-fly response check used while a test runs.

Only used for console/log feedback and for the SecurityAccess flow; the
authoritative verdict in the report is computed offline from the ASC log
(see ``dtp_can.reporting.verdict``).
"""

from __future__ import annotations

import logging
from typing import List, Tuple

from dtp_can.core import isotp_frames as tp
from dtp_can.core.hexutil import trim_trailing

_PADDING = (0x00, 0xAA, 0x20)
_RULE = "-" * 47


def _normalize_payload(payload) -> List[int]:
    data = [int(b) for b in (payload or [])]
    if not data:
        return []
    pci = data[0]
    ftype = tp.frame_type(pci)
    if ftype == tp.SINGLE_FRAME:
        return data[1:1 + (pci & 0x0F)]
    if ftype == tp.FIRST_FRAME and len(data) >= 2:
        return data[2:2 + tp.first_frame_length(pci, data[1])]
    return trim_trailing(data, _PADDING)


def _compare_variants(payload) -> List[List[int]]:
    raw = [int(b) for b in (payload or [])]
    variants: List[List[int]] = []
    for candidate in (raw, _normalize_payload(raw)):
        for value in (candidate, trim_trailing(candidate, _PADDING)):
            if value and value not in variants:
                variants.append(value)
    return variants


def verify_response(raw_payload, expected_bytes, tc_id, step_desc) -> Tuple[str, str]:
    status, failure_reason = "Fail", "-"
    try:
        actual_variants = _compare_variants(raw_payload)
        expected_variants = _compare_variants(expected_bytes)
        if any(a == e for a in actual_variants for e in expected_variants):
            logging.info(f"{_RULE}{tc_id} {step_desc} -> PASS{_RULE}")
            return "Pass", failure_reason

        actual = _normalize_payload(raw_payload)
        expected = _normalize_payload(expected_bytes)
        if not actual:
            failure_reason = "No response received"
            logging.warning(f"{_RULE}{tc_id} {step_desc} -> FAIL - {failure_reason}{_RULE}")
            return status, failure_reason

        expected_first = expected[0] if expected else expected_bytes[0]
        actual_first = actual[0]
        if expected_first == 0x7F:
            if actual_first == 0x7F:
                nrc = actual[2] if len(actual) >= 3 else None
                if len(expected) == 1:
                    status = "Pass"
                    logging.info(
                        f"{tc_id} {step_desc} -> PASS (any NRC accepted because only 0x7F given)"
                    )
                elif len(expected) == 3:
                    if nrc == expected[-1]:
                        status = "Pass"
                        logging.info(f"{_RULE}{tc_id} {step_desc} -> PASS{_RULE}")
                    else:
                        failure_reason = (
                            f"Expected NRC {hex(expected[-1])}, "
                            f"got {hex(nrc) if nrc is not None else 'Unknown'}"
                        )
                        logging.warning(
                            f"{_RULE}{tc_id} {step_desc} -> FAIL - {failure_reason}{_RULE}"
                        )
                else:
                    failure_reason = (
                        f"Malformed expected bytes for negative response: {expected}"
                    )
                    logging.error(f"{_RULE}{tc_id} {step_desc} -> FAIL - {failure_reason}{_RULE}")
            else:
                failure_reason = (
                    "Expected Negative Response (0x7F), but got Positive Response: "
                    f"{raw_payload}"
                )
                logging.warning(f"{_RULE}{tc_id} {step_desc} -> FAIL - {failure_reason}{_RULE}")
        else:
            if actual_first != 0x7F:
                if actual[: len(expected)] == expected:
                    status = "Pass"
                    logging.info(f"{tc_id} {step_desc} -> PASS")
                else:
                    failure_reason = f"Expected {expected}, got {actual[:len(expected)]}"
                    logging.warning(
                        f"{_RULE}{tc_id} {step_desc} -> FAIL - {failure_reason}{_RULE}"
                    )
            else:
                nrc = actual[2] if len(actual) >= 3 else None
                failure_reason = (
                    "Expected Positive Response, but got NRC: "
                    f"{hex(nrc) if nrc is not None else 'Unknown'}"
                )
                logging.warning(f"{_RULE}{tc_id} {step_desc} -> FAIL - {failure_reason}{_RULE}")
    except Exception as e:
        failure_reason = str(e)
        logging.error(f"{_RULE}{tc_id} {step_desc} -> EXCEPTION - {failure_reason}{_RULE}")
    return status, failure_reason
