"""ASC (Vector format) CAN traffic recorder."""

from __future__ import annotations

import logging
import os
from datetime import datetime
from typing import Callable, Optional

import can
from can.io.asc import ASCWriter


def _default_bus_factory(**kwargs):
    return can.interface.Bus(**kwargs)


class CanLogger:
    def __init__(
        self,
        channel: str = "can0",
        interface: str = "socketcan",
        can_fd: bool = True,
        filters=None,
        log_dir: Optional[str] = None,
        bus_factory: Callable[..., can.BusABC] = _default_bus_factory,
    ):
        self.channel = channel
        self.interface = interface
        self.can_fd = can_fd
        self.log_dir = log_dir
        self.filters = filters
        self._bus_factory = bus_factory
        self.bus = None
        self.notifier = None
        self.writer = None
        self.file = None
        self.log_path: Optional[str] = None

    @property
    def is_running(self) -> bool:
        return self.notifier is not None

    def _open_bus(self):
        bus_kwargs = {
            "channel": self.channel,
            "interface": self.interface,
            "can_filters": self.filters,
            "fd": self.can_fd,
        }
        # Request own messages so tester frames are always captured, even if
        # the interface's loop-back defaults change.
        try:
            return self._bus_factory(**bus_kwargs, receive_own_messages=True)
        except TypeError:
            logging.warning(
                "[CANLogger] Backend does not support receive_own_messages; "
                "falling back to default bus creation"
            )
            return self._bus_factory(**bus_kwargs)

    def start(self, filename: Optional[str] = None) -> None:
        if self.notifier or self.writer:
            self.stop()
        if self.log_dir is None:
            raise ValueError("log_dir must be provided before starting CAN logging")
        os.makedirs(self.log_dir, exist_ok=True)
        if filename is None:
            filename = f"can_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.asc"
        self.log_path = os.path.join(self.log_dir, filename)
        try:
            self.file = open(self.log_path, "w", buffering=1, encoding="utf-8", newline="")
            self.bus = self._open_bus()
            self.writer = ASCWriter(self.file)
            self.notifier = can.Notifier(self.bus, [self.writer])
            self.file.flush()
            logging.info(f"CAN logging started: {self.log_path}")
        except Exception as e:
            logging.error(f"[CANLogger] Failed to start: {e}")

    def stop(self) -> None:
        """Stop logging and release the bus.

        BUGFIX (B-03): ``ASCWriter.stop()`` already writes the ASC footer and
        closes the file.  V6.2.1 then wrote to the closed file, the resulting
        exception skipped ``bus.shutdown()`` and leaked one CAN socket per
        test run.  The file content is unchanged by this fix.
        """
        try:
            if self.notifier:
                self.notifier.stop()
                self.notifier = None
            if self.writer:
                self.writer.stop()
                self.writer = None
            if self.file and not self.file.closed:
                self.file.flush()
                os.fsync(self.file.fileno())
                self.file.close()
            self.file = None
        except Exception as e:
            logging.error(f"[CANLogger] Error during stop: {e}")
        finally:
            if self.bus:
                try:
                    self.bus.shutdown()
                except Exception as exc:
                    logging.warning(f"[CANLogger] Bus shutdown warning: {exc}")
            self.bus = None
        logging.info(f"CAN logging stopped: {self.log_path}")

    def get_log_path(self) -> Optional[str]:
        return self.log_path
