"""Test execution lifecycle (replaces ``UDSClient.run_testcase``).

Responsibilities: storage check -> ECU preparation -> CAN logging -> walk
the TXT sequence (WAIT rows, addressing switch, per-step display/delay) ->
stop logging -> hand the ASC log to the configured ``ReportGenerator``.

Per-service request building lives in ``diagnostics.services``; this class
only resolves the handler for each step from the registry.
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, List, Optional

from dtp_can.config.uds_config import UdsConfig
from dtp_can.core.disk import check_disk_space
from dtp_can.core.hexutil import parse_hex_byte_list
from dtp_can.core.models import TestStep, WaitStep
from dtp_can.diagnostics.services.base import StepContext, StepOutcome
from dtp_can.diagnostics.services.registry import ServiceRegistry
from dtp_can.reporting.generator import ReportGenerator, ReportRequest
from dtp_can.testcases.parser import load_testcase_sequence

_BANNER = "-" * 34


@dataclass
class ReportContext:
    """Where reports go and which source revision they describe."""

    repo_path: Optional[str] = None
    branch_name: str = "N/A"
    branch_url: str = ""


@dataclass
class StepResult:
    tc_id: str
    description: str
    status: str
    failure_reason: str


@dataclass
class RunResult:
    testcase_file: str
    can_log: Optional[str] = None
    report: Optional[str] = None
    steps: List[StepResult] = field(default_factory=list)
    aborted: Optional[str] = None


class TestRunner:
    __test__ = False  # not a pytest test class

    def __init__(
        self,
        config: UdsConfig,
        transport: Any,
        can_logger: Any,
        registry: ServiceRegistry,
        workspace: Any,
        report_generator: ReportGenerator,
        seed_key: Any = None,
        report_context: Optional[ReportContext] = None,
        min_free_disk_mb: int = 50,
        sleep: Callable[[float], None] = time.sleep,
        now: Callable[[], datetime] = datetime.now,
        disk_probe: Callable[..., Any] = check_disk_space,
    ):
        self.config = config
        self.transport = transport
        self.can_logger = can_logger
        self.registry = registry
        self.workspace = workspace
        self.report_generator = report_generator
        self.seed_key = seed_key
        self.report_context = report_context or ReportContext()
        self.min_free_disk_mb = min_free_disk_mb
        self._sleep = sleep
        self._now = now
        self._disk_probe = disk_probe
        self.state: dict = {}
        self._first_request_pending = True

    # ------------------------------------------------------------------
    def check_storage(self, display) -> bool:
        enough, free_mb = self._disk_probe(min_required_mb=self.min_free_disk_mb)
        if not enough:
            warning = f"Low Storage!\nOnly {free_mb}MB left.\nNeed {self.min_free_disk_mb}MB."
            display.display_centered_text(warning)
            logging.warning(warning)
            self._sleep(4)
            return False
        logging.info(f"{_BANNER}Storage OK Free: {free_mb} MB{_BANNER}")
        self._sleep(2)
        return True

    def _wait(self, display, step: WaitStep) -> None:
        wait_ms = step.duration_ms
        wait_sec = wait_ms / 1000
        logging.info(f"WAIT {wait_ms} ms")
        if wait_sec >= 1:
            remaining = int(wait_sec)
            while remaining > 0:
                message = f"Waiting...\n{remaining} sec"
                display.display_centered_text(message)
                print(message)
                self._sleep(1)
                remaining -= 1
        else:
            message = f"Waiting...\n{wait_ms} ms"
            display.display_centered_text(message)
            print(message)
            self._sleep(wait_sec)

    def _execute_step(self, display, step: TestStep):
        """Run one step; returns (status, failure_reason, outcome)."""
        status, failure_reason, outcome = "Pass", "-", None
        try:
            self.transport.switch_mode(step.addressing)
            if self._first_request_pending:
                try:
                    self.transport.drain(self.transport.active_conn)
                    logging.info(f"Final CAN drain completed before first testcase {step.tc_id}")
                except Exception as exc:
                    logging.warning(f"Failed final drain before first testcase {step.tc_id}: {exc}")
            if self.transport.active_conn is None:
                raise RuntimeError(f"No active connection for {step.addressing} addressing")

            with self.transport.open_client() as client:
                logging.info(
                    f"Switched to {step.addressing} mode for TC: {step.tc_id} "
                    f"Step: {step.description}"
                )
                sid = int(step.service, 16)
                expected_bytes = parse_hex_byte_list(step.expected)
                write_bytes = parse_hex_byte_list(step.write_data) if step.write_data else []
                logging.info(
                    f"{step.tc_id} - {step.description}: SID={step.service}, "
                    f"Sub={step.subfunction}, Expected={expected_bytes}"
                )
                ctx = StepContext(
                    step=step,
                    sid=sid,
                    expected_bytes=expected_bytes,
                    write_bytes=write_bytes,
                    client=client,
                    transport=self.transport,
                    display=display,
                    state=self.state,
                    seed_key=self.seed_key,
                    sleep=self._sleep,
                )
                ctx.show(f"{step.tc_id}\n{step.description}", 0)
                self._first_request_pending = False
                handler = self.registry.resolve(sid, step)
                outcome = handler.execute(ctx)
        except Exception as e:
            status, failure_reason = "Fail", str(e)
            logging.error(
                f"{_BANNER}{step.tc_id} {step.description} -> EXCEPTION - {failure_reason}{_BANNER}"
            )
        return status, failure_reason, outcome

    def _post_step(self, display, step: TestStep, status: str, failure_reason: str) -> None:
        try:
            if not self.config.immediate_mode:
                delay = self.config.step_delay_for(step.service)
                display.display_centered_text(f"{step.tc_id}\n{step.description[:20]}\n{status}")
                self._sleep(delay)
        except Exception:
            logging.error(
                f"{_BANNER}{step.tc_id} {step.description} -> FAIL - {failure_reason}{_BANNER}"
            )

    # ------------------------------------------------------------------
    def run(self, display, tester_name: str = "N/A") -> RunResult:
        if not self.check_storage(display):
            return RunResult(testcase_file="", aborted="low storage")
        testcase_file = self.workspace.active_testcase()
        result = RunResult(testcase_file=testcase_file)

        base_name = os.path.splitext(os.path.basename(testcase_file))[0]
        timestamp = self._now().strftime("%Y%m%d_%H%M%S")
        self.transport.prepare_ecu_before_logged_run()
        self.can_logger.start(filename=f"{base_name}_{timestamp}.asc")
        self.transport.prepare_execution_start()

        self.state = {}
        self._first_request_pending = True
        for step in load_testcase_sequence(testcase_file):
            if isinstance(step, WaitStep) or step[0] == "WAIT":
                self._wait(display, step)
                continue
            if len(step) != 11:
                logging.warning(
                    "Skipping malformed testcase step with %d fields: %r", len(step), step
                )
                continue
            print("\n")
            logging.info(f"Running Test Case: {step.tc_id}")
            status, reason, outcome = self._execute_step(display, step)
            result.steps.append(StepResult(step.tc_id, step.description, status, reason))
            if isinstance(outcome, StepOutcome) and outcome.skip_post_step_delay:
                continue
            self._post_step(display, step, status, reason)

        result.can_log = self._finish_logging(display)
        if result.can_log is None:
            return result
        result.report = self._generate_report(
            display, testcase_file, base_name, timestamp, result.can_log, tester_name
        )
        return result

    def _finish_logging(self, display) -> Optional[str]:
        self.can_logger.stop()
        self._sleep(1.5)
        full_log_path = self.can_logger.get_log_path() or "N/A"
        if not os.path.isfile(full_log_path):
            logging.error(f"File not found after logging stopped: {full_log_path}")
            display.display_centered_text("Log Error!\nFile Missing.")
            return None
        logging.info(f"{_BANNER}Log Generated!{_BANNER}")
        self._sleep(2)
        return full_log_path

    def _generate_report(self, display, testcase_file, base_name, timestamp, can_log, tester_name):
        repo_path = self.report_context.repo_path
        repo_path = repo_path if isinstance(repo_path, str) else os.getcwd()
        report_dir = os.path.join(repo_path, "output", "html_reports")
        os.makedirs(report_dir, exist_ok=True)
        report_path = os.path.join(report_dir, f"{base_name}_{timestamp}.html")
        self.report_generator.generate(
            ReportRequest(
                asc_file_path=can_log,
                txt_file_path=testcase_file,
                output_html_file=report_path,
                allowed_tx_ids=self.config.allowed_tx_ids,
                allowed_rx_ids=self.config.allowed_rx_ids,
                ecu_info_data={},
                target_ecu=self.config.target_ecu,
                ecu_info_field_map=self.config.info_dids,
                tester_name=tester_name,
                input_json_file=self.config.path,
                test_start_time=self.transport.clock.start,
                test_end_time=self.transport.clock.end,
                branch_name=self.report_context.branch_name,
                branch_url=self.report_context.branch_url,
            )
        )
        display.display_centered_text("Report Generated")
        logging.info(f"{_BANNER}Report Generated{_BANNER}")
        self._sleep(2)
        return report_path
