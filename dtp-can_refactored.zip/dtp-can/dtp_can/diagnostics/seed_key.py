"""Security-access key providers (port + UDP implementation).

V6.2.1 talked to the PC key-generation server directly from the 0x27
branch of ``run_testcase``.  The protocol is unchanged: the seed is sent as
an ASCII hex string in one UDP datagram and the raw key bytes come back.
"""

from __future__ import annotations

import abc
import logging
import socket
import time
from typing import Callable

from dtp_can.core.errors import SeedKeyError


class SeedKeyProvider(abc.ABC):
    """Port: compute/obtain the SecurityAccess key for a seed."""

    available: bool = True

    @abc.abstractmethod
    def check_server(self) -> bool:
        """Health check; returns True when keys can be obtained."""

    @abc.abstractmethod
    def request_key(self, seed: bytes) -> bytes:
        """Return the key for ``seed`` or raise ``SeedKeyError``."""


class UdpSeedKeyProvider(SeedKeyProvider):
    PROBE_SEED = "01020304"

    def __init__(
        self,
        ip: str,
        port: int,
        expected_key_length: int,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        timeout: float = 5.0,
        probe_timeout: float = 2.0,
        socket_factory: Callable[[], socket.socket] = lambda: socket.socket(
            socket.AF_INET, socket.SOCK_DGRAM
        ),
        sleep: Callable[[float], None] = time.sleep,
    ):
        self.ip = ip
        self.port = port
        self.expected_key_length = expected_key_length
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.timeout = timeout
        self.probe_timeout = probe_timeout
        self._socket_factory = socket_factory
        self._sleep = sleep
        self.available = True

    def check_server(self) -> bool:
        sock = self._socket_factory()
        sock.settimeout(self.probe_timeout)
        try:
            logging.info("Checking UDP Seed-Key server...")
            sock.sendto(self.PROBE_SEED.encode(), (self.ip, self.port))
            key, _ = sock.recvfrom(1024)
            if key:
                logging.info(f"UDP Server Connected. Key received: {key.hex()}")
                return True
            logging.warning("UDP Server returned empty response.")
            return False
        except socket.timeout:
            logging.error("UDP Server Timeout")
            return False
        except Exception as e:
            logging.error(f"UDP Server Error: {e}")
            return False
        finally:
            sock.close()

    def request_key(self, seed: bytes) -> bytes:
        sock = self._socket_factory()
        sock.settimeout(self.timeout)
        try:
            for attempt in range(1, self.max_retries + 1):
                try:
                    logging.info(f"Attempt {attempt}: Sending seed to PC...")
                    sock.sendto(seed.hex().encode(), (self.ip, self.port))
                    key, _ = sock.recvfrom(1024)
                    key = key.strip()
                    if not key:
                        raise SeedKeyError("Empty key received from UDP server")
                    if len(key) != self.expected_key_length:
                        raise SeedKeyError(
                            f"Invalid key length. Expected {self.expected_key_length}, "
                            f"got {len(key)}"
                        )
                    self.available = True
                    return key
                except socket.timeout:
                    logging.warning(f"Attempt {attempt} - Timeout waiting for key.")
                    if attempt < self.max_retries:
                        self._sleep(self.retry_delay)
                except Exception:
                    self.available = False
                    logging.exception(f"Attempt {attempt} - Error occurred:")
                    raise
            self.available = False
            raise SeedKeyError(
                f"Timeout after {self.max_retries} retries waiting for key from PC"
            )
        finally:
            sock.close()
