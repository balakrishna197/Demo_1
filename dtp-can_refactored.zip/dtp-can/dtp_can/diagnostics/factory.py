"""Builds a complete diagnostics stack from a test configuration.

The only place that knows how transport, logger, seed/key provider,
service registry, runner and ECU-info reader are wired together.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable, Optional

from dtp_can.config.uds_config import UdsConfig
from dtp_can.diagnostics.can_logger import CanLogger
from dtp_can.diagnostics.ecu_info import EcuInfoReader
from dtp_can.diagnostics.runner import ReportContext, TestRunner
from dtp_can.diagnostics.seed_key import SeedKeyProvider, UdpSeedKeyProvider
from dtp_can.diagnostics.services.registry import ServiceRegistry, default_registry
from dtp_can.diagnostics.transport import UdsTransport, _default_bus_factory
from dtp_can.reporting.generator import HtmlReportGenerator, ReportGenerator


@dataclass
class DiagnosticsStack:
    config: UdsConfig
    transport: UdsTransport
    can_logger: CanLogger
    seed_key: SeedKeyProvider
    registry: ServiceRegistry
    runner: TestRunner
    ecu_info: EcuInfoReader

    def close(self) -> None:
        if self.can_logger.is_running:
            self.can_logger.stop()
        self.transport.close()


def build_diagnostics(
    config: UdsConfig,
    workspace: Any,
    can_log_dir: str,
    report_context: Optional[ReportContext] = None,
    report_generator: Optional[ReportGenerator] = None,
    registry: Optional[ServiceRegistry] = None,
    seed_key: Optional[SeedKeyProvider] = None,
    bus_factory: Callable[..., Any] = _default_bus_factory,
    min_free_disk_mb: int = 50,
    sleep: Callable[[float], None] = time.sleep,
) -> DiagnosticsStack:
    transport = UdsTransport(config, bus_factory=bus_factory, sleep=sleep)
    can_logger = CanLogger(
        channel=config.channel,
        interface=config.interface,
        can_fd=config.can_fd,
        log_dir=can_log_dir,
        filters=config.uds_can_filters(),
        bus_factory=bus_factory,
    )
    seed_key = seed_key or UdpSeedKeyProvider(
        config.udp_ip, config.udp_port, config.expected_key_length, sleep=sleep
    )
    registry = registry or default_registry()
    runner = TestRunner(
        config=config,
        transport=transport,
        can_logger=can_logger,
        registry=registry,
        workspace=workspace,
        report_generator=report_generator or HtmlReportGenerator(),
        seed_key=seed_key,
        report_context=report_context,
        min_free_disk_mb=min_free_disk_mb,
        sleep=sleep,
    )
    return DiagnosticsStack(
        config=config,
        transport=transport,
        can_logger=can_logger,
        seed_key=seed_key,
        registry=registry,
        runner=runner,
        ecu_info=EcuInfoReader(config, transport, workspace, sleep=sleep),
    )
