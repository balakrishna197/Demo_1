"""Live "Read ECU Info" (replaces ``UDSClient.get_ecu_information``).

Runs the ``ECU_INFO*`` rows of the active testcase file in extended session
and shows each decoded value on the display.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Callable, Dict, Optional

from dtp_can.config.uds_config import UdsConfig
from dtp_can.core.did_decoder import decode_special_did_value
from dtp_can.testcases.parser import load_testcases

_BANNER = "-" * 34
ECU_INFO_PREFIX = "ECU_INFO"
NO_RESPONSE = "ECU No response"


def _clean_hex(val: str) -> str:
    return val.lower().replace("0x", "").strip()


def decode_value(step_desc: str, raw_data) -> str:
    """Special DID decoding first, then printable ASCII, else hex."""
    hex_str = " ".join(f"{b:02X}" for b in raw_data)
    special_value = decode_special_did_value(step_desc, raw_data)
    if special_value is not None:
        return special_value
    try:
        ascii_str = bytes(raw_data).decode("ascii").strip()
        if all(32 <= ord(c) <= 126 for c in ascii_str):
            return ascii_str
        return hex_str
    except Exception:
        return hex_str


class EcuInfoReader:
    def __init__(
        self,
        config: UdsConfig,
        transport: Any,
        workspace: Any,
        sleep: Callable[[float], None] = time.sleep,
    ):
        self.config = config
        self.transport = transport
        self.workspace = workspace
        self._sleep = sleep

    def read(self, display=None) -> Optional[Dict[str, str]]:
        testcase_file = self.workspace.active_testcase()
        grouped_cases = load_testcases(testcase_file)
        self._sleep(0.5)

        if self.transport.active_conn is None:
            logging.error("ECU information request failed: no active connection")
            if display:
                display.display_centered_text("Connection Error:\nNo active connection")
            return None

        ecu_info: Dict[str, str] = {}
        with self.transport.open_client(use_active_config=False) as client:
            try:
                client.change_session(self.config.default_session)
                self._sleep(0.2)
                client.change_session(self.config.extended_session)
                self._sleep(0.2)
            except Exception as e:
                if display:
                    display.display_centered_text(f"Session Error:\n{e}")
                logging.error(f"Session change failed: {e}")
                return None

            for tc_id, steps in grouped_cases.items():
                if not tc_id.startswith(ECU_INFO_PREFIX):
                    continue
                logging.info(f"[ECU Info] Processing {tc_id}")
                for step in steps:
                    self._read_step(client, step, ecu_info, display)
                    self._sleep(0.1)
        return ecu_info

    def _read_step(self, client, step, ecu_info, display) -> None:
        logging.debug(f"[ECU Info] Step={step}")
        step_desc = "Unknown step"
        try:
            tc_id, step_desc, service, subfunc, expected, *_rest = step
            try:
                service_int = int(_clean_hex(service), 16)
                did = int(_clean_hex(subfunc), 16)
            except ValueError as ve:
                logging.error(
                    f"[ECU Info] Invalid service or subfunc '{subfunc}' in {tc_id} "
                    f"step '{step_desc}': {ve}"
                )
                return
            did_hi, did_lo = (did >> 8) & 0xFF, did & 0xFF
            if service_int == 0x22:
                raw_request = bytes([0x22, did_hi, did_lo])
            else:
                raw_request = bytes([service_int, did])
            logging.info(f"[ECU Info] Sending raw request: {raw_request.hex()}")
            expected_bytes = [int(b, 16) for b in expected.strip().split()]
            response = self.transport.send_request_and_wait(
                client, raw_request, tc_id, step_desc, expected_bytes=expected_bytes
            )
            if not response:
                raise Exception("No response received")
            raw_payload = list(response)
            logging.debug(f"[ECU Info] Received raw payload: {raw_payload}")
            if service_int == 0x22:
                if raw_payload[0] != 0x62:
                    raise Exception(f"Unexpected response: {raw_payload}")
                if raw_payload[1] != did_hi or raw_payload[2] != did_lo:
                    raise Exception(f"DID mismatch: {raw_payload}")
                raw_data = raw_payload[3:]
            else:
                raw_data = raw_payload[1:]

            display_value = decode_value(step_desc, raw_data)
            ecu_info[step_desc] = display_value
            if display:
                display.display_centered_text(f"{step_desc}\n{display_value}")
                self._sleep(2)
            logging.info(f"{_BANNER}[ECU Info] {step_desc} ({subfunc}) = {display_value}{_BANNER}")
        except Exception as e:
            ecu_info[step_desc] = NO_RESPONSE
            if display:
                display.display_centered_text(f"{step_desc}\nError: {str(e)[:40]}")
            logging.error(f"{_BANNER}[ECU Info] {step_desc} - Exception: {e}{_BANNER}")
