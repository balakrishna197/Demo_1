"""UDS request/response transport over ISO-TP on python-can.

Extracted from V6.2.1 ``UDSClient`` without changing the on-bus behaviour:

* one ISO-TP connection per addressing mode (physical / functional), each
  with a second *sniffer* bus used to read raw response frames;
* raw single/multi-frame response reassembly with our own flow control,
  falling back to the udsoncan/ISO-TP stack when no raw frame arrives;
* 0x78 ResponsePending handling with P2/P2* and a pending-count limit;
* inter-request guard time derived from STmin and response length.

The bus, ISO-TP stack, connection and client classes are injectable, which
is what makes the transport testable on a virtual bus (see tests/).
"""

from __future__ import annotations

import logging
import time
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Callable, Dict, Iterator, Optional

import can
import isotp
from udsoncan import AsciiCodec
from udsoncan.client import Client
from udsoncan.configs import default_client_config
from udsoncan.connections import PythonIsoTpConnection

from dtp_can.config.uds_config import UdsConfig
from dtp_can.core import isotp_frames as tp
from dtp_can.core.hexutil import trim_trailing


class SafeAsciiCodec(AsciiCodec):
    def decode(self, data):
        try:
            return data.decode("ascii")
        except UnicodeDecodeError:
            return data.hex()


def _default_bus_factory(**kwargs):
    return can.interface.Bus(**kwargs)


@dataclass
class Connection:
    conn: Any
    bus: Any
    sniffer_bus: Any
    addr_cfg: Dict[str, Any]
    tx_id: int
    rx_id: int
    is_extended: bool
    client_config: Dict[str, Any]
    mode_name: str


class RunClock:
    """First-request / last-response timestamps of a test run."""

    def __init__(self):
        self.start: Optional[datetime] = None
        self.end: Optional[datetime] = None

    def reset(self) -> None:
        self.start = None
        self.end = None


class UdsTransport:
    ADDRESSING_MODES = ("physical", "functional")

    def __init__(
        self,
        config: UdsConfig,
        bus_factory: Callable[..., Any] = _default_bus_factory,
        client_factory: Callable[..., Any] = Client,
        sleep: Callable[[float], None] = time.sleep,
    ):
        self.config = config
        self.isotp_config = config.isotp
        self._bus_factory = bus_factory
        self._client_factory = client_factory
        self._sleep = sleep
        self.clock = RunClock()
        self.last_request: Optional[bytes] = None
        self.last_response: Optional[bytes] = None
        self.client_config = self._build_client_config()

        self.physical_conn: Optional[Connection] = self._create_connection("physical")
        self.functional_conn: Optional[Connection] = None
        self.active_conn: Optional[Connection] = self.physical_conn
        self.active_mode = "physical"

    # ------------------------------------------------------------------
    # configuration
    # ------------------------------------------------------------------
    def _build_client_config(self) -> Dict[str, Any]:
        timing = self.config.timing
        cfg = default_client_config.copy()
        cfg["p2_timeout"] = timing["p2_client"] / 1000.0
        cfg["p2_star_timeout"] = timing["p2_extended_client"] / 1000.0
        cfg["s3_client_timeout"] = timing["s3_client"] / 1000.0
        cfg["exception_on_negative_response"] = False
        cfg["exception_on_unexpected_response"] = False
        cfg["exception_on_invalid_response"] = False
        cfg["use_server_timing"] = False
        cfg["data_identifiers"] = {
            int(did_str, 16): SafeAsciiCodec(length)
            for did_str, length in self.config.decode_dids.items()
        }
        cfg["write_data"] = {
            int(did_str, 16): data_str
            for did_str, data_str in self.config.write_data.items()
        }
        return cfg

    # ------------------------------------------------------------------
    # connections
    # ------------------------------------------------------------------
    def _create_connection(self, mode_name: str) -> Optional[Connection]:
        addr_cfg = self.config.addressing_modes.get(mode_name)
        if not addr_cfg:
            logging.info(f"No config found for {mode_name} addressing, skipping.")
            return None

        tx_id = int(addr_cfg["tx_id"], 16)
        rx_id = int(addr_cfg["rx_id"], 16)
        is_extended = addr_cfg.get("is_extended", False)
        address = isotp.Address(
            addressing_mode=(
                isotp.AddressingMode.Normal_29bits
                if is_extended
                else isotp.AddressingMode.Normal_11bits
            ),
            txid=tx_id,
            rxid=rx_id,
        )
        rx_mask = 0x1FFFFFFF if is_extended else 0x7FF
        bus_kwargs = dict(
            channel=self.config.channel,
            interface=self.config.interface,
            fd=self.config.can_fd,
            can_filters=[{"can_id": rx_id, "can_mask": rx_mask, "extended": is_extended}],
        )
        bus = self._bus_factory(**bus_kwargs)
        sniffer_bus = self._bus_factory(**bus_kwargs)
        stack = isotp.CanStack(bus=bus, address=address, params=self.isotp_config)
        conn = PythonIsoTpConnection(stack)
        return Connection(
            conn=conn,
            bus=bus,
            sniffer_bus=sniffer_bus,
            addr_cfg=addr_cfg,
            tx_id=tx_id,
            rx_id=rx_id,
            is_extended=is_extended,
            client_config=self.client_config,
            mode_name=mode_name,
        )

    @staticmethod
    def _close_connection(entry: Optional[Connection]) -> None:
        if not entry:
            return
        for closer in (entry.conn.close, entry.bus.shutdown, entry.sniffer_bus.shutdown):
            try:
                closer()
            except Exception:
                pass

    def switch_mode(self, mode: str) -> None:
        mode = mode.lower()
        if mode not in self.ADDRESSING_MODES:
            raise ValueError(f"Unsupported or unconfigured addressing mode: {mode}")
        if self.active_mode == mode and self.active_conn is not None:
            return
        if self.active_mode == "physical" and self.physical_conn is not None:
            self._close_connection(self.physical_conn)
            self.physical_conn = None
        elif self.active_mode == "functional" and self.functional_conn is not None:
            self._close_connection(self.functional_conn)
            self.functional_conn = None

        new_conn = self._create_connection(mode)
        if new_conn is None:
            raise ValueError(f"Unsupported or unconfigured addressing mode: {mode}")
        if mode == "physical":
            self.physical_conn = new_conn
        else:
            self.functional_conn = new_conn
        self.active_conn = new_conn
        self.active_mode = mode

    def reset_connections(self) -> None:
        self._close_connection(self.physical_conn)
        self._close_connection(self.functional_conn)
        self.physical_conn = self._create_connection("physical")
        self.functional_conn = None
        self.active_conn = self.physical_conn
        self.active_mode = "physical"

    def close(self) -> None:
        """Release every CAN socket owned by this transport."""
        self._close_connection(self.physical_conn)
        self._close_connection(self.functional_conn)
        self.physical_conn = self.functional_conn = self.active_conn = None

    @contextmanager
    def open_client(self, use_active_config: bool = True) -> Iterator[Any]:
        """udsoncan ``Client`` bound to the active connection."""
        if self.active_conn is None:
            raise RuntimeError("No active connection configured")
        config = self.active_conn.client_config if use_active_config else self.client_config
        with self._client_factory(self.active_conn.conn, request_timeout=2, config=config) as client:
            yield client

    # ------------------------------------------------------------------
    # raw frame handling
    # ------------------------------------------------------------------
    @staticmethod
    def drain(entry: Optional[Connection]) -> None:
        if not entry:
            return
        while entry.sniffer_bus.recv(timeout=0.0) is not None:
            pass

    def _send_flow_control_frame(self, entry: Connection) -> None:
        tx_len = int(self.isotp_config.get("tx_data_length", 8))
        padding = int(self.isotp_config.get("tx_padding", 0))
        blocksize = int(self.isotp_config.get("blocksize", 8))
        stmin = self.isotp_config.get("stmin", 0)
        if isinstance(stmin, str):
            stmin = int(stmin, 0)
        payload = [0x30, blocksize & 0xFF, stmin & 0xFF]
        payload.extend([padding] * max(0, tx_len - len(payload)))
        entry.sniffer_bus.send(
            can.Message(
                arbitration_id=entry.tx_id,
                is_extended_id=entry.is_extended,
                is_fd=self.config.can_fd,
                bitrate_switch=self.isotp_config.get("bitrate_switch", True),
                data=payload[:tx_len],
            )
        )

    def _timeouts(self, active_config: Dict[str, Any]):
        p2 = float(active_config.get("p2_timeout", self.client_config.get("p2_timeout", 2.0)))
        p2_star = float(
            active_config.get("p2_star_timeout", self.client_config.get("p2_star_timeout", 5.0))
        )
        max_pending = int(self.config.timing.get("max_pending_responses", 20))
        return p2, p2_star, max_pending

    def get_cf_timeout(self, active_config: Optional[Dict[str, Any]] = None) -> float:
        active_config = active_config or (
            self.active_conn.client_config if self.active_conn else {}
        )
        p2_star = float(
            active_config.get("p2_star_timeout", self.client_config.get("p2_star_timeout", 5.0))
        )
        configured = float(self.config.timing.get("cf_wait_timeout", 0.25))
        stmin_seconds = tp.stmin_to_seconds(self.isotp_config.get("stmin", 0))
        # CANoe traces show CF spacing around 100 ms; leave margin for STmin
        # plus Linux/Raspberry Pi scheduling jitter.
        stmin_guard = (stmin_seconds * 3) + 0.2 if stmin_seconds > 0 else 0.0
        return max(p2_star, configured, stmin_guard, 1.0)

    def wait_for_raw_response(self, entry: Connection, tc_id: str, step_desc: str):
        p2, p2_star, max_pending = self._timeouts(entry.client_config)
        cf_timeout = self.get_cf_timeout(entry.client_config)
        pending_count = 0
        timeout = p2
        while True:
            msg = entry.sniffer_bus.recv(timeout=timeout)
            if msg is None:
                return None
            data = bytes(msg.data)
            if not data:
                continue
            ftype = tp.frame_type(data[0])
            # ECU flow-control frames acknowledge our multi-frame request
            # (e.g. 27 02 + key); they are not diagnostic responses.
            if ftype == tp.FLOW_CONTROL:
                continue
            if ftype == tp.SINGLE_FRAME:
                payload = data[1:1 + (data[0] & 0x0F)]
                if tp.is_response_pending(payload):
                    pending_count += 1
                    if pending_count > max_pending:
                        return payload
                    timeout = p2_star
                    continue
                return payload
            if ftype == tp.FIRST_FRAME:
                total_len = tp.first_frame_length(data[0], data[1])
                payload = bytearray(data[2:])
                self._send_flow_control_frame(entry)
                expected_sn = 1
                while len(payload) < total_len:
                    cf_msg = entry.sniffer_bus.recv(timeout=cf_timeout)
                    if cf_msg is None:
                        logging.warning(
                            f"{tc_id} {step_desc} -> Raw CAN reassembly timeout "
                            f"({len(payload)}/{total_len})"
                        )
                        return bytes(payload[:total_len])
                    cf_data = bytes(cf_msg.data)
                    if not cf_data or tp.frame_type(cf_data[0]) != tp.CONSECUTIVE_FRAME:
                        continue
                    sequence_number = cf_data[0] & 0x0F
                    if sequence_number != (expected_sn & 0x0F):
                        logging.warning(
                            f"{tc_id} {step_desc} -> Raw CAN CF SN mismatch. "
                            f"Expected {expected_sn & 0x0F}, got {sequence_number}"
                        )
                    payload.extend(cf_data[1:])
                    expected_sn += 1
                return bytes(payload[:total_len])
            # Already payload-form response from another transport layer.
            return data

    # ------------------------------------------------------------------
    # udsoncan-stack fallback path
    # ------------------------------------------------------------------
    @staticmethod
    def _expected_payload_length(expected_bytes):
        trimmed = trim_trailing(expected_bytes, (0x00, 0xAA))
        if not trimmed:
            return None
        first = trimmed[0]
        ftype = tp.frame_type(first)
        if ftype == tp.FIRST_FRAME and len(trimmed) >= 2:
            declared_len = tp.first_frame_length(first, trimmed[1])
            available_len = max(0, len(trimmed) - 2)
            return min(declared_len, available_len) if available_len else declared_len
        if ftype == tp.SINGLE_FRAME:
            declared_len = first & 0x0F
            available_len = max(0, len(trimmed) - 1)
            return min(declared_len, available_len) if available_len else declared_len
        return None

    def extend_response_to_expected(self, response, expected_bytes, client, tc_id, step_desc):
        expected_len = self._expected_payload_length(expected_bytes)
        if not response or not expected_len:
            return response
        payload, detected_len = tp.extract_payload_view(response)
        if detected_len is None:
            return response
        target_len = detected_len or expected_len
        if len(payload) >= target_len:
            return response
        cf_timeout = self.get_cf_timeout()
        logging.info(
            f"{tc_id} {step_desc} -> Response shorter than expected "
            f"({len(payload)}/{target_len}). Waiting for remaining payload."
        )
        while len(payload) < target_len:
            next_frame = client.conn.wait_frame(timeout=cf_timeout)
            if not next_frame:
                logging.warning(
                    f"{tc_id} {step_desc} -> Timed out while extending "
                    f"response ({len(payload)}/{target_len})"
                )
                break
            if len(next_frame) >= 1:
                ftype = tp.frame_type(next_frame[0])
                if ftype == tp.FLOW_CONTROL:
                    continue
                if ftype == tp.CONSECUTIVE_FRAME:
                    payload.extend(next_frame[1:])
                    continue
            # Transports that already strip PCI expose payload bytes only.
            payload.extend(next_frame)
        return bytes(payload[:target_len])

    def _reassemble_isotp_response(self, first_frame, client, tc_id, step_desc, cf_timeout=None):
        if not first_frame or len(first_frame) < 2:
            return first_frame
        pci = first_frame[0]
        if tp.frame_type(pci) != tp.FIRST_FRAME:
            return first_frame
        total_len = tp.first_frame_length(pci, first_frame[1])
        payload = bytearray(first_frame[2:])
        expected_sn = 1
        cf_timeout = self.get_cf_timeout() if cf_timeout is None else cf_timeout
        header = bytes([first_frame[0], first_frame[1]])
        logging.info(
            f"{tc_id} {step_desc} -> Reassembling ISO-TP multi-frame response, "
            f"total payload {total_len} bytes, CF timeout {cf_timeout:.3f}s"
        )
        while len(payload) < total_len:
            next_frame = client.conn.wait_frame(timeout=cf_timeout)
            if not next_frame:
                logging.warning(
                    f"{tc_id} {step_desc} -> Timed out waiting for consecutive "
                    f"frame {expected_sn} after collecting {len(payload)}/{total_len} bytes"
                )
                return header + bytes(payload)
            next_type = tp.frame_type(next_frame[0])
            if next_type == tp.FLOW_CONTROL:
                continue
            if next_type != tp.CONSECUTIVE_FRAME:
                logging.warning(
                    f"{tc_id} {step_desc} -> Unexpected frame during reassembly: "
                    f"{next_frame.hex().upper()}"
                )
                return header + bytes(payload)
            sequence_number = next_frame[0] & 0x0F
            if sequence_number != (expected_sn & 0x0F):
                logging.warning(
                    f"{tc_id} {step_desc} -> Consecutive frame SN mismatch. "
                    f"Expected {expected_sn & 0x0F}, got {sequence_number}"
                )
            payload.extend(next_frame[1:])
            expected_sn += 1
        return header + bytes(payload[:total_len])

    def _guard_time(self, response_len: int, tc_id: str, step_desc: str) -> float:
        tx_data_length = int(self.isotp_config.get("tx_data_length", 8))
        first_frame_payload = max(tx_data_length - 2, 1)
        consecutive_frame_payload = max(tx_data_length - 1, 1)
        stmin_seconds = tp.stmin_to_seconds(self.isotp_config.get("stmin", 0))
        configured_guard_ms = self.config.timing.get("inter_request_guard_ms", 0)
        guard_time = 0.05
        if response_len > first_frame_payload and stmin_seconds > 0:
            extra_frames = max(
                1,
                (response_len - first_frame_payload + consecutive_frame_payload - 1)
                // consecutive_frame_payload,
            )
            guard_time = max(guard_time, (extra_frames + 1) * stmin_seconds)
        if configured_guard_ms:
            guard_time = max(guard_time, configured_guard_ms / 1000.0)
            logging.info(f"{tc_id} {step_desc} -> Inter-request guard {guard_time:.3f}s")
        return guard_time

    def wait_for_final_response(self, client, tc_id: str, step_desc: str):
        active_config = (
            self.active_conn.client_config if self.active_conn else self.client_config
        )
        p2, p2_star, max_pending = self._timeouts(active_config)
        logging.info(f"{tc_id} {step_desc} -> Waiting for response (P2={p2}s, P2*={p2_star}s)")
        response = client.conn.wait_frame(timeout=p2)
        pending_count = 0
        while response and tp.is_response_pending(response):
            pending_count += 1
            logging.info(
                f"{tc_id} {step_desc} -> 0x78 Response Pending ({pending_count}), "
                "waiting with P2*..."
            )
            if pending_count > max_pending:
                logging.warning(
                    f"{tc_id} {step_desc} -> Exceeded max pending responses ({max_pending})"
                )
                return response
            response = client.conn.wait_frame(timeout=p2_star)

        response = self._reassemble_isotp_response(
            response, client, tc_id, step_desc, self.get_cf_timeout(active_config)
        )
        self._sleep(self._guard_time(len(response), tc_id, step_desc) if response else 0.05)
        return response

    # ------------------------------------------------------------------
    # public request API
    # ------------------------------------------------------------------
    def send_request_and_wait(
        self,
        client,
        raw_request: bytes,
        tc_id: str,
        step_desc: str,
        post_wait: float = 0.0,
        expected_bytes=None,
    ):
        logging.info(f"{tc_id} - {step_desc}: Sending request {bytes(raw_request).hex().upper()}")
        self.drain(self.active_conn)
        self.last_request = raw_request
        if self.clock.start is None:
            self.clock.start = datetime.now()
            logging.info(
                f" Test start time: {self.clock.start.isoformat()}"
                f" (first UDS request: {bytes(raw_request).hex().upper()})"
            )
        client.conn.send(raw_request)
        response = self.wait_for_raw_response(self.active_conn, tc_id, step_desc)
        if response is None:
            response = self.wait_for_final_response(client, tc_id, step_desc)
        if expected_bytes:
            response = self.extend_response_to_expected(
                response, expected_bytes, client, tc_id, step_desc
            )
        self.last_response = response
        if response is not None:
            self.clock.end = datetime.now()
            logging.info(
                f"Test end time: {self.clock.end.isoformat()} (TC: {tc_id}, step: {step_desc})"
            )
        if post_wait > 0:
            self._sleep(post_wait)
        return response

    def try_basic_communication(self) -> bool:
        """TesterPresent through the udsoncan client; True on positive reply."""
        try:
            with self.open_client(use_active_config=False) as client:
                return client.tester_present().positive
        except Exception as e:
            logging.warning(f"Tester Present failed: {e}")
            return False

    # ------------------------------------------------------------------
    # run preparation
    # ------------------------------------------------------------------
    def prepare_execution_start(self) -> None:
        settle_ms = int(self.config.timing.get("startup_settle_ms", 250))
        settle_seconds = max(0.0, settle_ms / 1000.0)
        if settle_seconds > 0:
            logging.info(
                f"Execution startup settle delay: {settle_seconds:.3f}s before first testcase"
            )
            self._sleep(settle_seconds)
        for name, entry in (
            ("physical", self.physical_conn),
            ("functional", self.functional_conn),
            ("active", self.active_conn),
        ):
            if not entry:
                continue
            try:
                self.drain(entry)
                logging.info(f"Drained stale CAN frames on {name} sniffer bus")
            except Exception as exc:
                logging.warning(f"Failed to drain {name} sniffer bus before execution: {exc}")

    def prepare_ecu_before_logged_run(self) -> None:
        """Fresh sockets + default session, so the logged run starts clean."""
        logging.info("Preparing ECU and CAN/ISO-TP connections before logged run")
        self.reset_connections()
        self.prepare_execution_start()
        try:
            with self.open_client() as client:
                response = self.send_request_and_wait(
                    client,
                    bytes([0x10, self.config.default_session]),
                    "PRE_RUN",
                    "Start default session before logged execution",
                    post_wait=0.2,
                )
                logging.info(
                    "Pre-run default session response: "
                    f"{response.hex().upper() if response else 'No response'}"
                )
        except Exception as exc:
            logging.warning(f"Pre-run default session preparation failed: {exc}")
        self.reset_connections()
        self.prepare_execution_start()
        self.clock.reset()
