"""UDS-on-CAN execution: transport, service handlers, test runner, logging."""
