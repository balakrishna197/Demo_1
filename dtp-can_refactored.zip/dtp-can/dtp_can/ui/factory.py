"""Builds the ``UserInterface`` for the requested mode.

``auto``     - OLED + buttons when available, console when a TTY exists,
               both mirrored ("hybrid") when both are present;
``hardware`` - OLED + buttons are mandatory (errors propagate);
``terminal`` - console only.
"""

from __future__ import annotations

import logging
from typing import Callable, Optional

from dtp_can.config.settings import UiSettings
from dtp_can.ui.interaction import UserInterface
from dtp_can.ui.router import DisplayRouter
from dtp_can.ui.terminal import TerminalDisplay, TerminalInput


def _default_oled(display_settings):
    from dtp_can.ui.oled import OLEDDisplay

    return OLEDDisplay(
        {
            "width": display_settings.width,
            "height": display_settings.height,
            "address": display_settings.address,
        }
    )


def _default_buttons(pins):
    from dtp_can.ui.buttons import GpioButtons

    return GpioButtons(pins)


def build_user_interface(
    settings: UiSettings,
    oled_factory: Callable = _default_oled,
    buttons_factory: Callable = _default_buttons,
    terminal_input_factory: Callable = TerminalInput,
    terminal_display_factory: Callable = TerminalDisplay,
) -> UserInterface:
    mode = settings.mode
    hardware_display = None
    buttons = None
    if mode in {"hardware", "auto"}:
        try:
            hardware_display = oled_factory(settings.display)
            buttons = buttons_factory(settings.buttons.pins())
        except Exception as exc:
            if mode == "hardware":
                raise
            logging.warning("Hardware UI unavailable, falling back to terminal UI: %s", exc)
            hardware_display = None
            buttons = None

    terminal_display = None
    terminal_input: Optional[TerminalInput] = None
    if mode in {"terminal", "auto"}:
        candidate = terminal_input_factory()
        if candidate.is_available():
            terminal_input = candidate
            terminal_display = terminal_display_factory()
        elif mode == "terminal":
            terminal_display = terminal_display_factory()

    if hardware_display and terminal_display:
        display, resolved = DisplayRouter(hardware_display, terminal_display), "hybrid"
    elif hardware_display:
        display, resolved = hardware_display, "hardware"
    else:
        display, resolved = terminal_display or terminal_display_factory(), "terminal"

    logging.info("User interface mode: %s", resolved)
    return UserInterface(
        display=display,
        hardware_display=hardware_display,
        buttons=buttons,
        terminal_input=terminal_input,
        mode=resolved,
        poll_interval=settings.poll_interval_s,
    )
