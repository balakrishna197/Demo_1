"""Fan-out display: mirrors every call to several displays (OLED + console)."""


class DisplayRouter:
    def __init__(self, *displays):
        self.displays = [
            display for display in displays if display is not None
        ]

    def set_wifi_status(self, status):
        for display in self.displays:
            display.set_wifi_status(status)

    def clear(self):
        for display in self.displays:
            display.clear()

    def display_text(self, text, line=0):
        for display in self.displays:
            display.display_text(text, line=line)

    def display_centered_text(self, text):
        for display in self.displays:
            display.display_centered_text(text)
