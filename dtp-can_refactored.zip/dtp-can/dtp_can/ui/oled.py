"""SSD1306 128x64 I2C OLED display (Adafruit Blinka).

Hardware libraries are imported lazily so the rest of the application can
run (terminal mode, tests) on machines without them.
"""

from __future__ import annotations

STATUS_BAR_X = 100
STATUS_BAR_HEIGHT = 8


class OLEDDisplay:
    def __init__(self, config):
        import adafruit_ssd1306  # pyright: ignore[reportMissingImports]
        import board  # pyright: ignore[reportMissingImports]
        import busio  # pyright: ignore[reportMissingImports]
        from PIL import Image, ImageDraw, ImageFont

        self.i2c = busio.I2C(board.SCL, board.SDA)
        address = config.get("address", "0x3C")
        address = int(address, 16) if isinstance(address, str) else int(address)
        self.display = adafruit_ssd1306.SSD1306_I2C(
            config["width"], config["height"], self.i2c, addr=address
        )
        self.width = self.display.width
        self.height = self.display.height
        self.image = Image.new("1", (self.width, self.height))
        self.draw = ImageDraw.Draw(self.image)
        self.font = ImageFont.load_default()
        self.wifi_status = "W-"
        self.clear()
        self.draw_status_bar()
        self._flush()

    def _flush(self):
        self.display.image(self.image)
        self.display.show()

    def set_wifi_status(self, status):
        self.wifi_status = status

    def draw_status_bar(self):
        self.draw.text((STATUS_BAR_X, 0), self.wifi_status, font=self.font, fill=255)

    def clear(self):
        self.draw.rectangle((0, 0, self.width, self.height), outline=0, fill=0)

    def display_text(self, text, line=10):
        self.clear()
        self.draw_status_bar()
        self.draw.text((0, line), text, font=self.font, fill=255)
        self._flush()

    def display_centered_text(self, text):
        self.clear()
        self.draw_status_bar()
        lines = text.split("\n")
        line_height = self.draw.textbbox((0, 0), "A", font=self.font)[3]
        total_text_height = line_height * len(lines)
        y_offset = ((self.height - STATUS_BAR_HEIGHT) - total_text_height) // 2 + STATUS_BAR_HEIGHT
        for i, line in enumerate(lines):
            bbox = self.draw.textbbox((0, 0), line, font=self.font)
            x = (self.width - (bbox[2] - bbox[0])) // 2
            self.draw.text((x, y_offset + i * line_height), line, font=self.font, fill=255)
        self._flush()
