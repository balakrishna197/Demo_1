"""UI contracts. Anything implementing these can be plugged in (e.g. a
web/remote display) without touching the application layer."""

from __future__ import annotations

from typing import Optional, Protocol, runtime_checkable


@runtime_checkable
class Display(Protocol):
    def set_wifi_status(self, status: str) -> None: ...
    def clear(self) -> None: ...
    def display_text(self, text: str, line: int = 0) -> None: ...
    def display_centered_text(self, text: str) -> None: ...


@runtime_checkable
class ButtonPad(Protocol):
    def get_pressed_nonblocking(self) -> Optional[int]:
        """Index of the pressed button (0..n-1) or None."""


@runtime_checkable
class KeyInput(Protocol):
    def is_available(self) -> bool: ...
    def read_key(self, timeout: float = 0): ...
    def poll_action(self, timeout: float = 0.1): ...


class NullDisplay:
    """Display that discards output (headless/test use)."""

    def set_wifi_status(self, status):
        pass

    def clear(self):
        pass

    def display_text(self, text, line=0):
        pass

    def display_centered_text(self, text):
        pass
