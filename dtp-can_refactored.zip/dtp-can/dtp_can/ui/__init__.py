"""User interface: displays, input devices and interaction widgets."""
