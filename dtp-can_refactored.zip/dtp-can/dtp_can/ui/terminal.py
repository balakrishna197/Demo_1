"""Console implementations of the display and key-input ports."""

import atexit
import codecs
import getpass
import os
import select
import sys

try:
    import termios
    import tty
except ImportError:  # pragma: no cover - non-POSIX
    termios = None
    tty = None


class TerminalDisplay:
    def __init__(self):
        self.wifi_status = "W-"
        self._last_rendered_output = None

    def set_wifi_status(self, status):
        self.wifi_status = status

    def clear(self):
        self._last_rendered_output = None
        # Clear terminal and move cursor to top-left.
        print("\033[2J\033[H", end="")

    def display_text(self, text, line=0):
        del line
        self.display_centered_text(text)

    def display_centered_text(self, text):
        rendered_output = f"[WiFi: {self.wifi_status}]\n{text}"
        if rendered_output == self._last_rendered_output:
            return
        self._last_rendered_output = rendered_output
        print("\033[2J\033[H", end="")
        print(rendered_output)


class TerminalInput:
    def __init__(self, stdin=None):
        self.stdin = stdin or sys.stdin
        self.enabled = False
        self._original_termios = None
        self._pending = ""
        self._decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
        self._setup_terminal()

    def _setup_terminal(self):
        if termios is None or tty is None:
            return
        if not self.stdin.isatty():
            return
        try:
            tcgetattr = getattr(termios, "tcgetattr", None)
            setcbreak = getattr(tty, "setcbreak", None)
            if tcgetattr is None or not callable(setcbreak):
                return
            self._original_termios = tcgetattr(self.stdin.fileno())
            setcbreak(self.stdin.fileno())
            atexit.register(self.restore)
            self.enabled = True
        except Exception:
            self.enabled = False

    def restore(self):
        if not self.enabled or self._original_termios is None:
            return
        try:
            if termios is None:
                return
            tcsetattr = getattr(termios, "tcsetattr", None)
            tcsadrain = getattr(termios, "TCSADRAIN", None)
            if not callable(tcsetattr) or tcsadrain is None:
                return
            tcsetattr(
                self.stdin.fileno(),
                tcsadrain,
                self._original_termios
            )
        except Exception:
            pass

    def is_available(self):
        return self.enabled

    def _read_char(self, timeout: float = 0):
        """Next character, reading the raw fd through our own buffer.

        BUGFIX (B-08): V6.2.1 used ``select()`` on the fd but read through
        the *buffered* ``sys.stdin``; one ``read(1)`` pulled every pending byte
        into Python's buffer, so ``select()`` then reported nothing.  Arrow
        keys (3-byte escape sequences) decoded as ESC and fast/pasted input
        was lost until the next key press.
        """
        if not self.enabled:
            return None
        if not self._pending:
            readable, _, _ = select.select([self.stdin], [], [], timeout)
            if not readable:
                return None
            data = os.read(self.stdin.fileno(), 1024)
            if not data:
                return None
            self._pending += self._decoder.decode(data)
            if not self._pending:
                return None
        char, self._pending = self._pending[0], self._pending[1:]
        return char

    def read_key(self, timeout: float = 0):
        char = self._read_char(timeout=timeout)
        if char is None:
            return None

        if char == "\x1b":
            next_char = self._read_char(timeout=0.01)
            if next_char == "[":
                arrow = self._read_char(timeout=0.01)
                if not isinstance(arrow, str):
                    return "ESC"
                return {
                    "A": "UP",
                    "B": "DOWN",
                    "C": "RIGHT",
                    "D": "LEFT"
                }.get(arrow, "ESC")
            return "ESC"

        if char in ("\r", "\n"):
            return "ENTER"
        if char in ("\x08", "\x7f"):
            return "BACKSPACE"
        if char == "\t":
            return "TAB"
        if char == " ":
            return "SPACE"
        return char

    def poll_action(self, timeout=0.1):
        key = self.read_key(timeout=timeout)
        if key is None:
            return None
        if key in {"LEFT", "UP", "a", "A", "p", "P"}:
            return "prev"
        if key in {"RIGHT", "DOWN", "d", "D", "n", "N"}:
            return "next"
        if key in {"ENTER", "s", "S"}:
            return "select"
        if key in {"ESC", "q", "Q"}:
            return "cancel"
        if isinstance(key, str) and key.isdigit():
            return ("digit", int(key))
        return None

    def prompt_password(self, ssid):
        self.restore()
        try:
            return getpass.getpass(f"Enter password for '{ssid}': ")
        finally:
            self._setup_terminal()
