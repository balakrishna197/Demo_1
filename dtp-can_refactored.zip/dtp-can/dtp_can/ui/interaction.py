"""Operator interaction widgets shared by every workflow and feature.

Moved out of the V6.2.1 ``UDSApp`` god-class.  Behaviour (button meanings,
keyboard shortcuts, redraw rules) is unchanged:

* list selection - B0 prev, B1 next, B2 select, B3 cancel (if allowed);
  keyboard A/P/Left/Up prev, D/N/Right/Down next, S/Enter select, Q/Esc
  cancel, digits 1-9 direct choice;
* text/password entry - B0 next char, B1 previous char, B2 add char
  (``>`` submits, ``<`` deletes in password mode), B3 submit; keyboard
  types directly.
"""

from __future__ import annotations

import os
import time
from typing import Callable, List, Optional, Sequence

from dtp_can.ui.terminal import TerminalDisplay

PASSWORD_CHARS = (
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "abcdefghijklmnopqrstuvwxyz"
    "0123456789"
    "@._-!#$%&*+=<>"
)
TEXT_CHARS = (
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "abcdefghijklmnopqrstuvwxyz"
    "0123456789"
    " ._-"
    ">"
)


def _clear_console() -> None:
    os.system("clear")


class UserInterface:
    """Facade over the active display(s) and input device(s)."""

    def __init__(
        self,
        display,
        hardware_display=None,
        buttons=None,
        terminal_input=None,
        mode: str = "terminal",
        poll_interval: float = 0.15,
        sleep: Callable[[float], None] = time.sleep,
        clear_console: Callable[[], None] = _clear_console,
        echo: Callable[[str], None] = print,
    ):
        self.display = display
        self.hardware_display = hardware_display
        self.buttons = buttons
        self.terminal_input = terminal_input
        self.mode = mode
        self.poll_interval = poll_interval
        self._sleep = sleep
        self._clear_console = clear_console
        self._echo = echo

    # ------------------------------------------------------------------
    @property
    def has_terminal_input(self) -> bool:
        return self.terminal_input is not None and self.terminal_input.is_available()

    @property
    def has_hardware_input(self) -> bool:
        return self.buttons is not None

    def show(self, text: str) -> None:
        self.display.display_centered_text(text)

    def show_for(self, text: str, seconds: float) -> None:
        self.display.display_centered_text(text)
        self._sleep(seconds)

    def show_text(self, text: str) -> None:
        self.display.clear()
        self.display.display_text(text)

    def set_wifi_status(self, status: str) -> None:
        self.display.set_wifi_status(status)

    def print_instructions(self, lines: Sequence[str]) -> None:
        if not self.has_terminal_input:
            return
        self._echo("")
        for line in lines:
            self._echo(line)

    # ------------------------------------------------------------------
    def _button(self) -> Optional[int]:
        return self.buttons.get_pressed_nonblocking() if self.buttons is not None else None

    def poll_action(self, options_count=None, allow_cancel=False, timeout=0.1):
        button = self._button()
        if button == 0:
            return "prev"
        if button == 1:
            return "next"
        if button == 2:
            return "select"
        if button == 3 and allow_cancel:
            return "cancel"

        if self.has_terminal_input:
            action = self.terminal_input.poll_action(timeout=timeout)
            if isinstance(action, tuple) and action[0] == "digit":
                digit = action[1]
                if options_count and 1 <= digit <= options_count:
                    return ("index", digit - 1)
                return None
            if action == "cancel" and not allow_cancel:
                return None
            return action

        if self.has_hardware_input:
            self._sleep(timeout)
        return None

    def select_from_list(
        self,
        title: str,
        items: List,
        formatter: Callable[[str], str] = str,
        allow_cancel: bool = False,
    ) -> Optional[int]:
        if not items:
            return None
        index = 0
        last_displayed_index = None
        while True:
            if index != last_displayed_index:
                if self.hardware_display is not None:
                    self.hardware_display.display_centered_text(f"{title}\n\n{formatter(items[index])}")
                if self.has_terminal_input:
                    self._render_console_list(title, items, index, formatter, allow_cancel)
                last_displayed_index = index

            action = self.poll_action(
                options_count=min(len(items), 9),
                allow_cancel=allow_cancel,
                timeout=self.poll_interval,
            )
            if action == "prev":
                index = (index - 1) % len(items)
            elif action == "next":
                index = (index + 1) % len(items)
            elif action == "select":
                return index
            elif action == "cancel":
                return None
            elif isinstance(action, tuple) and action[0] == "index":
                if 0 <= action[1] < len(items):
                    return action[1]

    def _render_console_list(self, title, items, index, formatter, allow_cancel) -> None:
        self._clear_console()
        self._echo("=" * 50)
        self._echo(f"Select {title}")
        self._echo("=" * 50)
        for i, item in enumerate(items):
            prefix = ">" if i == index else " "
            self._echo(f"{prefix} {i + 1}. {formatter(item)}")
        self._echo("")
        self._echo("Controls:")
        self._echo("A / P      : Previous")
        self._echo("D / N      : Next")
        self._echo("S / Enter  : Select")
        if allow_cancel:
            self._echo("Q          : Cancel")
        self._echo("1-9        : Direct Selection")

    def choose_menu_option(self, count: int) -> int:
        """Block until option 1..count is chosen; returns the 0-based index.

        Hardware button *n* selects option *n+1* (up to four buttons).
        """
        while True:
            button = self._button()
            if button is not None and button < count:
                return button
            if self.has_terminal_input:
                action = self.terminal_input.poll_action(timeout=self.poll_interval)
                if isinstance(action, tuple) and action[0] == "digit":
                    if 1 <= action[1] <= count:
                        return action[1] - 1
            else:
                self._sleep(self.poll_interval)

    # ------------------------------------------------------------------
    def enter_password(self, ssid: str) -> str:
        chars = PASSWORD_CHARS
        password = ""
        index = 0
        if self.has_terminal_input:
            self.print_instructions(
                [
                    f"Entering password for {ssid}",
                    "Keyboard: type password directly, Backspace deletes, "
                    "Enter submits, Q or Esc submits current text.",
                    "Keypad still works in parallel.",
                ]
            )
        while True:
            current_char = chars[index]
            masked = "*" * min(len(password), 8)
            self.display.display_centered_text(f"Password:\n{masked}\n\n[{current_char}]")
            button = self._button()
            if button is not None:
                if button == 0:
                    index = (index + 1) % len(chars)
                elif button == 1:
                    index = (index - 1) % len(chars)
                elif button == 2:
                    if current_char == "<":
                        password = password[:-1]
                    elif current_char == ">":
                        return password
                    else:
                        password += current_char
                elif button == 3:
                    return password
                self._sleep(0.15)
                continue

            if self.has_terminal_input:
                key = self.terminal_input.read_key(timeout=self.poll_interval)
                if key is None:
                    continue
                if key == "ENTER":
                    return password
                if key == "BACKSPACE":
                    password = password[:-1]
                    continue
                if key in {"ESC", "q", "Q"}:
                    return password
                if isinstance(key, str) and len(key) == 1 and key.isprintable():
                    password += key
                    continue
            else:
                self._sleep(self.poll_interval)

    def enter_text(self, title: str, default_text: str = "") -> str:
        chars = TEXT_CHARS
        value = default_text or ""
        index = 0
        last_display = None
        if self.has_terminal_input:
            self.print_instructions(
                [
                    f"{title}:",
                    "Keyboard: type directly, Backspace deletes, Enter submits.",
                    "Keypad: UP/DOWN select char, OK adds char, BACK submits.",
                ]
            )
        while True:
            current_char = chars[index]
            preview = value[-14:] if value else "<empty>"
            if (preview, current_char) != last_display:
                if self.hardware_display is not None:
                    self.hardware_display.display_centered_text(
                        f"{title}\n{preview}\n\n[{current_char}]"
                    )
                if self.has_terminal_input:
                    self._clear_console()
                    self._echo("=" * 50)
                    self._echo(title)
                    self._echo("=" * 50)
                    self._echo(f"Value: {value}")
                    self._echo("")
                    self._echo("Type directly and press Enter")
                last_display = (preview, current_char)

            button = self._button()
            if button is not None:
                if button == 0:
                    index = (index + 1) % len(chars)
                elif button == 1:
                    index = (index - 1) % len(chars)
                elif button == 2:
                    if current_char == ">":
                        return value.strip()
                    value += current_char
                elif button == 3:
                    return value.strip()
                self._sleep(0.15)
                continue

            if self.has_terminal_input:
                key = self.terminal_input.read_key(timeout=self.poll_interval)
                if key is None:
                    continue
                if key in ("ENTER", "ESC"):
                    return value.strip()
                if key == "BACKSPACE":
                    value = value[:-1]
                    continue
                if key == "SPACE":
                    value += " "
                    continue
                if isinstance(key, str) and len(key) == 1 and key.isprintable():
                    value += key
                    continue
            else:
                self._sleep(self.poll_interval)


def make_terminal_only(sleep=time.sleep) -> UserInterface:
    """Minimal UI used before the real one is built (e.g. early errors)."""
    display = TerminalDisplay()
    return UserInterface(display=display, mode="terminal", sleep=sleep)
