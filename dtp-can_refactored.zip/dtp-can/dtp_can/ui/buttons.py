"""Active-low push buttons on Raspberry Pi GPIO (BCM numbering)."""

from __future__ import annotations

import time
from typing import List, Optional


class GpioButtons:
    def __init__(self, pins: List[int], gpio=None):
        if gpio is None:
            import RPi.GPIO as gpio  # type: ignore[import-not-found]
        self._gpio = gpio
        self.pins = list(pins)
        gpio.setmode(gpio.BCM)
        for pin in self.pins:
            gpio.setup(pin, gpio.IN, pull_up_down=gpio.PUD_UP)

    def wait_for_press(self) -> int:
        while True:
            for i, pin in enumerate(self.pins):
                if self._gpio.input(pin) == self._gpio.LOW:
                    time.sleep(0.2)
                    return i

    def get_pressed_nonblocking(self) -> Optional[int]:
        for idx, pin in enumerate(self.pins):
            if self._gpio.input(pin) == self._gpio.LOW:
                return idx
        return None
