"""Tracks files a test run adds under ``output/`` and syncs them to the repo."""

from __future__ import annotations

import logging
import os
import shutil
from typing import List, Set


class ReportTracker:
    def __init__(self, output_dir: str):
        self.output_dir = output_dir
        self._snapshot: Set[str] = set()
        self.current_run_reports: List[str] = []

    def _scan(self) -> Set[str]:
        found = set()
        for root, _dirs, files in os.walk(self.output_dir):
            for filename in files:
                found.add(os.path.relpath(os.path.join(root, filename), self.output_dir))
        return found

    def start(self) -> None:
        os.makedirs(self.output_dir, exist_ok=True)
        self._snapshot = self._scan()
        self.current_run_reports = []
        logging.info(f"Report tracking started. Existing files: {len(self._snapshot)}")

    def finish(self) -> List[str]:
        self.current_run_reports = sorted(self._scan() - self._snapshot)
        logging.info("Current run reports: %s", self.current_run_reports)
        return self.current_run_reports

    def copy_to(self, repo_path: str) -> int:
        if repo_path is None:
            raise ValueError("A repository must be selected before copying reports")
        if not self.current_run_reports:
            raise Exception("No new reports generated in current run")
        destination_root = os.path.join(repo_path, "output")
        os.makedirs(destination_root, exist_ok=True)
        copied = 0
        for relative_path in self.current_run_reports:
            source = os.path.join(self.output_dir, relative_path)
            destination = os.path.join(destination_root, relative_path)
            if not os.path.exists(source):
                logging.warning(f"Report file missing: {source}")
                continue
            os.makedirs(os.path.dirname(destination), exist_ok=True)
            shutil.copy2(source, destination)
            logging.info(f"Copied report: {relative_path}")
            copied += 1
        if copied == 0:
            raise Exception("No report files were copied")
        logging.info(f"{copied} current-run report files copied.")
        return copied
