"""Thin wrapper around the ``git`` CLI for the test repository."""

from __future__ import annotations

import logging
import os
from typing import List, Optional

from dtp_can.platform.shell import CommandRunner


def repo_web_url(repo_url: str) -> str:
    """``git@bitbucket.org:org/repo.git`` -> ``https://bitbucket.org/org/repo``."""
    return repo_url.replace("git@bitbucket.org:", "https://bitbucket.org/").replace(".git", "")


class GitClient:
    def __init__(self, repo_url: str, base_dir: str, runner: Optional[CommandRunner] = None,
                 commit_message: str = "Updated Reports"):
        self.repo_url = repo_url
        self.base_dir = base_dir
        self.runner = runner or CommandRunner()
        self.commit_message = commit_message
        self.branch: Optional[str] = None
        self.repo_path: Optional[str] = None
        logging.info(f"Application Base Directory: {self.base_dir}")

    def list_remote_branches(self) -> List[str]:
        logging.info("Fetching latest branches...")
        result = self.runner.run(["git", "ls-remote", "--heads", self.repo_url], check=True)
        branches = set()
        for line in result.stdout.splitlines():
            if line.strip():
                branches.add(line.split("\t")[1].replace("refs/heads/", ""))
        return sorted(branches)

    def checkout_path(self, branch: str) -> str:
        return os.path.join(self.base_dir, branch.replace("/", "_"))

    def clone(self, branch: str) -> str:
        self.branch = branch
        self.repo_path = self.checkout_path(branch)
        logging.info(f"Selected Branch: {self.branch}")
        logging.info(f"Repository Path: {self.repo_path}")
        if os.path.exists(self.repo_path):
            logging.info("Repository already exists.")
            return self.repo_path
        self.runner.run(
            ["git", "clone", "--branch", branch, self.repo_url, self.repo_path],
            check=True, capture=False,
        )
        logging.info(f"Repository cloned successfully: {branch}")
        return self.repo_path

    def _require(self):
        if self.branch is None or self.repo_path is None:
            raise ValueError("A branch/repository must be selected first")
        return self.branch, self.repo_path

    def pull(self) -> None:
        branch, repo = self._require()
        self.runner.run(["git", "-C", repo, "pull", "origin", branch], check=True, capture=False)

    def head_commit(self) -> str:
        _branch, repo = self._require()
        return self.runner.run(["git", "-C", repo, "rev-parse", "HEAD"], check=True).stdout.strip()

    def branch_url(self, commit: str) -> str:
        branch, _repo = self._require()
        return f"{repo_web_url(self.repo_url)}/src/{commit}/?at={branch}"

    def add_all(self) -> None:
        _branch, repo = self._require()
        self.runner.run(["git", "-C", repo, "add", "."], check=True, capture=False)

    def commit(self) -> None:
        # Non-zero exit ("nothing to commit") is tolerated, as in V6.2.1.
        _branch, repo = self._require()
        self.runner.run(["git", "-C", repo, "commit", "-m", self.commit_message], capture=False)

    def push(self) -> None:
        branch, repo = self._require()
        self.runner.run(["git", "-C", repo, "push", "-u", "origin", branch], check=True, capture=False)
