"""Hierarchical branch naming: ``<employee>/<variant>/<type>/<stage>/<date>``.

Replaces five copy-pasted ``get_*`` functions.  The number/names of levels
come from ``git.branch_levels`` in the settings, so adding a level is a
configuration change.  Branches with fewer segments than levels are ignored
(as before); extra segments are allowed and ignored for matching.
"""

from __future__ import annotations

import logging
from typing import List, Optional, Sequence

from dtp_can.core.errors import SessionSetupError


class BranchCatalog:
    def __init__(self, branches: Sequence[str], levels: Sequence[str]):
        self.levels = list(levels)
        depth = len(self.levels)
        self._entries = [
            (branch, branch.split("/"))
            for branch in branches
            if len(branch.split("/")) >= depth
        ]

    def options(self, selected: Sequence[str]) -> List[str]:
        """Distinct, sorted values for the next level given the prefix."""
        level = len(selected)
        values = []
        for _branch, parts in self._entries:
            if parts[:level] == list(selected) and parts[level] not in values:
                values.append(parts[level])
        return sorted(values)

    def match(self, selected: Sequence[str]) -> Optional[str]:
        for branch, parts in self._entries:
            if parts[: len(selected)] == list(selected):
                logging.info(f"Matched Branch: {branch}")
                return branch
        return None

    def require_match(self, selected: Sequence[str]) -> str:
        branch = self.match(selected)
        if not branch:
            raise SessionSetupError("Matching branch not found")
        return branch
