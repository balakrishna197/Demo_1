"""DTP-CAN - Raspberry Pi based portable UDS diagnostic tester.

Package layout (dependencies point downwards only)::

    app          composition root, startup pipeline, menu features, workflows
      |
    diagnostics  reporting  ui  platform  vcs     (feature/infrastructure layers)
      |
    testcases  config
      |
    core         pure helpers and domain models (no I/O, no hardware)
"""

APP_NAME = "DTP-CAN"
APP_VERSION = "V6.2.1"
