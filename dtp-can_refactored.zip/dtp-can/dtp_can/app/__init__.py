"""Application layer: composition root, startup pipeline, workflows, menu features."""
