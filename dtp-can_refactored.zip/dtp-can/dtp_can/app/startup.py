"""Start-up pipeline.

V6.2.1 performed initialisation in one 200-line method.  Each phase is now a
``StartupStep`` with a unique name; ``AppSettings.startup`` lists which steps
run and in which order (default = V6.2.1 order).  Extensions add steps with
``@register_step`` and list them in the settings.
"""

from __future__ import annotations

import abc
import logging
import time
from typing import Dict, Iterable, List, Type

from dtp_can.app.context import AppContext
from dtp_can.app.events import SESSION_READY, WIFI_STATUS
from dtp_can.app.workflows.session_setup import SessionSetupWorkflow
from dtp_can.app.workflows.wifi_setup import WifiSetupWorkflow
from dtp_can.diagnostics.factory import build_diagnostics
from dtp_can.diagnostics.runner import ReportContext
from dtp_can.platform.hardware_setup import CanInterface, HardwareInterfaceSetup
from dtp_can.platform.power import gpio_cleanup
from dtp_can.platform.service_installer import ServiceInstaller
from dtp_can.platform.ssh import SshSetup
from dtp_can.platform.usb_storage import UsbStorage
from dtp_can.platform.wifi import WifiManager, WifiMonitor
from dtp_can.ui.factory import build_user_interface
from dtp_can.vcs.git_client import GitClient

_BANNER = "-" * 34


class StartupStep(abc.ABC):
    name: str = ""

    @abc.abstractmethod
    def run(self, ctx: AppContext) -> None:
        ...


_STEPS: Dict[str, Type[StartupStep]] = {}


def register_step(cls: Type[StartupStep]) -> Type[StartupStep]:
    if not cls.name:
        raise ValueError(f"{cls.__name__} has no name")
    _STEPS[cls.name] = cls
    return cls


def available_steps() -> List[str]:
    return sorted(_STEPS)


class StartupPipeline:
    def __init__(self, step_names: Iterable[str]):
        unknown = [n for n in step_names if n not in _STEPS]
        if unknown:
            raise ValueError(f"Unknown startup steps {unknown}; known: {available_steps()}")
        self.steps = [_STEPS[n]() for n in step_names]

    def run(self, ctx: AppContext) -> None:
        for step in self.steps:
            logging.info("Startup step: %s", step.name)
            step.run(ctx)


# ----------------------------------------------------------------------------
# built-in steps (V6.2.1 order)
# ----------------------------------------------------------------------------
@register_step
class GpioCleanupStep(StartupStep):
    name = "gpio_cleanup"

    def run(self, ctx):
        gpio_cleanup()


@register_step
class HardwareInterfacesStep(StartupStep):
    name = "hardware_interfaces"

    def run(self, ctx):
        if ctx.settings.hardware.enabled:
            HardwareInterfaceSetup(ctx.settings.hardware, ctx.runner).initialize()


@register_step
class SshSetupStep(StartupStep):
    name = "ssh_setup"

    def run(self, ctx):
        if ctx.settings.ssh.enabled:
            SshSetup(ctx.settings.ssh, ctx.settings.git, ctx.paths.base_dir, ctx.runner).setup()


@register_step
class UserInterfaceStep(StartupStep):
    name = "user_interface"

    def run(self, ctx):
        if ctx.ui is None:
            ctx.ui = build_user_interface(ctx.settings.ui)
        ctx.events.subscribe(WIFI_STATUS, ctx.ui.set_wifi_status)


@register_step
class WifiSetupStep(StartupStep):
    name = "wifi_setup"

    def run(self, ctx):
        if ctx.wifi is None:
            ctx.wifi = WifiManager(ctx.runner, ctx.settings.wifi.connect_wait_s)
        if ctx.settings.wifi.enabled:
            WifiSetupWorkflow(ctx.require_ui(), ctx.wifi, ctx.events, ctx.sleep).run()


@register_step
class WifiMonitorStep(StartupStep):
    name = "wifi_monitor"

    def run(self, ctx):
        if not ctx.settings.wifi.enabled or ctx.wifi is None:
            return
        if ctx.wifi_monitor is None:
            ctx.wifi_monitor = WifiMonitor(
                ctx.wifi,
                lambda status: ctx.events.publish(WIFI_STATUS, status),
                ctx.settings.wifi.monitor_interval_s,
            )
        ctx.wifi_monitor.start()


@register_step
class TestSessionStep(StartupStep):
    """Repository selection; skipped when a session was pre-set (offline)."""

    __test__ = False
    name = "test_session"

    def run(self, ctx):
        if ctx.session is not None and ctx.git is None:
            ctx.events.publish(SESSION_READY, ctx.session)
            return
        if ctx.git is None:
            git = ctx.settings.git
            ctx.git = GitClient(git.repo_url, ctx.paths.base_dir, ctx.runner, git.commit_message)
        workflow = SessionSetupWorkflow(
            ctx.require_ui(), ctx.git, ctx.workspace, ctx.settings.git.branch_levels, ctx.sleep
        )
        ctx.session = workflow.run()
        ctx.events.publish(SESSION_READY, ctx.session)


@register_step
class DiagnosticsStep(StartupStep):
    """Build the UDS stack and probe the seed/key server."""

    name = "diagnostics"

    def run(self, ctx):
        if ctx.session is None:
            raise RuntimeError("No test session - run 'test_session' first")
        if ctx.diagnostics is not None:
            ctx.diagnostics.close()
        kwargs = {}
        if ctx.bus_factory is not None:
            kwargs["bus_factory"] = ctx.bus_factory
        ctx.diagnostics = build_diagnostics(
            ctx.session.uds_config,
            ctx.workspace,
            ctx.paths.can_log_dir,
            report_context=ReportContext(
                repo_path=ctx.session.repo_path,
                branch_name=ctx.session.branch,
                branch_url=ctx.session.branch_url,
            ),
            report_generator=ctx.report_generator,
            registry=ctx.service_registry,
            min_free_disk_mb=ctx.settings.diagnostics.min_free_disk_mb,
            sleep=ctx.sleep,
            **kwargs,
        )
        logging.info(f"UDS Repo Path: {ctx.session.repo_path}")
        ctx.diagnostics.seed_key.available = self._probe_seed_key(ctx)

    @staticmethod
    def _probe_seed_key(ctx) -> bool:
        ui = ctx.require_ui()
        provider = ctx.diagnostics.seed_key
        retries = ctx.settings.diagnostics.udp_check_retries
        for attempt in range(1, retries + 1):
            ui.show(f"Checking\nUDP Server...\n\n{attempt}/{retries}")
            logging.info(f"{_BANNER}Checking UDP Server ({attempt}/{retries}){_BANNER}")
            try:
                if provider.check_server():
                    ui.show_for("UDP Server\nConnected", 2)
                    logging.info(f"{_BANNER}UDP Server Connected{_BANNER}")
                    return True
                logging.warning(f"{_BANNER}UDP Server Not Found ({attempt}/{retries}){_BANNER}")
            except Exception as e:
                logging.error(f"UDP Server check failed: {e}")
            if attempt < retries:
                ui.show_for(f"UDP Server\nNot Found\n\nRetry {attempt}/{retries}", 2)
        logging.warning(f"{_BANNER}UDP Server Unavailable - Continuing Startup{_BANNER}")
        ui.show_for("UDP Server\nUnavailable\n\nContinuing...", 3)
        return False


@register_step
class CanReadinessStep(StartupStep):
    """Optional: bring can0 up with the test config rates and wait for the ECU."""

    name = "can_readiness"

    def run(self, ctx):
        config = ctx.session.uds_config
        if not ctx.services.get("welcome_shown"):
            logging.info(f"{_BANNER}Welcome to Diagnostics{_BANNER}")
            ctx.sleep(2)
            ctx.services["welcome_shown"] = True
        logging.info(f"{_BANNER}Initializing{_BANNER}")
        ctx.sleep(1.5)
        logging.info(f"{_BANNER}Waiting for CAN{_BANNER}")
        if not config.bringup_on_startup:
            logging.info("CAN bring-up skipped (bringup_on_startup = false)")
            return
        ui = ctx.require_ui()
        can_if = CanInterface(ctx.settings.hardware.can_init.channel, ctx.runner)
        deadline = time.time() + ctx.settings.diagnostics.can_ready_timeout_s
        while time.time() < deadline:
            if not can_if.is_present():
                logging.warning("CAN0 not detected. Retrying...")
                ctx.sleep(1)
                continue
            can_if.bring_up(config.bitrate, config.dbitrate, config.restart_ms)
            ctx.sleep(1)
            try:
                # BUGFIX (B-05): V6.2.1 built a throw-away UDS client per
                # attempt and never closed it (leaking two sockets each time).
                ctx.diagnostics.transport.reset_connections()
                if ctx.diagnostics.transport.try_basic_communication():
                    logging.info(f"{_BANNER}ECU Ready{_BANNER}")
                    return
                logging.warning("No response from ECU.")
                ui.show("Waiting for ECU...")
            except Exception:
                logging.error("Exception during UDS handshake", exc_info=True)
                ui.show("ECU Comm Fail")
            ctx.sleep(2)
        logging.error("CAN or ECU did not respond within timeout.")
        ui.show_for("CAN/ECU Timeout\nCheck Setup", 5)
        raise SystemExit("Initialization failed: CAN or ECU not responding.")


@register_step
class UsbStorageStep(StartupStep):
    name = "usb_storage"

    def run(self, ctx):
        ui = ctx.ui
        ctx.usb = UsbStorage(
            output_dir=ctx.paths.output_dir,
            workspace=ctx.workspace,
            config_dir=ctx.paths.base_dir,
            notify=(ui.show if ui else (lambda text: None)),
            sleep=ctx.sleep,
        )


@register_step
class ServiceInstallStep(StartupStep):
    name = "service_install"

    def run(self, ctx):
        if ctx.settings.service.install:
            ServiceInstaller(ctx.settings.service, ctx.runner).install()


SESSION_STEPS = ["test_session", "diagnostics", "can_readiness"]
