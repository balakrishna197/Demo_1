"""Composition root: builds the object graph and runs the application.

This is the only module that knows concrete classes of every layer.  To
replace an implementation (another display, report format, key provider,
...) change the wiring here or - preferably - through app_settings.json
extension hooks, never inside the consumers.
"""

from __future__ import annotations

import argparse
import logging
import sys
from typing import List, Optional

from dtp_can import APP_NAME, APP_VERSION
from dtp_can.app.context import AppContext
from dtp_can.app.events import EventBus
from dtp_can.app.features import FEATURES, FeatureRegistry
from dtp_can.app.logging_setup import configure_logging
from dtp_can.app.menu import MainMenu
from dtp_can.app.paths import AppPaths
from dtp_can.app.startup import SESSION_STEPS, StartupPipeline
from dtp_can.app.workflows.session_setup import offline_session
from dtp_can.config.settings import AppSettings, load_settings, resolve_ui_mode
from dtp_can.diagnostics.services.registry import default_registry
from dtp_can.platform.shell import CommandRunner
from dtp_can.reporting.generator import HtmlReportGenerator
from dtp_can.testcases.workspace import TestcaseWorkspace
from dtp_can.vcs.report_tracker import ReportTracker

OFFLINE_SKIPPED_STEPS = {"ssh_setup", "wifi_setup", "wifi_monitor"}


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="uds_diagnostics", description=f"{APP_NAME} {APP_VERSION}")
    parser.add_argument("--settings", help="path to app_settings.json")
    parser.add_argument("--ui", choices=["auto", "hardware", "oled", "terminal", "console"],
                        help="override the UI mode (same as DTP_UI_MODE)")
    parser.add_argument("--offline", action="store_true",
                        help="bench mode: no Wi-Fi/SSH/Git; use --config/--testcase")
    parser.add_argument("--config", help="test configuration JSON (offline mode)")
    parser.add_argument("--testcase", help="testcase TXT (offline mode)")
    parser.add_argument("--version", action="version", version=f"{APP_NAME} {APP_VERSION}")
    return parser.parse_args(argv)


def load_extensions(settings: AppSettings):
    """Import extension modules and build the service registry."""
    ext = settings.extensions or {}
    FeatureRegistry.import_modules(ext.get("feature_modules", []))
    FeatureRegistry.import_modules(ext.get("startup_modules", []))
    registry = default_registry()
    registry.load_plugins(ext.get("service_handlers", []))
    return registry


def build_context(
    paths: AppPaths, settings: AppSettings, runner: Optional[CommandRunner] = None
) -> AppContext:
    registry = load_extensions(settings)
    return AppContext(
        settings=settings,
        paths=paths,
        events=EventBus(),
        runner=runner or CommandRunner(),
        workspace=TestcaseWorkspace(paths.support_dir, paths.selection_file),
        report_tracker=ReportTracker(paths.output_dir),
        service_registry=registry,
        report_generator=HtmlReportGenerator(settings.report.app_version),
    )


def shutdown_context(ctx: AppContext) -> None:
    if ctx.wifi_monitor is not None:
        ctx.wifi_monitor.stop()
    if ctx.diagnostics is not None:
        ctx.diagnostics.close()
    terminal_input = getattr(ctx.ui, "terminal_input", None) if ctx.ui else None
    if terminal_input is not None:
        terminal_input.restore()


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    paths = AppPaths.detect()
    paths.ensure()
    configure_logging(paths.debug_log)
    logging.info("%s %s starting (base dir %s)", APP_NAME, APP_VERSION, paths.base_dir)

    settings = load_settings(paths.base_dir, path=args.settings)
    if args.ui:
        settings.ui.mode = resolve_ui_mode(args.ui)

    ctx = build_context(paths, settings)
    steps = list(settings.startup)
    if args.offline:
        if not args.config:
            logging.error("--offline requires --config")
            return 2
        ctx.session = offline_session(args.config, args.testcase, ctx.workspace, paths.base_dir)
        steps = [s for s in steps if s not in OFFLINE_SKIPPED_STEPS]
    ctx.restart_session = lambda: StartupPipeline(
        [s for s in SESSION_STEPS if s in steps]
    ).run(ctx)

    try:
        StartupPipeline(steps).run(ctx)
        MainMenu(ctx.require_ui(), FEATURES.create(settings.menu, ctx)).run_forever()
    except KeyboardInterrupt:
        logging.info("Interrupted by user")
    finally:
        shutdown_context(ctx)
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
