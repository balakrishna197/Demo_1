"""Main menu: renders the configured features and dispatches the choice."""

from __future__ import annotations

import logging
from typing import List

from dtp_can.app.features.base import MenuFeature

MAX_BUTTON_OPTIONS = 4  # one hardware button per entry


class MainMenu:
    def __init__(self, ui, features: List[MenuFeature]):
        if not features:
            raise ValueError("The main menu needs at least one feature")
        self.ui = ui
        self.features = features

    def oled_text(self) -> str:
        return "\n".join(f"{i} {f.oled_label}" for i, f in enumerate(self.features, 1))

    def choose(self) -> MenuFeature:
        count = len(self.features)
        if count > MAX_BUTTON_OPTIONS:
            index = None
            while index is None:
                index = self.ui.select_from_list(
                    "Menu", self.features, formatter=lambda f: f.oled_label
                )
            return self.features[index]
        self.ui.print_instructions(
            ["Select an option:"]
            + [f"{i}. {f.terminal_label}" for i, f in enumerate(self.features, 1)]
            + [f"Keyboard: press 1-{count}."]
        )
        self.ui.show(self.oled_text())
        return self.features[self.ui.choose_menu_option(count)]

    def run_once(self) -> None:
        feature = self.choose()
        try:
            feature.run()
        except Exception:
            # A failing feature must not take the tester down; V6.2.1
            # crashed the whole process here (systemd then restarted it).
            logging.exception("Feature '%s' failed", feature.feature_id)
            self.ui.show_for(f"{feature.oled_label}\nFailed", 2)

    def run_forever(self) -> None:
        while True:
            self.run_once()
