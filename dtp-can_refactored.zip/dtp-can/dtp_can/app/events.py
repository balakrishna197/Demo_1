"""Minimal synchronous publish/subscribe bus.

Decouples producers (Wi-Fi monitor, test runner, session setup) from
consumers (display status bar, report tracking, third-party features).
Handlers run in the publisher's thread; a failing handler is logged and does
not affect the publisher or other handlers.
"""

from __future__ import annotations

import logging
import threading
from collections import defaultdict
from typing import Any, Callable, DefaultDict, List

Handler = Callable[[Any], None]

# Well-known topics
WIFI_STATUS = "wifi.status"            # payload: "W+" | "W~" | "W-"
SESSION_READY = "session.ready"        # payload: SessionInfo
TEST_RUN_STARTED = "test.run.started"  # payload: tester name
TEST_RUN_FINISHED = "test.run.finished"  # payload: RunResult
REPORTS_PUSHED = "reports.pushed"      # payload: branch name


class EventBus:
    def __init__(self):
        self._handlers: DefaultDict[str, List[Handler]] = defaultdict(list)
        self._lock = threading.Lock()

    def subscribe(self, topic: str, handler: Handler) -> Callable[[], None]:
        with self._lock:
            self._handlers[topic].append(handler)

        def unsubscribe() -> None:
            with self._lock:
                if handler in self._handlers[topic]:
                    self._handlers[topic].remove(handler)

        return unsubscribe

    def publish(self, topic: str, payload: Any = None) -> None:
        with self._lock:
            handlers = list(self._handlers.get(topic, ()))
        for handler in handlers:
            try:
                handler(payload)
            except Exception:
                logging.exception("Event handler for '%s' failed", topic)
