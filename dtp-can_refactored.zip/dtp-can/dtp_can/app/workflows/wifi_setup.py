"""Interactive Wi-Fi selection at start-up (V6.2.1 ``wifi_setup``)."""

from __future__ import annotations

import logging

from dtp_can.app.events import WIFI_STATUS, EventBus
from dtp_can.platform.wifi import STATUS_CONNECTED, WifiManager


class WifiSetupWorkflow:
    def __init__(self, ui, wifi: WifiManager, events: EventBus, sleep):
        self.ui = ui
        self.wifi = wifi
        self.events = events
        self.sleep = sleep

    def _connected(self, ssid: str, message: str) -> bool:
        self.wifi.mark_connected(ssid)
        self.events.publish(WIFI_STATUS, STATUS_CONNECTED)
        self.ui.show_for(f"{message}\n{ssid}", 1)
        return True

    def run(self) -> bool:
        logging.info("------------- Wifi Setup -------------")
        self.ui.show("Scanning\nWiFi...")
        networks = self.wifi.scan()
        if not networks:
            self.ui.show_for("No WiFi\nFound", 2)
            return False
        while True:
            self.ui.print_instructions(
                [
                    "WiFi setup:",
                    "Keyboard: A/P previous, D/N next, S/Enter select, Q cancel, "
                    "or type 1-9 for direct choice.",
                ]
            )
            selected = self.ui.select_from_list("WiFi", networks, allow_cancel=True)
            if selected is None:
                self.ui.show_for("No WiFi\nConnected", 1)
                return False
            ssid = networks[selected]
            if ssid in self.wifi.saved_connections():
                if self.wifi.is_connected(ssid):
                    return self._connected(ssid, "Using")
                if self.wifi.try_saved_connection(ssid):
                    return self._connected(ssid, "Connected")
                self.wifi.delete_connection(ssid)
            while True:
                password = self.ui.enter_password(ssid)
                self.ui.show(f"Connecting\n{ssid}")
                if self.wifi.connect(ssid, password):
                    return self._connected(ssid, "Connected")
                self.ui.show_for("Wrong Password\nTry Again", 1)
