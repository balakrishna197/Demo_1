"""Repository -> branch -> testcase/config selection (V6.2.1 ``git_setup``)."""

from __future__ import annotations

import logging
import os
from typing import Dict, List, Optional

from dtp_can.app.context import SessionInfo
from dtp_can.config.json_loader import load_json
from dtp_can.config.uds_config import UdsConfig
from dtp_can.core.errors import SessionSetupError, SetupCancelled
from dtp_can.testcases.discovery import find_testcases_and_configs
from dtp_can.testcases.workspace import TestcaseWorkspace
from dtp_can.vcs.branch_catalog import BranchCatalog
from dtp_can.vcs.git_client import GitClient


class SessionSetupWorkflow:
    def __init__(self, ui, git: GitClient, workspace: TestcaseWorkspace,
                 levels: List[str], sleep):
        self.ui = ui
        self.git = git
        self.workspace = workspace
        self.levels = levels
        self.sleep = sleep

    def _pick(self, title: str, items: List[str], formatter=str) -> str:
        index = self.ui.select_from_list(title, items, formatter=formatter)
        if index is None:
            raise SetupCancelled(f"{title} selection cancelled")
        logging.info(f"Selected {title}: {items[index]}")
        return items[index]

    def _pick_file(self, title: str, files: List[str]) -> str:
        if len(files) == 1:
            logging.info(f"Single {title.lower()} automatically selected: {files[0]}")
            self.ui.show_for(f"{title}\nAuto Selected", 1)
            return files[0]
        logging.info(f"Multiple {title.lower()} files found. Waiting for user selection.")
        return self._pick(title, files, formatter=os.path.basename)

    def select_branch(self) -> (str, Dict[str, str]):
        catalog = BranchCatalog(self.git.list_remote_branches(), self.levels)
        selected: List[str] = []
        for level in self.levels:
            options = catalog.options(selected)
            if not options:
                raise SessionSetupError(f"No {level.lower()} options found")
            selected.append(self._pick(level, options))
        branch = catalog.require_match(selected)
        logging.info(f"Selected Branch: {branch}")
        return branch, dict(zip(self.levels, selected))

    def run(self) -> SessionInfo:
        self.ui.show("Checking\nRepository...")
        try:
            branch, selections = self.select_branch()
            self.ui.show("Updating\nRepository...")
            repo_path = self.git.clone(branch)
            self.git.pull()
            logging.info("Repository clone/pull completed")
            commit = self.git.head_commit()
            branch_url = self.git.branch_url(commit)

            testcases, configs = find_testcases_and_configs(repo_path)
            logging.info(f"Testcase count: {len(testcases)}")
            logging.info(f"Config count: {len(configs)}")
            testcase = self._pick_file("Testcase", testcases)
            config_path = self._pick_file("Config", configs)

            self.workspace.install_testcase(testcase)
            uds_config = UdsConfig(load_json(config_path), path=config_path)

            logging.info("-" * 34)
            for key, value in {**selections, "Branch": branch,
                               "Testcase": testcase, "Config": config_path}.items():
                logging.info(f"{key:<10}: {value}")
            logging.info("-" * 34)
            self.ui.show_for("Repository\nReady", 2)
            return SessionInfo(
                branch=branch,
                branch_url=branch_url,
                commit=commit,
                repo_path=repo_path,
                testcase_path=testcase,
                config_path=config_path,
                uds_config=uds_config,
                selections=selections,
            )
        except Exception as e:
            logging.exception(f"Git setup failed: {e}")
            self.ui.show_for("Git Setup\nFailed", 2)
            raise


def offline_session(config_path: str, testcase_path: Optional[str],
                    workspace: TestcaseWorkspace, report_root: str) -> SessionInfo:
    """Session without Git (``--offline``): local config + testcase."""
    if testcase_path:
        workspace.install_testcase(testcase_path)
    active = workspace.active_testcase()
    return SessionInfo(
        branch="N/A",
        branch_url="",
        commit="",
        repo_path=report_root,
        testcase_path=active,
        config_path=config_path,
        uds_config=UdsConfig(load_json(config_path), path=config_path),
    )
