"""Menu feature contract and registry.

A *feature* is one entry of the main menu.  Features are looked up by id
from ``AppSettings.menu`` so the menu is configuration-driven: adding a
feature = new module with a ``@register_feature`` class + its id in
``app_settings.json`` (or ``extensions.feature_modules`` for external
packages).  No existing module is edited.
"""

from __future__ import annotations

import abc
import importlib
import logging
from typing import Dict, Iterable, List, Type


class MenuFeature(abc.ABC):
    #: unique id used in app_settings.json "menu"
    feature_id: str = ""
    #: short label for the 128x64 OLED (<= ~18 chars)
    oled_label: str = ""
    #: label for the console menu
    terminal_label: str = ""

    def __init__(self, context):
        self.context = context

    @abc.abstractmethod
    def run(self) -> None:
        """Execute the feature; must return to the menu when done."""


class FeatureRegistry:
    def __init__(self):
        self._features: Dict[str, Type[MenuFeature]] = {}

    def register(self, cls: Type[MenuFeature]) -> Type[MenuFeature]:
        if not cls.feature_id:
            raise ValueError(f"{cls.__name__} has no feature_id")
        if cls.feature_id in self._features and self._features[cls.feature_id] is not cls:
            raise ValueError(f"Feature id '{cls.feature_id}' already registered")
        self._features[cls.feature_id] = cls
        return cls

    def ids(self) -> List[str]:
        return sorted(self._features)

    def create(self, feature_ids: Iterable[str], context) -> List[MenuFeature]:
        features = []
        for fid in feature_ids:
            cls = self._features.get(fid)
            if cls is None:
                logging.error("Unknown menu feature '%s' ignored (known: %s)", fid, self.ids())
                continue
            features.append(cls(context))
        return features

    @staticmethod
    def import_modules(module_names: Iterable[str]) -> None:
        """Import external feature modules so their decorators register them."""
        for name in module_names:
            importlib.import_module(name)
            logging.info("Loaded feature module %s", name)


FEATURES = FeatureRegistry()


def register_feature(cls: Type[MenuFeature]) -> Type[MenuFeature]:
    return FEATURES.register(cls)
