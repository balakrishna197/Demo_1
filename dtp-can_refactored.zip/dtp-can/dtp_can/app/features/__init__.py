"""Menu features (plugins).  Importing this package registers the built-ins."""

from dtp_can.app.features import builtin as _builtin
from dtp_can.app.features.base import FEATURES, FeatureRegistry, MenuFeature, register_feature

BUILTIN_MODULE = _builtin.__name__

__all__ = ["BUILTIN_MODULE", "FEATURES", "FeatureRegistry", "MenuFeature", "register_feature"]
