"""Application context: the dependency-injection container.

Built once by the composition root (``bootstrap.py``) and handed to startup
steps, workflows and menu features.  Components never construct their own
collaborators; they read them from here.  ``services`` is an open registry
for extension modules that need to share objects with each other.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional

from dtp_can.app.events import EventBus
from dtp_can.app.paths import AppPaths
from dtp_can.config.settings import AppSettings
from dtp_can.config.uds_config import UdsConfig
from dtp_can.diagnostics.services.registry import ServiceRegistry
from dtp_can.platform.shell import CommandRunner
from dtp_can.reporting.generator import ReportGenerator
from dtp_can.testcases.workspace import TestcaseWorkspace
from dtp_can.vcs.report_tracker import ReportTracker


@dataclass
class SessionInfo:
    """Result of the repository/test selection workflow."""

    branch: str
    branch_url: str
    commit: str
    repo_path: str
    testcase_path: str
    config_path: str
    uds_config: UdsConfig
    selections: Dict[str, str] = field(default_factory=dict)


@dataclass
class AppContext:
    settings: AppSettings
    paths: AppPaths
    events: EventBus
    runner: CommandRunner
    workspace: TestcaseWorkspace
    report_tracker: ReportTracker
    service_registry: ServiceRegistry
    report_generator: ReportGenerator

    # populated by startup steps
    ui: Any = None                 # dtp_can.ui.interaction.UserInterface
    wifi: Any = None               # dtp_can.platform.wifi.WifiManager
    wifi_monitor: Any = None       # dtp_can.platform.wifi.WifiMonitor
    git: Any = None                # dtp_can.vcs.git_client.GitClient
    session: Optional[SessionInfo] = None
    diagnostics: Any = None        # dtp_can.diagnostics.factory.DiagnosticsStack
    usb: Any = None                # dtp_can.platform.usb_storage.UsbStorage

    # infrastructure seams (overridable in tests)
    bus_factory: Optional[Callable[..., Any]] = None
    sleep: Callable[[float], None] = field(default=None)  # type: ignore[assignment]

    # callbacks wired by the composition root
    restart_session: Callable[[], None] = lambda: None

    # open extension registry
    services: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if self.sleep is None:
            import time

            self.sleep = time.sleep

    def require_ui(self):
        if self.ui is None:
            raise RuntimeError("User interface display is not initialized")
        return self.ui

    def require_diagnostics(self):
        if self.diagnostics is None:
            raise RuntimeError("UDS client is not initialized")
        return self.diagnostics
