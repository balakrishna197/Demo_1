"""Single source of truth for on-device file locations.

``base_dir`` is the folder of the PyInstaller executable, or the project
root (the folder containing ``main.py``) when running from source.  V6.2.1
computed this independently in four modules, which only agreed in the frozen
build (bug B-01).
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass


def detect_base_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    package_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.dirname(package_dir)


@dataclass(frozen=True)
class AppPaths:
    base_dir: str

    @classmethod
    def detect(cls) -> "AppPaths":
        return cls(detect_base_dir())

    @property
    def logs_dir(self) -> str:
        return os.path.join(self.base_dir, "logs")

    @property
    def debug_log(self) -> str:
        return os.path.join(self.logs_dir, "uds_debug.log")

    @property
    def support_dir(self) -> str:
        return os.path.join(self.base_dir, "supportfiles")

    @property
    def selection_file(self) -> str:
        return os.path.join(self.base_dir, "selected_testcase.txt")

    @property
    def output_dir(self) -> str:
        return os.path.join(self.base_dir, "output")

    @property
    def can_log_dir(self) -> str:
        return os.path.join(self.output_dir, "can_logs")

    def ensure(self) -> None:
        for path in (
            self.logs_dir,
            self.support_dir,
            os.path.join(self.output_dir, "logs"),
            self.can_log_dir,
            os.path.join(self.output_dir, "html_reports"),
        ):
            os.makedirs(path, exist_ok=True)
