"""Root logger configuration (same format/handlers as V6.2.1)."""

from __future__ import annotations

import logging
import os

LOG_FORMAT = "%(asctime)s [%(levelname)s] %(message)s"


def configure_logging(log_file: str, level: int = logging.DEBUG) -> None:
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    logging.basicConfig(
        level=level,
        format=LOG_FORMAT,
        handlers=[logging.FileHandler(log_file, mode="w"), logging.StreamHandler()],
        force=True,
    )
