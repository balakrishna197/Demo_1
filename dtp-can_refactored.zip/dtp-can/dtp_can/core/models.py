"""Domain models shared by the execution and reporting layers.

``TestStep`` and ``WaitStep`` are ``NamedTuple``s so they stay drop-in
compatible with the positional 11-tuple / ``("WAIT", ms)`` shapes produced by
the original parser (unpacking, ``step[0] == "WAIT"``, ``len(step)`` all keep
working) while adding named field access.
"""

from __future__ import annotations

from typing import NamedTuple, Union


class TestStep(NamedTuple):
    tc_id: str
    description: str
    service: str
    subfunction: str
    expected: str
    write_data: str
    addressing: str
    format_type: str
    status_mask: str
    communication_type: str
    control_type: str

    @property
    def is_wait(self) -> bool:
        return False


class WaitStep(NamedTuple):
    kind: str  # always "WAIT"
    duration_ms: int

    @property
    def is_wait(self) -> bool:
        return True


Step = Union[TestStep, WaitStep]

PASS = "Pass"
FAIL = "Fail"
