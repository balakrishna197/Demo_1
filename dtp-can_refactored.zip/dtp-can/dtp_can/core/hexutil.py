"""Hex text <-> byte helpers.

Every module that turns operator-written hex text ("0x22", "F1 90", "01,02")
into bytes goes through here so cleaning rules exist in exactly one place.
Each helper keeps the precise semantics of the legacy code path it replaces;
the differences between them (odd-length handling, accepted separators) are
intentional and documented per function.
"""

from __future__ import annotations

import re
from typing import Iterable, List

HEX_DIGITS = frozenset("0123456789abcdefABCDEF")
_PAIR_RE = re.compile(r"[0-9A-F]+")
DEFAULT_PADDING = ("00", "AA", "20")


def is_hex(text: str) -> bool:
    return all(c in HEX_DIGITS for c in text)


def hex_field_to_bytes(value) -> bytes:
    """Lenient field parser (services 0x19, 0x27, 0x28, 0x85).

    Accepts ``0x`` prefixes, commas and spaces; left-pads odd length with 0.
    Raises ``ValueError`` on non-hex characters.
    """
    cleaned = (
        str(value or "")
        .replace("0x", "")
        .replace("0X", "")
        .replace(",", " ")
        .strip()
    )
    if not cleaned:
        return b""
    compact = "".join(cleaned.split())
    if len(compact) % 2 != 0:
        compact = "0" + compact
    if not is_hex(compact):
        raise ValueError(f"Invalid hex value: {value}")
    return bytes.fromhex(compact)


def parse_hex_byte_list(text: str) -> List[int]:
    """Whitespace separated byte tokens -> ints (expected/write columns)."""
    return [int(token, 16) for token in (text or "").strip().split()]


def split_hex_pairs(hex_text) -> List[str]:
    """Strict pair splitter used by the report: invalid input -> ``[]``."""
    clean = (
        (hex_text or "").strip().replace("0x", "").replace("0X", "")
        .replace(",", " ")
    )
    clean = clean.replace(" ", "").upper()
    if not clean or clean == "-":
        return []
    if len(clean) % 2 != 0:
        return []
    if not _PAIR_RE.fullmatch(clean):
        return []
    return [clean[i:i + 2] for i in range(0, len(clean), 2)]


def parse_expected_tokens(expected_response_data) -> List[str]:
    """Expected-response column -> upper-case byte tokens (report side)."""
    expected_response_data = (expected_response_data or "").replace(",", " ")
    return [
        b.replace("0x", "").upper()
        for b in expected_response_data.split()
        if b
    ]


def normalize_hex_tokens(data_bytes: Iterable) -> List[str]:
    return [b.strip().upper() for b in data_bytes if isinstance(b, str)]


def to_hex_tokens(data: Iterable[int]) -> List[str]:
    return [f"{b:02X}" for b in data]


def remove_trailing_padding(data_list, pad_byte: str):
    """Remove trailing occurrences of one pad byte token."""
    i = len(data_list)
    while i > 0 and data_list[i - 1].upper() == pad_byte.upper():
        i -= 1
    return data_list[:i]


def trim_trailing(values, pads) -> list:
    """Remove trailing values contained in ``pads`` (ints or tokens)."""
    trimmed = list(values or [])
    while trimmed and trimmed[-1] in pads:
        trimmed.pop()
    return trimmed


def normalize_did_string(value) -> str:
    if value is None:
        return ""
    text = str(value).strip().upper()
    if not text:
        return ""
    text = text.replace("0X", "")
    text = re.sub(r"\s+", "", text)
    if not text or not re.fullmatch(r"[0-9A-F]+", text):
        return ""
    return text


def looks_like_did(value) -> bool:
    normalized = normalize_did_string(value)
    return bool(normalized) and len(normalized) <= 8
