"""Exception hierarchy used across the application."""


class DtpError(Exception):
    """Base class for all application specific errors."""


class ConfigError(DtpError):
    """A configuration file is missing, malformed or incomplete."""


class SetupCancelled(DtpError):
    """The operator cancelled an interactive selection."""


class SessionSetupError(DtpError):
    """Selecting/cloning the test repository failed."""


class SeedKeyError(DtpError):
    """The seed/key service could not provide a key."""


class TestcaseFormatError(DtpError):
    """The TXT testcase file cannot be interpreted."""
