"""Pure, dependency-free domain helpers shared by every other layer."""
