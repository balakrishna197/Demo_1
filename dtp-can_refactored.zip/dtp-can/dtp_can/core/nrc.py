"""UDS negative response codes (ISO 14229-1, Annex A.1)."""

NRC_DESCRIPTIONS = {
    "10": "generalReject",
    "11": "serviceNotSupported",
    "12": "subFunctionNotSupported",
    "13": "incorrectMessageLengthOrInvalidFormat",
    "14": "responseTooLong",
    "21": "busyRepeatReques",  # spelling kept: it appears in reports
    "22": "conditionsNotCorrect",
    "23": "ISOSAEReserved",
    "24": "requestSequenceError",
    "31": "requestOutOfRange",
    "32": "ISOSAEReserved",
    "33": "securityAccessDenied",
    "34": "ISOSAEReserved",
    "35": "invalidKey",
    "36": "exceedNumberOfAttempts",
    "37": "requiredTimeDelayNotExpired",
    "70": "uploadDownloadNotAccepted",
    "71": "transferDataSuspended",
    "72": "generalProgrammingFailure",
    "73": "wrongBlockSequenceCounter",
    "78": "requestCorrectlyReceived-ResponsePending",
    "7E": "subFunctionNotSupportedInActiveSession",
    "7F": "serviceNotSupportedInActiveSession",
    "80": "ISOSAEReserved",
    "81": "rpmTooHigh",
    "82": "rpmTooLow",
    "83": "engineIsRunning",
    "84": "engineIsNotRunning",
    "85": "engineRunTimeTooLow",
    "86": "temperatureTooHigh",
    "87": "temperatureTooLow",
    "88": "vehicleSpeedTooHigh",
    "89": "vehicleSpeedTooLow",
    "8A": "throttle/PedalTooHigh",
    "8B": "throttle/PedalTooLow",
    "8C": "transmissionRangeNotInNeutral",
    "8D": "transmissionRangeNotInGear",
    "8E": "ISOSAEReserved",
    "8F": (
        "brakeSwitch(es)NotClosed (Brake Pedal not pressed "
        "or not applied)"
    ),
    "90": "shifterLeverNotInPark",
    "91": "torqueConverterClutchLocked",
    "92": "voltageTooHigh",
    "93": "voltageTooLow",
    "FF": "ISOSAEReserved",
}


def describe_nrc(nrc: str) -> str:
    return NRC_DESCRIPTIONS.get(nrc.upper(), f"Unknown NRC: {nrc}")
