"""ISO 15765-2 (ISO-TP) protocol-control-information helpers.

Pure functions working on either ``int`` byte lists (live transport side) or
hex-token lists (ASC/report side).
"""

from __future__ import annotations

from typing import List, Optional, Tuple

SINGLE_FRAME = 0x0
FIRST_FRAME = 0x1
CONSECUTIVE_FRAME = 0x2
FLOW_CONTROL = 0x3

NEGATIVE_RESPONSE_SID = 0x7F
NRC_RESPONSE_PENDING = 0x78


def frame_type(pci: int) -> int:
    return (pci >> 4) & 0x0F


def first_frame_length(byte0: int, byte1: int) -> int:
    return ((byte0 & 0x0F) << 8) | byte1


def is_response_pending(payload) -> bool:
    """``7F <sid> 78`` on an already PCI-stripped int payload."""
    return (
        len(payload) >= 3
        and payload[0] == NEGATIVE_RESPONSE_SID
        and payload[2] == NRC_RESPONSE_PENDING
    )


def stmin_to_seconds(stmin_value) -> float:
    if isinstance(stmin_value, str):
        stmin_value = int(stmin_value, 0)
    if 0 <= stmin_value <= 0x7F:
        return stmin_value / 1000.0
    if 0xF1 <= stmin_value <= 0xF9:
        return (stmin_value - 0xF0) / 10000.0
    return 0.0


# --- token (hex string) based helpers used by the report ------------------

def extract_payload_tokens(data: List[str]) -> List[str]:
    """Strip SF/FF PCI from a token list; other frames returned unchanged."""
    if not data:
        return []
    try:
        pci = int(data[0], 16)
    except ValueError:
        return data
    ftype = frame_type(pci)
    if ftype == SINGLE_FRAME:
        return data[1:1 + (pci & 0x0F)]
    if ftype == FIRST_FRAME and len(data) >= 2:
        return data[2:2 + first_frame_length(pci, int(data[1], 16))]
    return data


def build_display_frame(payload: List[str]) -> List[str]:
    """Re-add an SF or FF PCI so a payload can be displayed as a frame."""
    payload = list(payload or [])
    if len(payload) <= 15:
        return [f"{len(payload):02X}"] + payload
    total_len = len(payload)
    return [
        f"{0x10 | ((total_len >> 8) & 0x0F):02X}",
        f"{total_len & 0xFF:02X}",
    ] + payload


# --- int based helpers used by the live transport --------------------------

def extract_payload_view(response: bytes) -> Tuple[bytearray, Optional[int]]:
    if not response:
        return bytearray(), None
    if len(response) >= 2 and frame_type(response[0]) == FIRST_FRAME:
        total_len = first_frame_length(response[0], response[1])
        return bytearray(response[2:]), total_len
    if len(response) >= 1 and frame_type(response[0]) == SINGLE_FRAME:
        total_len = response[0] & 0x0F
        return bytearray(response[1:1 + total_len]), total_len
    return bytearray(response), None
