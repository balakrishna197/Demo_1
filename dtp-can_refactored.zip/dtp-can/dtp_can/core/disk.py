"""Free disk space probe."""

from __future__ import annotations

import shutil
from typing import Tuple


def check_disk_space(path: str = "/", min_required_mb: int = 50) -> Tuple[bool, int]:
    _total, _used, free = shutil.disk_usage(path)
    free_mb = free // (1024 * 1024)
    return free_mb >= min_required_mb, free_mb
