"""Pass/fail evaluation of a recorded response against the expected bytes.

The verdict is computed offline from the ASC log, exactly as in V6.2.1.
"""

from dtp_can.core.hexutil import normalize_hex_tokens as normalize_hex_bytes
from dtp_can.core.hexutil import remove_trailing_padding
from dtp_can.core.isotp_frames import extract_payload_tokens as extract_isotp_payload
from dtp_can.core.nrc import describe_nrc as get_failure_reason


def normalize_response_payload(data_bytes):
    data = normalize_hex_bytes(data_bytes)
    if not data:
        return []

    try:
        pci = int(data[0], 16)
    except ValueError:
        return data

    frame_type = (pci >> 4) & 0x0F
    if frame_type in (0x0, 0x1):
        return extract_isotp_payload(data)
    return data


def normalize_for_compare(data_bytes):
    raw = remove_trailing_padding(
        remove_trailing_padding(normalize_hex_bytes(data_bytes), "00"),
        "AA",
    )
    payload = remove_trailing_padding(
        remove_trailing_padding(extract_isotp_payload(raw), "00"),
        "AA",
    )
    return raw, payload


def trim_compare_padding(data_bytes):
    trimmed = list(data_bytes or [])
    while trimmed and trimmed[-1] in ("00", "AA", "20"):
        trimmed.pop()
    return trimmed


def response_compare_variants(data_bytes):
    raw = normalize_hex_bytes(data_bytes)
    payload = normalize_response_payload(raw)
    variants = []

    for candidate in (raw, payload):
        if candidate and candidate not in variants:
            variants.append(candidate)

        trimmed = trim_compare_padding(candidate)
        if trimmed and trimmed not in variants:
            variants.append(trimmed)

    return variants


def is_empty_positive_read_response(data_bytes):
    payload = normalize_response_payload(data_bytes)
    if len(payload) < 3 or payload[0] != "62":
        return False

    did = "".join(payload[1:3]).upper()
    if did == "F18B":
        return False

    did_data = remove_trailing_padding(
        remove_trailing_padding(payload[3:], "00"),
        "AA",
    )
    return len(did_data) == 0


def get_status(actual_data, expected_response_data):
    """
    Determines Pass/Fail by comparing full actual vs expected response.
    Handles negative responses with NRCs too.
    """
    if not actual_data:
        return "Fail", "No response received"
    if not expected_response_data:
        return "Fail", "Expected response not specified"

    actual_variants = response_compare_variants(actual_data)
    expected_variants = response_compare_variants(expected_response_data)

    if any(
        actual == expected
        for actual in actual_variants
        for expected in expected_variants
    ):
        return "Pass", ""

    # 🟥 Negative Response Handling
    _actual_raw, actual_payload = normalize_for_compare(actual_data)
    if len(actual_payload) >= 3 and actual_payload[0] == "7F":
        nrc = actual_payload[2]
        return (
            "Fail",
            f"Negative Response (0x{nrc}: {get_failure_reason(nrc)})",
        )

    if is_empty_positive_read_response(actual_data):
        return "Fail", "Empty response data"

    return "Fail", "Response mismatch"
