"""Maps diagnostic requests seen in the ASC log back to TXT testcase rows.
"""

from collections import defaultdict
from dataclasses import dataclass

from dtp_can.core.hexutil import parse_expected_tokens as parse_expected_bytes
from dtp_can.core.hexutil import split_hex_pairs
from dtp_can.core.isotp_frames import build_display_frame


def build_request_payload_from_step(step):
    if not step or step[0] == "WAIT":
        return []

    (
        _tc_id,
        _description,
        sid,
        sub,
        _expected_response_data,
        write_data,
        _addressing,
        _format_type,
        status_mask,
        communication_type,
        controltype,
    ) = step

    sid_bytes = split_hex_pairs(sid)
    sub_bytes = split_hex_pairs(sub)
    write_bytes = split_hex_pairs(write_data)
    status_mask_bytes = split_hex_pairs(status_mask)
    communication_type_bytes = split_hex_pairs(communication_type)
    controltype_bytes = split_hex_pairs(controltype)

    if not sid_bytes:
        return []

    service = sid_bytes[0]
    payload = list(sid_bytes)
    payload.extend(sub_bytes)

    if service == "19":
        payload.extend(status_mask_bytes)
        payload.extend(write_bytes)
        return payload

    if service == "28":
        payload.extend(communication_type_bytes)
        payload.extend(write_bytes)
        return payload

    if service == "2F":
        payload.extend(controltype_bytes)
        payload.extend(write_bytes)
        return payload

    payload.extend(write_bytes)
    return payload


def payload_to_display_frame(payload):
    return build_display_frame(payload)


def build_request_candidate_keys(request_bytes):
    if not request_bytes:
        return []

    known_sids = {
        "10", "11", "14", "19", "22", "27", "28", "2E", "2F",
        "31", "3E", "85",
    }
    sid_index = -1
    sid = ""

    for idx, byte in enumerate(request_bytes):
        if byte.upper() in known_sids:
            sid_index = idx
            sid = byte.upper()
            break

    if sid_index == -1:
        return []

    candidate_keys = []
    remaining_len = len(request_bytes) - sid_index - 1
    for length in range(remaining_len, -1, -1):
        sub = "".join(
            request_bytes[sid_index + 1: sid_index + 1 + length]
        ).upper()
        candidate_keys.append((sid, sub))
    return candidate_keys


def build_occurrence_key(tc_id, occurrence_index):
    return f"{tc_id}__occurrence_{occurrence_index}"


def build_placeholder_request_bytes(step):
    if not step or step[0] == "WAIT":
        return []
    payload = build_request_payload_from_step(step)
    if not payload:
        return []
    return build_display_frame(payload)


def build_placeholder_message(tc_id, occurrence_key, step):
    (
        _tc_id,
        description,
        _sid,
        _sub,
        expected_response_data,
        _write_data,
        _addressing,
        format_type,
        *_rest,
    ) = step

    expected_bytes = [
        b.replace("0x", "").upper()
        for b in (expected_response_data or "").split()
        if b
    ]

    return {
        "timestamp": 0.0,
        "can_id": "",
        "direction": "Tx",
        "data_bytes": build_placeholder_request_bytes(step),
        "desc": description.strip(),
        "tc_id": tc_id,
        "occurrence_key": occurrence_key,
        "format": (format_type or "Hex").strip().capitalize(),
        "expected_resp": expected_bytes,
        "status": "Fail",
        "failure_reason": "Testcase not observed in ASC log",
        "response": {},
        "response_data_bytes": [],
        "response_type": (
            "Not Observed in ASC"
        ),
    }


def ensure_all_testcases_present(messages_by_tc, steps):
    occurrence_counts = defaultdict(int)

    for step in steps:
        if not step or step[0] == "WAIT":
            continue

        tc_id = step[0].strip()
        occurrence_counts[tc_id] += 1
        occurrence_key = build_occurrence_key(tc_id, occurrence_counts[tc_id])

        if occurrence_key in messages_by_tc:
            continue

        messages_by_tc[occurrence_key].append(
            build_placeholder_message(
                tc_id, occurrence_key, step
            )
        )

    return messages_by_tc


def get_testcase_order(steps):
    ordered_ids = []
    occurrence_counts = defaultdict(int)

    for step in steps:
        if not step or step[0] == "WAIT":
            continue

        tc_id = step[0].strip()
        occurrence_counts[tc_id] += 1
        ordered_ids.append(
            build_occurrence_key(tc_id, occurrence_counts[tc_id])
        )

    return ordered_ids


@dataclass
class TestcaseDefinition:
    index: int
    tc_id: str
    occurrence_key: str
    desc: str
    request_payload: list
    request_keys: list
    expected_resp: list
    format_type: str
    step: tuple


class TestcaseMatcher:
    def __init__(self, definitions):
        self.definitions = definitions
        self.cursor = 0
        self.used_indices = set()

    def _mark_used(self, definition):
        self.used_indices.add(definition.index)
        self.cursor = max(self.cursor, definition.index + 1)
        return definition

    def has_matched_payload(self, request_payload):
        """Return whether this exact request was already consumed by a
        testcase.

        Once all matching definitions have been consumed, a repeated request in
        the ASC is a retry/duplicate capture, not another result to report.
        """
        return any(
            definition.index in self.used_indices
            and definition.request_payload == request_payload
            for definition in self.definitions
        )

    def _iter_candidates(self, start_from_cursor=True):
        if start_from_cursor:
            for idx in range(self.cursor, len(self.definitions)):
                if idx not in self.used_indices:
                    yield self.definitions[idx]
        for idx in range(0, len(self.definitions)):
            if idx >= self.cursor and start_from_cursor:
                continue
            if idx not in self.used_indices:
                yield self.definitions[idx]

    def _is_dynamic_security_access_key_request(
            self, definition, request_payload):
        expected = definition.request_payload or []
        if (len(expected) != 2
                or len(request_payload) <= len(expected)):
            return False
        if (expected[0] != "27"
                or request_payload[:2] != expected):
            return False
        try:
            return int(expected[1], 16) % 2 == 0
        except ValueError:
            return False

    def _match_dynamic_security_access_key_request(
            self, request_payload, start_from_cursor=True):
        for definition in self._iter_candidates(
                start_from_cursor=start_from_cursor):
            if self._is_dynamic_security_access_key_request(
                    definition, request_payload):
                return self._mark_used(definition)
        return None

    def match(self, request_payload):
        if not request_payload:
            return None

        request_keys = build_request_candidate_keys(request_payload)
        for definition in self._iter_candidates(start_from_cursor=True):
            if definition.request_payload == request_payload:
                return self._mark_used(definition)

        for definition in self._iter_candidates(start_from_cursor=False):
            if definition.request_payload == request_payload:
                return self._mark_used(definition)

        dynamic_security_match = (
            self._match_dynamic_security_access_key_request(
                request_payload,
                start_from_cursor=True,
            )
        )
        if dynamic_security_match:
            return dynamic_security_match

        dynamic_security_match = (
            self._match_dynamic_security_access_key_request(
                request_payload,
                start_from_cursor=False,
            )
        )
        if dynamic_security_match:
            return dynamic_security_match

        # Real UDS requests must not be matched by partial prefixes like
        # 22 F1, otherwise retries for F18B can steal F18C/F193 testcases.
        if request_payload:
            return None

        for definition in self._iter_candidates(start_from_cursor=True):
            if any(key in request_keys for key in definition.request_keys):
                return self._mark_used(definition)

        for definition in self._iter_candidates(start_from_cursor=False):
            if any(key in request_keys for key in definition.request_keys):
                return self._mark_used(definition)

        return None


def build_testcase_definitions(steps):
    definitions = []
    occurrence_counts = defaultdict(int)

    running_index = 0
    for step in steps:
        if not step or step[0] == "WAIT":
            continue

        (
            step_tc_id,
            description,
            _sid,
            _sub,
            expected_response_data,
            _write_data,
            _addressing,
            format_type,
            *_rest,
        ) = step

        tc_id = step_tc_id.strip()
        occurrence_counts[tc_id] += 1
        request_payload = build_request_payload_from_step(step)
        definitions.append(
            TestcaseDefinition(
                index=running_index,
                tc_id=tc_id,
                occurrence_key=build_occurrence_key(
                    tc_id, occurrence_counts[tc_id]
                ),
                desc=description.strip(),
                request_payload=request_payload,
                request_keys=build_request_candidate_keys(request_payload),
                expected_resp=parse_expected_bytes(expected_response_data),
                format_type=(format_type or "Hex").strip().capitalize(),
                step=step,
            )
        )
        running_index += 1

    return definitions


def build_message_from_definition(
    definition, request_timestamp, request_bytes
):
    addressing = ""
    if definition.step and len(definition.step) > 6:
        addressing = definition.step[6]

    return {
        "timestamp": request_timestamp,
        "can_id": "",
        "direction": "Tx",
        "data_bytes": payload_to_display_frame(request_bytes),
        "request_payload": request_bytes,
        "desc": definition.desc,
        "tc_id": definition.tc_id,
        "occurrence_key": definition.occurrence_key,
        "format": definition.format_type,
        "expected_resp": definition.expected_resp,
        "addressing": addressing,
        "status": "Pending",
    }


def build_unmatched_message(request_timestamp, request_bytes):
    return {
        "timestamp": request_timestamp,
        "can_id": "",
        "direction": "Tx",
        "data_bytes": payload_to_display_frame(request_bytes),
        "request_payload": request_bytes,
        "desc": "ASC diagnostic request not found in TXT testcase definitions",
        "tc_id": "UNMATCHED_ASC",
        "occurrence_key": f"UNMATCHED_ASC__{request_timestamp:.6f}",
        "format": "Hex",
        "expected_resp": [],
        "status": "Pending",
    }
