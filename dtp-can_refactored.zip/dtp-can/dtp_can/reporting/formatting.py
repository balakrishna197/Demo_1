"""Formatting helpers for report metadata (file times, time windows, bytes).
"""

import datetime
import logging
import os
import re


def flatten_bytes(data):
    flat = []
    for item in data:
        if isinstance(item, list):

            flat.extend(item)
        else:
            flat.append(item)
    return flat


def get_valid_request_data(data_bytes):
    """
    Extracts the actual data from a UDS request.
    Assumes the first byte is the PCI, which tells us how many bytes follow.
    """

    if not data_bytes:
        return data_bytes
    try:
        pci = int(data_bytes[0], 16)
        if pci <= 0x07:
            # Single-frame: first byte is length of remaining data
            total_len = pci + 1  # include PCI itself
            return data_bytes[:total_len]
    except (TypeError, ValueError, IndexError):
        pass
    return data_bytes


def format_generated_entry(filename, generated_at):
    if not filename or str(filename).upper() == "N/A":
        return "N/A"
    safe_filename = os.path.basename(filename) if filename else "N/A"
    safe_generated_at = generated_at or "N/A"
    if str(safe_generated_at).upper() == "N/A":
        return safe_filename
    safe_generated_at = normalize_generated_time_display(safe_generated_at)
    return f"{safe_filename} ({safe_generated_at})"


def normalize_generated_time_display(generated_at):
    if not generated_at:
        return "N/A"

    raw_value = str(generated_at).strip()
    if not raw_value or raw_value.upper() == "N/A":
        return "N/A"

    cleaned_value = re.sub(
        r"\s+Time\s*:\s*",
        " ",
        re.sub(r"\bDate\s*:\s*", "", raw_value, flags=re.IGNORECASE),
        flags=re.IGNORECASE,
    ).strip()

    for fmt in (
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%d-%m-%Y %H:%M:%S",
        "%d-%m-%Y %H:%M",
        "%d/%m/%Y %H:%M:%S",
        "%d/%m/%Y %H:%M",
    ):
        try:
            parsed = datetime.datetime.strptime(cleaned_value, fmt)
            return parsed.strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue

    return cleaned_value


def extract_generated_time_from_filename(file_path):
    filename = os.path.basename(file_path or "")
    match = re.search(r"_(\d{8})_(\d{6})(?=\.[^.]+$)", filename)

    if not match:
        return "N/A"

    try:
        timestamp_str = f"{match.group(1)}_{match.group(2)}"
        return datetime.datetime.strptime(
            timestamp_str, "%Y%m%d_%H%M%S"
        ).strftime("%Y-%m-%d %H:%M:%S")
    except ValueError as exc:
        logging.warning(
            f"Failed to extract generated time from filename {filename}: {exc}"
        )
        return "N/A"


def get_file_generated_time(file_path):
    try:
        timestamp = os.path.getmtime(file_path)
        return datetime.datetime.fromtimestamp(timestamp).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
    except Exception as exc:
        logging.warning(
            f"Failed to read file timestamp for {file_path}: {exc}"
        )
        return "N/A"


def get_json_generated_time(file_path):
    try:
        filename = os.path.basename(file_path)

        # Extract YYMMDDHHMM from the end of the filename.
        match = re.search(r"_(\d{10})\.json$", filename, re.IGNORECASE)

        if match:
            timestamp_str = match.group(1)
            parsed_time = datetime.datetime.strptime(
                timestamp_str, "%y%m%d%H%M"
            )
            file_generated_time = get_file_generated_time(file_path)
            if file_generated_time != "N/A":
                try:
                    parsed_file_time = datetime.datetime.strptime(
                        file_generated_time, "%Y-%m-%d %H:%M:%S"
                    )
                    parsed_time = parsed_time.replace(
                        second=parsed_file_time.second
                    )
                except ValueError:
                    pass

            return parsed_time.strftime("%Y-%m-%d %H:%M:%S")

        return get_file_generated_time(file_path)

    except Exception as exc:
        logging.warning(
            "Failed to extract JSON generated time from "
            f"{file_path}: {exc}"
        )
        return "N/A"


def format_time_with_offset(display_time, offset_seconds):
    if not display_time:
        return "N/A"
    if offset_seconds is None:
        return display_time
    return f"{display_time} ({offset_seconds:.5f})"


def to_time_display(dt_value):
    if not dt_value:
        return None
    return dt_value.strftime("%H:%M:%S.%f")[:-3]
