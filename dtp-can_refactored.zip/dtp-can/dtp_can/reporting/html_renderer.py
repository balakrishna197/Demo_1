"""Renders the self-contained HTML test report.

The output is byte-for-byte identical to V6.2.1 (guarded by
``tests/regression/test_golden_master.py``).  The former 790-line function is
split into: message ordering, ECU header assembly (``reporting.ecu_info``),
time-window computation, the page header template and per-testcase blocks.
"""

import datetime
import logging
import os
from collections import OrderedDict
from html import escape

from dtp_can.core.did_decoder import decode_special_did_value
from dtp_can.core.hexutil import remove_trailing_padding
from dtp_can.reporting.asc_parser import get_asc_measurement_window
from dtp_can.reporting.ecu_info import build_ecu_header
from dtp_can.reporting.formatting import (
    extract_generated_time_from_filename,
    flatten_bytes,
    format_generated_entry,
    format_time_with_offset,
    get_file_generated_time,
    get_json_generated_time,
    get_valid_request_data,
    to_time_display,
)
from dtp_can.reporting.verdict import (
    is_empty_positive_read_response,
    normalize_response_payload,
)

REPORT_CSS = """  body { font-family: Arial, sans-serif; margin: 10px; color: #111; }
  .report-title {
    background: #d9d9d9;
    text-align: center;
    padding: 4px 0 5px;
    margin-bottom: 12px;
  }
  .report-title h1 {
    color: #111;
    font-size: 28px;
    margin: 0;
    font-weight: 700;
  }
  .section-title {
    background: #d9d9d9;
    text-align: center;
    font-weight: 700;
    padding: 6px;
    margin-top: 14px;
  }
  .overall-row {
    display: grid;
    grid-template-columns: 380px minmax(0, 1fr);
    align-items: center;
    gap: 12px;
    margin: 8px 0 14px;
  }
  .overall-row h2 {
    color: #111;
    margin: 0 0 0 60px;
    font-size: 16px;
    white-space: nowrap;
  }
  .overall-bar {
    height: 18px;
    line-height: 18px;
    color: #111;
    font-size: 16px;
    font-weight: 700;
    text-align: center;
  }
  .overall-pass { background: #35a853; }
  .overall-fail { background: #ee0000; }
  .general-grid {
    display: grid;
    grid-template-columns: minmax(520px, 1fr) minmax(420px, 520px);
    gap: 56px;
    max-width: 1280px;
    margin: 0 auto;
    padding: 16px 14px 24px;
  }
  .info-block h3 {
    margin: 0 0 10px;
    font-size: 14px;
  }
  .info-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 6px;
    font-size: 13px;
  }
  .info-table td {
    border: none !important;
    padding: 3px 6px;
    vertical-align: top;
  }
  .info-table td:first-child {
    width: 170px;
    font-weight: 700;
    white-space: nowrap;
  }
  .overview-grid {
    display: grid;
    grid-template-columns: minmax(520px, 1fr) 360px;
    gap: 56px;
    align-items: start;
    max-width: 1280px;
    margin: 0 auto;
    padding: 16px 14px;
  }
  .stats-table {
    width: 430px;
    border-collapse: collapse;
    font-size: 13px;
  }
  .stats-table td, .stats-table th {
    border: 1px solid #ccc;
    padding: 5px 8px;
  }
  .stats-table th {
    background: #eee;
    text-align: left;
  }
  .pass { color: green; font-weight: bold; }
  .fail { color: red; font-weight: bold; }
  .chart-filter-row {
    display: flex;
    align-items: center;
    gap: 18px;
    margin-top: 12px;
    margin-left: 24px;
    font-size: 14px;
  }
  .chart-filter-item {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    user-select: none;
  }
  .chart-filter-swatch {
    width: 28px;
    height: 12px;
    display: inline-block;
  }
  .chart-filter-label.inactive {
    text-decoration: line-through;
    opacity: 0.6;
  }
  #chart-container { width: 300px; }
  table { border-collapse: collapse; width: 100%; margin-top: 10px; }
  th, td { border: 1px solid #ccc; padding: 8px; }
  th { background: #f0f0f0; }
  summary { font-weight: bold; cursor: pointer; }
"""

CHART_SCRIPT_TEMPLATE = """    <script>
        let activeFilter = null;

        function updateFilterLabels() {
            const passedLabel = document.getElementById('passedFilterLabel');
            const failedLabel = document.getElementById('failedFilterLabel');

            passedLabel.classList.toggle(
                'inactive', activeFilter === 'Failed'
            );
            failedLabel.classList.toggle(
                'inactive', activeFilter === 'Passed'
            );
        }

        function setChartFilter(label) {
            activeFilter = label;
            filterCasesByLabel(label);
            updateFilterLabels();
            const filterIndex = chart.data.labels.indexOf(label);
            if (filterIndex >= 0) {
                chart.setActiveElements([
                    { datasetIndex: 0, index: filterIndex }
                ]);
            }
            chart.update();
        }

        function showAllCases() {
            activeFilter = null;
            document.querySelectorAll('.case-block').forEach(el => {
                el.style.display = 'block';
            });
            chart.setActiveElements([]);
            updateFilterLabels();
            chart.update();
        }

        function filterCasesByLabel(label) {
            document.querySelectorAll('.case-block').forEach(el => {
                el.style.display = 'none';
            });
            if (label === 'Passed') {
                document.querySelectorAll('.pass-case').forEach(el => {
                    el.style.display = 'block';
                });
            } else if (label === 'Failed') {
                document.querySelectorAll('.fail-case').forEach(el => {
                    el.style.display = 'block';
                });
            }
        }

        const ctx = document.getElementById('passFailChart').getContext('2d');
        const chart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Passed', 'Failed'],
                datasets: [{
                    data: [__PASSED__, __FAILED__],
                    backgroundColor: ['#4CAF50', '#F44336']
                }]
            },
            options: {
                responsive: true,
                onClick: function (evt, item) {
                    const segment = chart.getElementsAtEventForMode(
                        evt, 'nearest', { intersect: true }, true
                    );
                    if (!segment.length) return;
                    const label = chart.data.labels[segment[0].index];
                    setChartFilter(label);
                },
                plugins: {
                    legend: { display: false },
                    title: { display: true, text: 'Test Case Results' }
                }
            }
        });

        updateFilterLabels();
    </script>
"""


def testcase_status(steps):
    # A retry must not mask an earlier timeout or response mismatch.
    if steps and all(msg.get("status") == "Pass" for msg in steps):
        return "Pass"
    return "Fail"


def order_messages(messages_by_tc, testcase_order):
    """TXT order first, then anything only seen in the ASC (unmatched)."""
    ordered = OrderedDict()
    for occurrence_key in testcase_order or []:
        if occurrence_key in messages_by_tc:
            ordered[occurrence_key] = messages_by_tc[occurrence_key]
    for occurrence_key, steps in messages_by_tc.items():
        if occurrence_key not in ordered:
            ordered[occurrence_key] = steps
    return ordered


def _is_number(value):
    return isinstance(value, (int, float))


def compute_time_window(asc_file_path, start_ts, test_start_time, test_end_time):
    """Returns ``(start_display, end_display, duration_seconds)``.

    Prefers the ASC measurement clock; falls back to the runner's wall-clock
    timestamps when the log header cannot be parsed.
    """
    asc_window = get_asc_measurement_window(asc_file_path)
    start_offset = asc_window["first_event_offset"]
    if start_offset is None and _is_number(start_ts):
        start_offset = start_ts
    end_offset = asc_window["last_event_offset"]
    measurement_start = asc_window["measurement_start"]

    absolute_start_time = None
    if isinstance(measurement_start, datetime.datetime) and _is_number(start_offset):
        absolute_start_time = measurement_start + datetime.timedelta(seconds=float(start_offset))
    elif test_start_time:
        absolute_start_time = test_start_time

    absolute_end_time = None
    if absolute_start_time is not None and _is_number(start_offset) and _is_number(end_offset):
        absolute_end_time = absolute_start_time + datetime.timedelta(
            seconds=float(end_offset - start_offset)
        )
    elif isinstance(measurement_start, datetime.datetime) and _is_number(end_offset):
        absolute_end_time = measurement_start + datetime.timedelta(seconds=float(end_offset))
    elif test_end_time:
        absolute_end_time = test_end_time

    if _is_number(start_offset) and _is_number(end_offset):
        duration = max(0.0, end_offset - start_offset)
    elif absolute_start_time and absolute_end_time:
        duration = (absolute_end_time - absolute_start_time).total_seconds()
    else:
        duration = 0.0

    return (
        format_time_with_offset(to_time_display(absolute_start_time), start_offset),
        format_time_with_offset(to_time_display(absolute_end_time), end_offset),
        duration,
    )


def _generated_time(path):
    value = extract_generated_time_from_filename(path)
    return get_file_generated_time(path) if value == "N/A" else value


def safe_text(value, default="N/A"):
    return default if value is None else str(value)


def _format_description(desc):
    if "PreCondition:" in desc and "Testcase" in desc:
        parts = desc.split("PreCondition:", 1)[1].split("Testcase", 1)
        return (
            f"<b>PreCondition:</b> {escape(parts[0].strip())}<br>"
            f"<b>Testcase:</b>{escape(parts[1].strip())}"
        )
    if "PreCondition:" in desc:
        return f"<b>PreCondition:</b> {escape(desc.split('PreCondition:', 1)[1].strip())}"
    return escape(desc.strip())


def _with_decoded(full_hex_str, decoded):
    return f"{full_hex_str} → {decoded}" if decoded else full_hex_str


def _format_response_data(msg, response, raw_resp, response_type):
    # Keep zero bytes for DID values such as Manufacturing Date 00 00 00 00.
    clean_resp = remove_trailing_padding(raw_resp, "AA")
    payload_bytes = normalize_response_payload(raw_resp)
    format_type = msg.get("format", "Hex").strip().lower()
    try:
        if is_empty_positive_read_response(raw_resp):
            text = "ECU No response"
        else:
            full_hex_str = " ".join(payload_bytes if payload_bytes else clean_resp)
            payload = payload_bytes
            # Skip positive-response SID + DID to get the data bytes.
            if "62" in [b.upper() for b in payload]:
                idx = next(i for i, b in enumerate(payload) if b.upper() == "62")
                payload = payload[idx + 3:] if len(payload) > idx + 2 else []
            special_value = decode_special_did_value(msg.get("desc", ""), payload)
            if special_value is not None:
                text = _with_decoded(full_hex_str, special_value)
            elif format_type == "ascii":
                ascii_str = ""
                if payload and all(32 <= int(b, 16) <= 126 for b in payload):
                    ascii_str = "".join(chr(int(b, 16)) for b in payload)
                text = _with_decoded(full_hex_str, ascii_str)
            elif format_type == "decimal":
                text = _with_decoded(full_hex_str, " ".join(str(int(b, 16)) for b in payload))
            else:
                text = full_hex_str
    except Exception:
        text = " ".join(clean_resp)

    if response_type == "No Response":
        text = msg.get("response_note") or "ECU No response"
    elif response_type in ("Error Frame", "Empty Frame"):
        text = escape(response.get("raw", response_type))
    return text


def _render_message_rows(msg, step_count):
    req_data_str = " ".join(flatten_bytes(get_valid_request_data(msg.get("data_bytes", []))))
    expected = remove_trailing_padding(
        remove_trailing_padding(msg.get("expected_resp", []), "00"), "AA"
    )
    expected_str = " ".join(flatten_bytes(expected))
    response = msg.get("response", {})
    raw_resp = msg.get("response_data_bytes", response.get("data_bytes", []))
    response_type = msg.get("response_type", "Response Received")
    response_data_str = _format_response_data(msg, response, raw_resp, response_type)
    response_ts = response.get("timestamp")
    response_ts_str = f"{response_ts:.6f}" if _is_number(response_ts) else "-"
    return (
        f"<tr><td>{step_count}</td><td>{_format_description(msg['desc'])}</td>"
        f"<td>{msg['timestamp']:.6f}</td><td>Request Sent</td>"
        f"<td>{req_data_str}</td><td></td><td>-</td></tr>\n"
        f"<tr><td>{step_count + 1}</td><td></td><td></td>"
        f"<td>Expected_data</td><td>{expected_str}</td>"
        f"<td></td><td>-</td></tr>\n"
        f"<tr><td>{step_count + 2}</td><td></td>"
        f"<td>{response_ts_str}</td><td>{escape(response_type)}</td>"
        f"<td>{response_data_str}</td><td>{msg['status']}</td>"
        f"<td>{escape(msg.get('failure_reason', ''))}</td></tr>\n"
    )


def render_case_block(steps):
    display_tc_id = steps[0].get("tc_id", "N/A") if steps else "N/A"
    status = testcase_status(steps)
    status_class = "pass" if status == "Pass" else "fail" if status == "Fail" else "pending"
    parts = [
        f"<div class='case-block {status_class}-case'>\n",
        f"<details><summary>{display_tc_id} - "
        f"<span class='{status_class}'>{status}</span></summary>\n",
        "<table><tr><th>Step</th><th>Description</th>"
        "<th>Timestamp</th><th>Type</th><th>Data</th>"
        "<th>Status</th><th>Failure Reason</th></tr>\n",
    ]
    for index, msg in enumerate(steps):
        parts.append(_render_message_rows(msg, 1 + 3 * index))
    parts.append("</table></details></div>\n")
    return "".join(parts)


def _render_page_header(
    *, tester_name, app_version, branch_name, branch_url, author_name,
    input_json_name, input_json_time, input_filename, input_generated_time,
    html_filename, html_generated_time, asc_filename, asc_generated_time,
    target_ecu_text, ecu_rows_html, verdict_text, verdict_class,
    test_start_display, test_end_display, duration,
    total, passed, failed, pass_pct, fail_pct,
):
    chart_script = CHART_SCRIPT_TEMPLATE.replace("__PASSED__", str(passed)).replace(
        "__FAILED__", str(failed)
    )
    return f"""<!DOCTYPE html>
<html>
<head><title>UDS Diagnostic Report</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
{REPORT_CSS}</style>
</head>
<body>

<div class="report-title">
    <h1>Report: DTP-CAN Diagnostic Test</h1>
</div>

<div class="overall-row">
    <h2>Overall Test Result Status</h2>
    <div class="overall-bar {verdict_class}">{verdict_text}</div>
</div>

<div class="section-title">General Test Information</div>
<div class="general-grid">
    <div class="info-block">
        <h3>Tester</h3>
        <table class="info-table">
            <tr><td>Tester Name</td><td>{escape(tester_name or "N/A")}</td></tr>
        </table>

        <h3 style="margin-top:18px;">Test Setup</h3>
        <table class="info-table">
            <tr><td>Version</td><td>{escape(app_version)}</td></tr>
            <tr>
                <td>Branch</td>
                <td>
                    <a href="{escape(branch_url)}" target="_blank">
                        {escape(branch_name)}
                    </a>
                </td>
            </tr>
            <tr><td>Testcase Author</td><td>{escape(author_name)}</td></tr>
            <tr><td>JSON Configuration File</td><td>{escape(format_generated_entry(input_json_name, input_json_time))}</td></tr>
            <tr><td>Generated Input File</td><td>{escape(format_generated_entry(input_filename, input_generated_time))}</td></tr>
            <tr><td>Output File, HTML Report</td><td>{escape(format_generated_entry(html_filename, html_generated_time))}</td></tr>
            <tr><td>Output File, ASC Report</td><td>{escape(format_generated_entry(asc_filename, asc_generated_time))}</td></tr>
        </table>
    </div>

    <div class="info-block">
        <h3>ECU Information</h3>
        <table class="info-table">
            <tr><td>Target ECU</td><td>{escape(target_ecu_text)}</td></tr>
            {ecu_rows_html}
        </table>
    </div>
</div>

<div class="section-title">Test Overview</div>
<div class="overview-grid">
    <div>
        <table class="info-table">
            <tr><td>Test start time</td><td>{test_start_display}</td></tr>
            <tr><td>Test end time</td><td>{test_end_display}</td></tr>
            <tr><td>Test duration</td><td>{duration:.3f} seconds</td></tr>
        </table>
        <table class="stats-table">
            <tr><th>Statistics</th><th>Count</th><th>Percentage</th></tr>
            <tr><td>Executed test cases</td><td>{total}</td><td>100%</td></tr>
            <tr><td>Test cases passed</td>
                <td class="pass">{passed}</td>
                <td class="pass">{pass_pct:.1f}%</td></tr>
            <tr><td>Test cases failed</td>
                <td class="fail">{failed}</td>
                <td class="fail">{fail_pct:.1f}%</td></tr>
        </table>
    </div>

    <div id="chart-container">
        <button type="button" onclick="showAllCases()">Show All</button>
        <canvas id="passFailChart" width="300" height="300"></canvas>
        <div class="chart-filter-row">
            <span class="chart-filter-item"
                onclick="setChartFilter('Passed')">
                <span class="chart-filter-swatch"
                    style="background:#4CAF50;"></span>
                <span id="passedFilterLabel"
                    class="chart-filter-label">Passed</span>
            </span>
            <span class="chart-filter-item"
                onclick="setChartFilter('Failed')">
                <span class="chart-filter-swatch"
                    style="background:#F44336;"></span>
                <span id="failedFilterLabel"
                    class="chart-filter-label">Failed</span>
            </span>
        </div>
    </div>
</div>

{chart_script}
    <hr><br>
    """


def generate_html_report(
    messages_by_tc,
    output_path,
    asc_file_path,
    start_ts,
    end_ts,
    ecu_info_data=None,
    target_ecu=None,
    expected_ecu_fields=None,
    author_name="N/A",
    input_file_metadata=None,
    testcase_order=None,
    ecu_info_field_map=None,
    asc_did_responses=None,
    tester_name="N/A",
    input_json_file=None,
    test_start_time=None,
    test_end_time=None,
    branch_name="N/A",
    branch_url="",
    app_version="DTP-CAN Diagnostic Application V6.2.1",
):
    ordered_messages = order_messages(messages_by_tc, testcase_order)
    total = len(ordered_messages)
    passed = sum(1 for steps in ordered_messages.values() if testcase_status(steps) == "Pass")
    failed = total - passed

    test_start_display, test_end_display, duration = compute_time_window(
        asc_file_path, start_ts, test_start_time, test_end_time
    )
    display_ecu_fields, merged_ecu_info = build_ecu_header(
        ordered_messages, ecu_info_field_map, expected_ecu_fields,
        asc_did_responses, ecu_info_data,
    )
    ecu_rows_html = "".join(
        f"<tr><td>{escape(safe_text(field))}</td>"
        f"<td>{escape(safe_text(merged_ecu_info.get(field), 'ECU No response'))}</td></tr>"
        for field in display_ecu_fields
    )
    metadata = input_file_metadata or {}

    html = _render_page_header(
        tester_name=tester_name,
        app_version=app_version,
        branch_name=branch_name,
        branch_url=branch_url,
        author_name=author_name,
        input_json_name=os.path.basename(input_json_file) if input_json_file else "N/A",
        input_json_time=get_json_generated_time(input_json_file) if input_json_file else "N/A",
        input_filename=metadata.get("filename") if input_file_metadata else "N/A",
        input_generated_time=metadata.get("generated_at") if input_file_metadata else "N/A",
        html_filename=os.path.basename(output_path),
        html_generated_time=_generated_time(output_path),
        asc_filename=os.path.basename(asc_file_path),
        asc_generated_time=_generated_time(asc_file_path),
        target_ecu_text=target_ecu or "N/A",
        ecu_rows_html=ecu_rows_html,
        verdict_text="Test passed" if failed == 0 else "Test failed",
        verdict_class="overall-pass" if failed == 0 else "overall-fail",
        test_start_display=test_start_display,
        test_end_display=test_end_display,
        duration=duration,
        total=total,
        passed=passed,
        failed=failed,
        pass_pct=(passed / total * 100) if total else 0,
        fail_pct=(failed / total * 100) if total else 0,
    )
    html += "".join(render_case_block(steps) for steps in ordered_messages.values())
    html += "</body></html>"

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
    logging.info("UDS HTML Report generated at: %s", output_path)
