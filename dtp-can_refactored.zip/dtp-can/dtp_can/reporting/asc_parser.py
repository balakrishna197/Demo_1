"""Vector ASC log parsing: frame lines, ISO-TP reassembly and request/response
pairing against the testcase definitions.
"""

import datetime
import logging
import re
from collections import defaultdict

from dtp_can.core.hexutil import split_hex_pairs
from dtp_can.core.isotp_frames import extract_payload_tokens as extract_isotp_payload
from dtp_can.reporting.matcher import (
    TestcaseMatcher,
    build_message_from_definition,
    build_request_candidate_keys,
    build_testcase_definitions,
    build_unmatched_message,
)
from dtp_can.reporting.verdict import get_status, normalize_response_payload


def parse_data_bytes(line, ctype):
    try:
        parts = line.strip().split()

        if ctype == "CANFD":
            candidate_start = None
            candidate_len = 0

            for idx in range(len(parts) - 2):
                if not parts[idx].isdigit() or not parts[idx + 1].isdigit():
                    continue

                possible_len = int(parts[idx + 1])
                if possible_len <= 0 or possible_len > 64:
                    continue

                next_tokens = parts[idx + 2: idx + 2 + possible_len]
                if len(next_tokens) != possible_len:
                    continue

                if all(
                    re.fullmatch(r"[0-9A-Fa-f]{2}", token)
                    for token in next_tokens
                ):
                    candidate_start = idx + 2
                    candidate_len = possible_len
                    break

            if candidate_start is not None:
                return [
                    value.upper()
                    for value in parts[
                        candidate_start: candidate_start + candidate_len
                    ]
                ]

        for idx, token in enumerate(parts):
            if token == "d" and idx + 1 < len(parts):
                try:
                    dlc = int(parts[idx + 1])
                except ValueError:
                    continue

                payload = []
                for value in parts[idx + 2:]:
                    if re.fullmatch(r"[0-9A-Fa-f]{2}", value):
                        payload.append(value.upper())
                    elif payload:
                        break

                if payload:
                    return payload[:dlc]

        match = re.search(
            r"((?:\b[0-9A-Fa-f]{2}\b(?:\s+|$))+)$",
            line.strip(),
        )
        if match:
            return [byte.upper() for byte in match.group(1).split()]
    except Exception:
        pass
    return []


def get_request_match_bytes(data_bytes):
    data = [b.strip().upper() for b in data_bytes if isinstance(b, str)]
    if not data:
        return []

    try:
        pci = int(data[0], 16)
    except ValueError:
        return data

    frame_type = (pci >> 4) & 0x0F

    if frame_type == 0:
        declared_payload_len = pci & 0x0F
        declared_end = min(len(data), 1 + declared_payload_len)
        declared_payload = data[1:declared_end]
        extra_bytes = list(data[declared_end:])

        while extra_bytes and extra_bytes[-1] in ("00", "AA"):
            extra_bytes.pop()

        if extra_bytes:
            return declared_payload + extra_bytes
        return declared_payload

    if frame_type == 1 and len(data) >= 2:
        payload_len = ((pci & 0x0F) << 8) | int(data[1], 16)
        return data[2:2 + payload_len]

    return data


def parse_line(line):
    line = line.strip()
    if not line:
        return None

    timestamp_match = re.match(r"^(?P<timestamp>\d+\.\d+)", line)
    if not timestamp_match:
        return None

    parts = line.split()
    timestamp = float(timestamp_match.group("timestamp"))

    if "errorframe" in line.lower():
        direction = "Tx" if "Tx" in parts else "Rx" if "Rx" in parts else ""
        return {
            "timestamp": timestamp,
            "can_id": "ERROR",
            "direction": direction,
            "data_bytes": [],
            "raw": line,
            "frame_kind": "error",
        }

    if "CANFD" not in line and " d " not in line:
        return None

    try:
        direction_idx = next(
            idx for idx, token in enumerate(parts) if token in ("Tx", "Rx")
        )
    except StopIteration:
        return None

    direction = parts[direction_idx]
    ctype = "CANFD" if "CANFD" in line else "CAN"
    can_id = None

    for idx in (
        direction_idx - 1,
        direction_idx + 1,
        direction_idx - 2,
        direction_idx + 2,
    ):
        if 0 <= idx < len(parts) and re.fullmatch(
            r"[0-9A-Fa-f]{3,8}", parts[idx]
        ):
            can_id = parts[idx].upper()
            break

    if can_id is None:
        return None

    return {
        "timestamp": timestamp,
        "can_id": can_id,
        "direction": direction,
        "data_bytes": parse_data_bytes(line, ctype),
        "raw": line,
        "frame_kind": "message",
    }


def scan_actual_did_responses(asc_file_path, allowed_tx_ids, allowed_rx_ids):
    allowed_tx_ids = set(f"{id:X}" for id in allowed_tx_ids)
    allowed_rx_ids = set(f"{id:X}" for id in allowed_rx_ids)

    did_to_response = {}
    active_request = None
    assembling_request = False
    request_buffer = []
    total_req_len = 0
    awaiting_response = False
    response_buffer = []
    total_resp_len = 0
    collected_len = 0
    pending_flag = False

    def find_did_from_request(data_bytes):
        request_bytes = get_request_match_bytes(data_bytes)
        for idx, byte in enumerate(request_bytes):
            if byte == "22" and idx + 2 < len(request_bytes):
                return "".join(request_bytes[idx + 1: idx + 3]).upper()
        return None

    def finalize_response(full_resp):
        nonlocal active_request, awaiting_response, response_buffer
        nonlocal total_resp_len, collected_len, pending_flag
        if not active_request or not full_resp:
            active_request = None
            awaiting_response = False
            response_buffer = []
            total_resp_len = 0
            collected_len = 0
            pending_flag = False
            return

        payload = extract_isotp_payload(full_resp)
        if len(payload) >= 3 and payload[0] == "62":
            did = "".join(payload[1:3]).upper()
            did_to_response[did] = full_resp
        elif active_request.get("did") and len(payload) >= 2:
            expected_did_bytes = split_hex_pairs(active_request["did"])
            if payload[:2] == expected_did_bytes:
                did_to_response[active_request["did"]] = ["62"] + payload

        active_request = None
        awaiting_response = False
        response_buffer = []
        total_resp_len = 0
        collected_len = 0
        pending_flag = False

    with open(asc_file_path, "r", encoding="utf-8", errors="ignore") as f:
        for raw_line in f:
            line = raw_line.strip()
            if not line or not re.match(r"^\d+\.\d+", line):
                continue

            msg = parse_line(line)
            if not msg or msg["frame_kind"] != "message":
                continue

            can_id = msg["can_id"]
            direction = msg["direction"]
            data = msg["data_bytes"]

            if not data:
                continue

            pci_type = data[0].upper()

            if direction == "Tx" and can_id in allowed_tx_ids:
                if pci_type == "30" and awaiting_response:
                    continue

                if pci_type == "10":
                    assembling_request = True
                    total_req_len = (
                        ((int(data[0], 16) & 0x0F) << 8) | int(data[1], 16)
                    )
                    request_buffer = data[2:]
                    continue

                if assembling_request and pci_type.startswith("2"):
                    request_buffer += data[1:]
                    if len(request_buffer) >= total_req_len:
                        trimmed_request = request_buffer[:total_req_len]
                        did = find_did_from_request(trimmed_request)
                        active_request = {"did": did} if did else None
                        assembling_request = False
                        request_buffer = []
                    continue

                if assembling_request:
                    assembling_request = False
                    request_buffer = []

                did = find_did_from_request(data)
                active_request = {"did": did} if did else None
                continue

            if (
                direction == "Rx"
                and can_id in allowed_rx_ids
                and active_request
            ):
                if pci_type == "30":
                    continue

                if (
                    len(data) >= 4
                    and data[1].upper() == "7F"
                    and data[3].upper() == "78"
                ):
                    pending_flag = True
                    continue

                if pending_flag:
                    pending_flag = False
                    finalize_response(data)
                    continue

                if pci_type == "10":
                    total_resp_len = (
                        ((int(data[0], 16) & 0x0F) << 8)
                        | int(data[1], 16)
                    )
                    response_buffer = data[2:]
                    collected_len = len(response_buffer)
                    awaiting_response = True
                    continue

                if pci_type.startswith("2") and awaiting_response:
                    response_buffer += data[1:]
                    collected_len += len(data) - 1
                    if collected_len >= total_resp_len:
                        finalize_response(response_buffer[:total_resp_len])
                    continue

                finalize_response(data)

    return did_to_response


def get_asc_measurement_window(asc_file_path):
    metadata: dict[str, datetime.datetime | float | None] = {
        "measurement_start": None,
        "first_event_offset": None,
        "last_event_offset": None,
    }

    try:
        with open(
            asc_file_path, "r", encoding="utf-8", errors="ignore"
        ) as asc_file:
            for raw_line in asc_file:
                line = raw_line.strip()
                if not line:
                    continue

                if metadata["measurement_start"] is None:
                    begin_match = re.match(
                        r"^Begin Triggerblock\s+(.+)$", line, re.IGNORECASE
                    )
                    if begin_match:
                        measurement_text = begin_match.group(1).strip()
                        try:
                            metadata["measurement_start"] = (
                                datetime.datetime.strptime(
                                    measurement_text, "%a %b %d %H:%M:%S.%f %Y"
                                )
                            )
                        except ValueError as exc:
                            logging.warning(
                                "Failed to parse ASC measurement start "
                                f"'{measurement_text}': {exc}"
                            )

                timestamp_match = re.match(r"^(?P<timestamp>\d+\.\d+)", line)
                if not timestamp_match:
                    continue

                timestamp = float(timestamp_match.group("timestamp"))
                if metadata["first_event_offset"] is None:
                    metadata["first_event_offset"] = timestamp
                metadata["last_event_offset"] = timestamp
    except Exception as exc:
        logging.warning(
            "Failed to read ASC measurement window from "
            f"{asc_file_path}: {exc}"
        )

    return metadata


def finalize_message(
    message,
    messages_by_tc,
    start_ts,
    end_ts,
    response=None,
    response_data_bytes=None,
    response_type=None,
    failure_reason=None,
    status=None,
):
    response = response or {}
    response_data_bytes = response_data_bytes or []
    response_type = response_type or "Response Received"

    if status is None and message.get("tc_id") == "UNMATCHED_ASC":
        status = "Fail"
        derived_reason = (
            "Diagnostic traffic observed in ASC but not matched to TXT"
        )
    elif status is None:
        status, derived_reason = get_status(
            response_data_bytes, message.get("expected_resp", [])
        )
    else:
        derived_reason = ""

    message.update(
        {
            "response": response,
            "response_data_bytes": response_data_bytes,
            "response_type": response_type,
            "status": status,
            "failure_reason": (
                failure_reason
                if failure_reason is not None
                else derived_reason
            ),
        }
    )
    occurrence_key = message.get("occurrence_key", message["tc_id"])
    messages_by_tc[occurrence_key].append(message)

    start_ts = min(start_ts or message["timestamp"], message["timestamp"])
    response_ts = response.get("timestamp")
    if isinstance(response_ts, (int, float)):
        end_ts = max(end_ts or response_ts, response_ts)
    else:
        end_ts = max(end_ts or message["timestamp"], message["timestamp"])

    return start_ts, end_ts


def parse_asc_log(asc_file_path, allowed_tx_ids, allowed_rx_ids, steps):
    """Pair requests/responses in the ASC log with testcase definitions.

    Returns ``(messages_by_occurrence_key, start_ts, end_ts)``.
    """
    definitions = build_testcase_definitions(steps)
    matcher = TestcaseMatcher(definitions)

    messages_by_tc = defaultdict(list)
    allowed_tx_ids = set(f"{id:X}" for id in allowed_tx_ids)
    allowed_rx_ids = set(f"{id:X}" for id in allowed_rx_ids)
    allowed_ids = allowed_tx_ids | allowed_rx_ids

    current_message = None
    request_builder = None
    response_builder = None
    pending_error_frame = None
    start_ts = None
    end_ts = None

    def close_current_no_response(
        reason, response=None, response_type=None, response_bytes=None
    ):
        nonlocal current_message, start_ts, end_ts, pending_error_frame
        nonlocal response_builder
        if not current_message:
            return
        start_ts, end_ts = finalize_message(
            current_message,
            messages_by_tc,
            start_ts,
            end_ts,
            response=response,
            response_data_bytes=response_bytes or [],
            response_type=response_type or "No Response",
            failure_reason=reason,
            status="Fail",
        )
        current_message = None
        pending_error_frame = None
        response_builder = None

    with open(asc_file_path, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    for line in lines:
        stripped = line.strip()
        if not stripped or not re.match(r"^\d+\.\d+", stripped):
            continue

        msg = parse_line(stripped)
        if not msg:
            continue

        if msg["frame_kind"] == "error":
            if current_message:
                pending_error_frame = msg
            continue

        if msg["can_id"] not in allowed_ids:
            continue

        data = msg["data_bytes"]
        if not data:
            continue

        direction = msg["direction"]
        pci = int(data[0], 16)
        frame_type = (pci >> 4) & 0x0F

        if direction == "Tx" and msg["can_id"] in allowed_tx_ids:
            if frame_type == 0x3:
                continue

            if frame_type == 0x0:
                request_payload = get_request_match_bytes(data)
                if (
                    current_message
                    and request_payload
                    and current_message.get("request_payload") == (
                        request_payload
                    )
                ):
                    pending_error_frame = None
                    response_builder = None
                    continue

            if current_message and request_builder is None:
                reason = (
                    "Incomplete multi-frame response"
                    if response_builder
                    else "No response received"
                )
                response = pending_error_frame if pending_error_frame else None
                response_type = (
                    "Error Frame" if pending_error_frame else "No Response"
                )
                response_bytes = (
                    response_builder["payload"][:] if response_builder else []
                )
                close_current_no_response(
                    reason,
                    response=response,
                    response_type=response_type,
                    response_bytes=response_bytes,
                )

            if frame_type == 0x1 and len(data) >= 2:
                total_len = (
                    ((pci & 0x0F) << 8) | int(data[1], 16)
                )
                request_builder = {
                    "timestamp": msg["timestamp"],
                    "can_id": msg["can_id"],
                    "payload": data[2:],
                    "total_len": total_len,
                }
                continue

            if request_builder and frame_type == 0x2:
                request_builder["payload"].extend(data[1:])
                if (
                    len(request_builder["payload"])
                    >= request_builder["total_len"]
                ):
                    request_payload = request_builder["payload"][
                        : request_builder["total_len"]
                    ]
                    definition = matcher.match(request_payload)
                    if definition:
                        current_message = build_message_from_definition(
                            definition,
                            request_builder["timestamp"],
                            request_payload,
                        )
                    elif matcher.has_matched_payload(
                        request_payload
                    ):
                        # The matching testcase has already completed; this is
                        # a duplicate/retry transmission, not a new result.
                        pass
                    elif build_request_candidate_keys(request_payload):
                        current_message = build_unmatched_message(
                            request_builder["timestamp"],
                            request_payload,
                        )
                    request_builder = None
                continue

            request_builder = None
            request_payload = get_request_match_bytes(data)
            definition = matcher.match(request_payload)
            if definition:
                current_message = build_message_from_definition(
                    definition,
                    msg["timestamp"],
                    request_payload,
                )
            elif matcher.has_matched_payload(request_payload):
                # Do not add another report entry for a completed retry.
                pass
            elif build_request_candidate_keys(request_payload):
                current_message = build_unmatched_message(
                    msg["timestamp"],
                    request_payload,
                )
            continue

        if (
            direction == "Rx"
            and msg["can_id"] in allowed_rx_ids
            and current_message
        ):
            if frame_type == 0x3:
                continue

            payload = extract_isotp_payload(data)
            if len(payload) >= 3 and payload[0] == "7F" and payload[2] == "78":
                continue

            if frame_type == 0x1 and len(data) >= 2:
                total_len = (
                    ((pci & 0x0F) << 8) | int(data[1], 16)
                )
                response_builder = {
                    "response": msg,
                    "payload": data[2:],
                    "total_len": total_len,
                    "observed_len": len(data[2:]),
                }
                continue

            if response_builder and frame_type == 0x2:
                response_builder["payload"].extend(data[1:])
                response_builder["observed_len"] = len(
                    response_builder["payload"]
                )
                if (
                    len(response_builder["payload"])
                    >= response_builder["total_len"]
                ):
                    full_response = response_builder["payload"][
                        : response_builder["total_len"]
                    ]
                    start_ts, end_ts = finalize_message(
                        current_message,
                        messages_by_tc,
                        start_ts,
                        end_ts,
                        response=response_builder["response"],
                        response_data_bytes=full_response,
                    )
                    current_message = None
                    response_builder = None
                    pending_error_frame = None
                continue

            if response_builder:
                full_response = response_builder["payload"][
                    : response_builder["total_len"]
                ]
                failure_reason = None
                status = None
                if len(response_builder["payload"]) < response_builder[
                    "total_len"
                ]:
                    failure_reason = (
                        f"Incomplete multi-frame response "
                        f"({len(response_builder['payload'])}/"
                        f"{response_builder['total_len']} bytes)"
                    )
                    status = "Fail"
                start_ts, end_ts = finalize_message(
                    current_message,
                    messages_by_tc,
                    start_ts,
                    end_ts,
                    response=response_builder["response"],
                    response_data_bytes=full_response,
                    failure_reason=failure_reason,
                    status=status,
                )
                current_message = None
                response_builder = None
                pending_error_frame = None
                # BUGFIX (B-04): V6.2.1 fell through and called
                # finalize_message(None, ...) -> AttributeError, aborting
                # report generation when an incomplete multi-frame response
                # was followed by a non-consecutive frame.
                continue

            start_ts, end_ts = finalize_message(
                current_message,
                messages_by_tc,
                start_ts,
                end_ts,
                response=msg,
                response_data_bytes=normalize_response_payload(data),
            )
            current_message = None
            pending_error_frame = None

    if current_message:
        reason = (
            "Incomplete multi-frame response"
            if response_builder
            else "No response received"
        )
        response = pending_error_frame if pending_error_frame else None
        response_type = (
            "Error Frame"
            if pending_error_frame
            else "No Response"
        )
        response_bytes = (
            response_builder["payload"][:] if response_builder else []
        )
        close_current_no_response(
            reason,
            response=response,
            response_type=response_type,
            response_bytes=response_bytes,
        )

    return messages_by_tc, start_ts or 0, end_ts or 0
