"""Offline report generation from an ASC CAN log + the TXT testcase file.

Public API: ``generate_report`` (same signature as V6.2.1) and the
``ReportGenerator`` port with its ``HtmlReportGenerator`` implementation.
"""

from dtp_can.reporting.generator import (  # noqa: F401
    HtmlReportGenerator,
    ReportGenerator,
    ReportRequest,
    generate_report,
)

__all__ = [
    "# noqa: F401",
    "HtmlReportGenerator",
    "ReportGenerator",
    "ReportRequest",
    "generate_report",
]
