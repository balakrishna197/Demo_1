"""ECU-information header assembly: DID label mapping and value merging.
"""

import re
from collections import OrderedDict

from dtp_can.core.did_decoder import decode_special_did_value
from dtp_can.core.hexutil import looks_like_did, normalize_did_string, remove_trailing_padding
from dtp_can.core.hexutil import normalize_hex_tokens as normalize_hex_bytes
from dtp_can.core.isotp_frames import extract_payload_tokens as extract_isotp_payload
from dtp_can.reporting.verdict import (
    is_empty_positive_read_response,
    normalize_response_payload,
)

NO_RESPONSE = "ECU No response"


def build_ecu_info_label_map(ecu_info_field_map):
    did_to_label = OrderedDict()
    ordered_labels = []

    if not isinstance(ecu_info_field_map, dict):
        return did_to_label, ordered_labels

    for raw_key, raw_value in ecu_info_field_map.items():
        key_text = str(raw_key).strip()
        value_text = str(raw_value).strip()

        key_is_did = looks_like_did(key_text)
        value_is_did = looks_like_did(value_text)

        did = ""
        label = ""

        if key_is_did and not value_is_did:
            did = normalize_did_string(key_text)
            label = value_text
        elif value_is_did and not key_is_did:
            did = normalize_did_string(value_text)
            label = key_text
        else:
            continue

        if not did or not label:
            continue

        did_to_label[did] = label
        if label not in ordered_labels:
            ordered_labels.append(label)

    return did_to_label, ordered_labels


def normalize_ecu_info_field_name(value):
    text = str(value or "").strip().lower()
    if not text:
        return ""
    return re.sub(r"[^a-z0-9]+", "", text)


def is_meaningful_ecu_info_value(value):
    if value is None:
        return False
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return False
        if stripped == "ECU No response":
            return False
    return True


def merge_ecu_info_values(
    primary_values, fallback_values, preferred_order=None
):
    merged = {}
    alias_to_canonical = OrderedDict()

    for field in preferred_order or []:
        alias = normalize_ecu_info_field_name(field)
        if alias and alias not in alias_to_canonical:
            alias_to_canonical[alias] = field
        merged[field] = None

    for source in (fallback_values or {}, primary_values or {}):
        for field, value in (source or {}).items():
            alias = normalize_ecu_info_field_name(field)
            canonical = alias_to_canonical.get(alias, field)
            if alias and alias not in alias_to_canonical:
                alias_to_canonical[alias] = canonical
            # existing = merged.get(canonical)
            if is_meaningful_ecu_info_value(value):
                merged[canonical] = value
            elif canonical not in merged:
                merged[canonical] = value

    return merged


def extract_request_did(data_bytes):
    payload = extract_isotp_payload(normalize_hex_bytes(data_bytes))
    if len(payload) >= 3 and payload[0].upper() == "22":
        return f"{payload[1]}{payload[2]}".upper()
    return ""


def format_response_value(raw_resp, format_type, desc=""):
    """Decoded DID value for the ECU header (no hex prefix)."""
    raw_bytes = normalize_hex_bytes(raw_resp or [])
    clean_resp = remove_trailing_padding(raw_bytes, "AA")
    payload = normalize_response_payload(raw_bytes)
    format_type = (format_type or "Hex").strip().lower()
    try:
        full_hex_str = " ".join(clean_resp)
        if "62" in [b.upper() for b in payload]:
            idx = next(i for i, b in enumerate(payload) if b.upper() == "62")
            payload = payload[idx + 3:] if len(payload) > idx + 2 else []
        elif len(payload) >= 2 and looks_like_did("".join(payload[:2])):
            payload = payload[2:]
        if not payload and is_empty_positive_read_response(raw_resp):
            return NO_RESPONSE
        special_value = decode_special_did_value(desc, payload)
        if special_value is not None:
            return special_value
        if format_type == "ascii":
            if payload and all(32 <= int(b, 16) <= 126 for b in payload):
                return "".join(chr(int(b, 16)) for b in payload)
            return full_hex_str
        if format_type == "decimal":
            return " ".join(str(int(b, 16)) for b in payload) if payload else full_hex_str
        return full_hex_str
    except Exception:
        return " ".join(clean_resp)


def ecu_info_from_messages(ordered_messages, did_to_label):
    """Values read by ``ECU_INFO*`` rows or by any read of a configured DID.

    Note (V6.2.1 behaviour, kept): when explicit ECU_INFO rows exist, a later
    non-ECU_INFO read of a *configured* DID overwrites the header value.
    """
    parsed = {}
    has_explicit_ecu_info = any(
        msg.get("tc_id", "").startswith("ECU_INFO")
        for steps in ordered_messages.values()
        for msg in steps
    )
    for steps in ordered_messages.values():
        for msg in steps:
            tc_id = msg.get("tc_id", "")
            desc = msg.get("desc", "")
            request_did = extract_request_did(msg.get("data_bytes", []))
            configured_field = did_to_label.get(request_did, "")
            if not desc and not configured_field:
                continue
            if not tc_id.startswith("ECU_INFO") and not configured_field:
                continue
            field_name = desc
            if configured_field and (
                not has_explicit_ecu_info or not tc_id.startswith("ECU_INFO")
            ):
                field_name = configured_field
            if not field_name:
                continue

            response_type = msg.get("response_type", "Response Received")
            raw_resp = msg.get(
                "response_data_bytes", msg.get("response", {}).get("data_bytes", [])
            )
            payload = normalize_response_payload(raw_resp)
            valid_positive = raw_resp and len(payload) >= 3 and payload[0].upper() == "62"
            valid_did_data = (
                raw_resp
                and request_did
                and len(payload) >= 2
                and "".join(payload[:2]).upper() == request_did
            )
            if valid_positive or valid_did_data:
                value = format_response_value(raw_resp, msg.get("format", "Hex"), desc)
                if is_empty_positive_read_response(raw_resp):
                    parsed.setdefault(field_name, value)
                else:
                    parsed[field_name] = value
            elif response_type == "No Response":
                parsed.setdefault(field_name, NO_RESPONSE)
    return parsed


def ecu_info_from_asc_dids(asc_did_responses, did_to_label):
    parsed = {}
    for did, raw_resp in (asc_did_responses or {}).items():
        field_name = did_to_label.get(did, "")
        if field_name:
            parsed[field_name] = format_response_value(raw_resp, "Ascii", field_name)
    return parsed


def build_ecu_header(ordered_messages, ecu_info_field_map, expected_ecu_fields,
                     asc_did_responses, ecu_info_data):
    """Returns ``(display_fields, merged_values)`` for the report header.

    Priority: values parsed from matched testcase messages > DID responses
    scanned from the raw ASC > values supplied by the caller.
    """
    did_to_label, configured_fields = build_ecu_info_label_map(ecu_info_field_map)
    display_fields = list(expected_ecu_fields or [])
    for field in configured_fields:
        if field not in display_fields:
            display_fields.append(field)

    from_messages = {
        k: v for k, v in ecu_info_from_messages(ordered_messages, did_to_label).items()
        if v is not None
    }
    from_asc = {
        k: v for k, v in ecu_info_from_asc_dids(asc_did_responses, did_to_label).items()
        if v is not None
    }
    merged = merge_ecu_info_values(
        from_messages,
        merge_ecu_info_values(from_asc, ecu_info_data or {}, display_fields),
        display_fields,
    )
    return display_fields, merged
