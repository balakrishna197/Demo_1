"""Report generation façade and extension port.

``ReportGenerator`` is the interface the test executor depends on, so a new
output format (JUnit XML, JSON, PDF...) is added by implementing it and
registering it in the composition root - no executor changes required.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from dtp_can.reporting.asc_parser import parse_asc_log, scan_actual_did_responses
from dtp_can.reporting.html_renderer import generate_html_report
from dtp_can.reporting.matcher import ensure_all_testcases_present, get_testcase_order
from dtp_can.testcases.metadata import (
    get_expected_ecu_info_fields,
    get_testcase_author,
    get_testcase_generated_metadata,
)
from dtp_can.testcases.parser import load_testcase_sequence

DEFAULT_APP_VERSION = "DTP-CAN Diagnostic Application V6.2.1"


@dataclass
class ReportRequest:
    asc_file_path: str
    txt_file_path: str
    output_html_file: str
    allowed_tx_ids: List[int]
    allowed_rx_ids: List[int]
    ecu_info_data: Optional[Dict[str, Any]] = None
    target_ecu: Optional[str] = None
    ecu_info_field_map: Optional[Dict[str, Any]] = None
    tester_name: str = "N/A"
    input_json_file: Optional[str] = None
    test_start_time: Any = None
    test_end_time: Any = None
    branch_name: str = "N/A"
    branch_url: str = ""
    extra: Dict[str, Any] = field(default_factory=dict)


class ReportGenerator(abc.ABC):
    """Port: turns a finished test run into one or more report artefacts."""

    @abc.abstractmethod
    def generate(self, request: ReportRequest) -> str:
        """Create the report and return the path of the primary artefact."""


class HtmlReportGenerator(ReportGenerator):
    def __init__(self, app_version: str = DEFAULT_APP_VERSION):
        self.app_version = app_version

    def generate(self, request: ReportRequest) -> str:
        steps = load_testcase_sequence(request.txt_file_path)  # parsed once
        txt = request.txt_file_path

        messages_by_tc, start_ts, end_ts = parse_asc_log(
            request.asc_file_path, request.allowed_tx_ids, request.allowed_rx_ids, steps
        )
        messages_by_tc = ensure_all_testcases_present(messages_by_tc, steps)
        asc_did_responses = scan_actual_did_responses(
            request.asc_file_path, request.allowed_tx_ids, request.allowed_rx_ids
        )
        generate_html_report(
            messages_by_tc,
            request.output_html_file,
            request.asc_file_path,
            start_ts,
            end_ts,
            ecu_info_data=request.ecu_info_data,
            target_ecu=request.target_ecu,
            expected_ecu_fields=get_expected_ecu_info_fields(txt),
            author_name=get_testcase_author(txt),
            input_file_metadata=get_testcase_generated_metadata(txt),
            testcase_order=get_testcase_order(steps),
            ecu_info_field_map=request.ecu_info_field_map,
            asc_did_responses=asc_did_responses,
            tester_name=request.tester_name,
            input_json_file=request.input_json_file,
            test_start_time=request.test_start_time,
            test_end_time=request.test_end_time,
            branch_name=request.branch_name,
            branch_url=request.branch_url,
            app_version=self.app_version,
        )
        return request.output_html_file


def generate_report(
    asc_file_path,
    txt_file_path,
    output_html_file,
    allowed_tx_ids,
    allowed_rx_ids,
    ecu_info_data=None,
    target_ecu=None,
    ecu_info_field_map=None,
    tester_name="N/A",
    input_json_file=None,
    test_start_time=None,
    test_end_time=None,
    branch_name="N/A",
    branch_url="",
    app_version=DEFAULT_APP_VERSION,
):
    """Backward compatible functional entry point (V6.2.1 signature)."""
    return HtmlReportGenerator(app_version).generate(
        ReportRequest(
            asc_file_path=asc_file_path,
            txt_file_path=txt_file_path,
            output_html_file=output_html_file,
            allowed_tx_ids=allowed_tx_ids,
            allowed_rx_ids=allowed_rx_ids,
            ecu_info_data=ecu_info_data,
            target_ecu=target_ecu,
            ecu_info_field_map=ecu_info_field_map,
            tester_name=tester_name,
            input_json_file=input_json_file,
            test_start_time=test_start_time,
            test_end_time=test_end_time,
            branch_name=branch_name,
            branch_url=branch_url,
        )
    )
