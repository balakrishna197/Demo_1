"""CSV-style TXT testcase parser (replaces drivers/Parse_handler.py).

Behaviour is identical to V6.2.1 - header detection, column aliases,
description-comma merging, ``WAIT,<hex ms>`` rows - but the parser no longer
keeps results in module-level globals, so concurrent/re-entrant use and unit
testing are safe.  Steps are returned as ``TestStep`` / ``WaitStep`` named
tuples (tuple compatible with the previous positional format).
"""

from __future__ import annotations

import csv
import logging
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from dtp_can.core.models import Step, TestStep, WaitStep

HEADER_ALIASES = {
    "TC_ID": ["TC_ID/PC_ID", "TC_ID", "PC_ID"],
    "DESCRIPTION": ["Testcase_Description", "Description", "Test Description"],
    "SERVICE": ["Service_ID", "SID", "Service"],
    "SUBFUNC": ["SubService_ID", "SubFunction", "DID"],
    "EXPECTED": ["Expected_Response_Data", "Expected", "Response"],
    "WRITE": ["Write_Data", "Data", "Payload"],
    "ADDRESSING": ["Addressing", "Mode"],
    "FORMAT": ["Format"],
    "STATUS_MASK": ["Status_Mask", "StatusMask"],
    "COMM_TYPE": ["Communication_Type", "CommunicationType"],
    "CONTROLTYPE": ["controltype", "ControlType"],
}

_REQUIRED = ("TC_ID", "DESCRIPTION", "SERVICE", "SUBFUNC", "EXPECTED", "WRITE",
             "ADDRESSING", "FORMAT")
_OPTIONAL = ("STATUS_MASK", "COMM_TYPE", "CONTROLTYPE")


def find_column(col, aliases, required=True):
    for alias in aliases:
        if alias in col:
            return col[alias]
    if required:
        raise KeyError(f"Column not found. Tried: {aliases}")
    return None


def normalize_row(row, header_len, description_idx):
    """Re-join a description that contained unquoted commas; pad short rows."""
    if len(row) > header_len and description_idx is not None:
        extra_count = len(row) - header_len
        merged_description = ",".join(
            row[description_idx: description_idx + extra_count + 1]
        )
        row = (
            row[:description_idx]
            + [merged_description]
            + row[description_idx + extra_count + 1:]
        )
    if len(row) < header_len:
        row = row + [""] * (header_len - len(row))
    return row


@dataclass
class ParsedTestcases:
    grouped: "OrderedDict[str, List[Step]]" = field(default_factory=OrderedDict)
    sequence: List[Step] = field(default_factory=list)
    error: Optional[str] = None


def _cell(row, idx) -> str:
    return row[idx].strip() if idx is not None and idx < len(row) else ""


def parse_testcase_file(file_path: str) -> ParsedTestcases:
    result = ParsedTestcases()
    try:
        with open(file_path, "r", newline="") as f:
            reader = csv.reader(f)
            header: List[str] = []
            for row in reader:
                candidate = [h.strip().lstrip("#").lstrip("﻿") for h in row]
                if "TC_ID/PC_ID" in candidate or "TC_ID" in candidate:
                    header = candidate
                    break
            if not header:
                raise ValueError("TXT header row not found")

            col = {name: idx for idx, name in enumerate(header)}
            description_idx = find_column(col, HEADER_ALIASES["DESCRIPTION"], required=False)

            current_tc_id = None
            for row in reader:
                if not row:
                    continue
                row = normalize_row(row, len(header), description_idx)
                row_values = [str(cell).strip().upper() for cell in row]
                if "WAIT" in row_values:
                    if current_tc_id:
                        wait_index = row_values.index("WAIT")
                        wait_step = WaitStep("WAIT", int(row[wait_index + 1].strip(), 16))
                        result.grouped[current_tc_id].append(wait_step)
                        result.sequence.append(wait_step)
                    continue
                if len(row) < 5:
                    continue

                idx = {key: find_column(col, HEADER_ALIASES[key]) for key in _REQUIRED}
                opt = {
                    key: find_column(col, HEADER_ALIASES[key], required=False)
                    for key in _OPTIONAL
                }
                tc_id = row[idx["TC_ID"]].strip()
                current_tc_id = tc_id
                step = TestStep(
                    tc_id=tc_id,
                    description=row[idx["DESCRIPTION"]].strip(),
                    service=row[idx["SERVICE"]].strip(),
                    subfunction=row[idx["SUBFUNC"]].strip(),
                    expected=row[idx["EXPECTED"]].strip(),
                    write_data=row[idx["WRITE"]].strip(),
                    addressing=row[idx["ADDRESSING"]].strip().lower(),
                    format_type=row[idx["FORMAT"]].strip(),
                    status_mask=_cell(row, opt["STATUS_MASK"]),
                    communication_type=_cell(row, opt["COMM_TYPE"]),
                    control_type=_cell(row, opt["CONTROLTYPE"]),
                )
                result.grouped.setdefault(tc_id, []).append(step)
                result.sequence.append(step)
    except Exception as exc:
        # V6.2.1 semantics: grouped view empty, sequence keeps parsed prefix.
        result.error = str(exc)
        result.grouped = OrderedDict()
        print(f"Error parsing testcases: {exc}")
        logging.error("Error parsing testcases in %s: %s", file_path, exc)
    return result


def load_testcases(file_path: str) -> Dict[str, List[Step]]:
    """Steps grouped by testcase id (insertion ordered)."""
    return parse_testcase_file(file_path).grouped


def load_testcase_sequence(file_path: str) -> List[Step]:
    """Flat list of steps in file order, including ``WaitStep`` rows."""
    return list(parse_testcase_file(file_path).sequence)
