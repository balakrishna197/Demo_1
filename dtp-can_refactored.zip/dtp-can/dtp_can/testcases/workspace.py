"""The on-device testcase workspace (``supportfiles/`` + selection marker).

V6.2.1 resolved this folder relative to *different* base directories in
``main.py`` and ``drivers/uds_client.py`` (identical only in the frozen
executable).  It is now owned by a single class built from ``AppPaths``.
"""

from __future__ import annotations

import os
import shutil


class TestcaseWorkspace:
    def __init__(self, support_dir: str, selection_file: str):
        self.support_dir = support_dir
        self.selection_file = selection_file

    def ensure(self) -> None:
        os.makedirs(self.support_dir, exist_ok=True)

    def install_testcase(self, testcase_path: str) -> str:
        """Replace the active testcase with ``testcase_path`` and select it."""
        self.ensure()
        for file in os.listdir(self.support_dir):
            if file.endswith(".txt"):
                os.remove(os.path.join(self.support_dir, file))
        filename = os.path.basename(testcase_path)
        shutil.copy(testcase_path, os.path.join(self.support_dir, filename))
        self.select(filename)
        return os.path.join(self.support_dir, filename)

    def add_testcase(self, testcase_path: str) -> str:
        """Copy a testcase without removing others (USB import semantics)."""
        filename = os.path.basename(testcase_path)
        destination = os.path.join(self.support_dir, filename)
        shutil.copy(testcase_path, destination)
        self.select(filename)
        return destination

    def select(self, filename: str) -> None:
        with open(self.selection_file, "w") as f:
            f.write(filename)

    def active_testcase(self) -> str:
        """Path of the selected testcase (falls back to first .txt)."""
        if not os.path.exists(self.support_dir):
            raise FileNotFoundError(f"Testcase folder not found: {self.support_dir}")
        if os.path.exists(self.selection_file):
            with open(self.selection_file, "r", encoding="utf-8") as f:
                selected_name = f.read().strip()
            if selected_name:
                selected_file = os.path.join(self.support_dir, selected_name)
                if os.path.isfile(selected_file):
                    return selected_file
        txt_files = sorted(
            file for file in os.listdir(self.support_dir) if file.lower().endswith(".txt")
        )
        if txt_files:
            return os.path.join(self.support_dir, txt_files[0])
        raise FileNotFoundError(f"Testcase file not found in: {self.support_dir}")
