"""Locate testcase (.txt) and test configuration (.json) files in a repository."""

from __future__ import annotations

import logging
import os
from typing import Iterable, List, Tuple

from dtp_can.core.errors import SessionSetupError

EXCLUDED_JSON = frozenset({"git_credentials.json"})


def find_testcases_and_configs(
    repo_path: str, excluded_json: Iterable[str] = EXCLUDED_JSON
) -> Tuple[List[str], List[str]]:
    if repo_path is None:
        raise ValueError("A repository must be selected before scanning files")
    excluded = {name.lower() for name in excluded_json}
    testcases: List[str] = []
    configs: List[str] = []
    for root, dirs, files in os.walk(repo_path):
        if ".git" in dirs:
            dirs.remove(".git")
        for file in files:
            full_path = os.path.join(root, file)
            lower = file.lower()
            if lower.endswith(".txt"):
                testcases.append(full_path)
            elif lower.endswith(".json") and lower not in excluded:
                configs.append(full_path)
    testcases.sort()
    configs.sort()
    if not testcases:
        raise SessionSetupError("No testcase files found")
    if not configs:
        raise SessionSetupError("No config files found")
    logging.info("Testcases found: %s", testcases)
    logging.info("Configs found: %s", configs)
    return testcases, configs
