"""Header metadata of a TXT testcase file (author, generation time, ECU fields)."""

from __future__ import annotations

import csv
import logging
import os
from typing import Dict, List, Optional

from dtp_can.testcases.parser import HEADER_ALIASES, find_column


def _is_header_row(first_col: str) -> bool:
    return first_col.startswith("#TC_ID") or first_col.startswith("TC_ID")


def get_testcase_author(txt_file_path: str) -> str:
    try:
        with open(txt_file_path, "r", encoding="utf-8-sig", newline="") as f:
            for row in csv.reader(f):
                if not row:
                    continue
                first_col = row[0].strip()
                if first_col.startswith("#Author"):
                    if len(row) > 1 and row[1].strip():
                        return row[1].strip()
                    if ":" in first_col:
                        return first_col.split(":", 1)[1].strip()
                    return "N/A"
                if _is_header_row(first_col):
                    break
    except Exception as exc:
        logging.warning(f"Failed to read testcase author from header: {exc}")
    return "N/A"


def get_testcase_generated_metadata(txt_file_path: str) -> Dict[str, Optional[str]]:
    metadata: Dict[str, Optional[str]] = {
        "filename": os.path.basename(txt_file_path),
        "generated_at": None,
    }
    try:
        with open(txt_file_path, "r", encoding="utf-8-sig", newline="") as f:
            for row in csv.reader(f):
                if not row:
                    continue
                first_col = row[0].strip()
                second_col = row[1].strip() if len(row) > 1 else ""
                if _is_header_row(first_col):
                    break
                normalized_key = first_col.lstrip("#").strip().lower()
                if (
                    first_col.startswith("#Date")
                    or normalized_key in {"date", "generated", "generated on"}
                ):
                    date_value = ""
                    time_value = ""
                    if ":" in first_col:
                        date_value = first_col.split(":", 1)[1].strip()
                    if second_col:
                        second_col_clean = second_col.strip()
                        if second_col_clean.lower().startswith("time"):
                            time_value = second_col_clean.split(":", 1)[1].strip()
                        else:
                            time_value = second_col_clean
                    combined = f"{date_value} {time_value}".strip()
                    metadata["generated_at"] = combined or metadata["generated_at"]
                elif normalized_key in {"file", "filename", "input file"} and second_col:
                    metadata["filename"] = os.path.basename(second_col)
    except Exception as exc:
        logging.warning(f"Failed to read testcase generated metadata from header: {exc}")
    return metadata


def get_expected_ecu_info_fields(txt_file_path: str) -> List[str]:
    """Descriptions of ``ECU_INFO*`` rows, de-duplicated, in file order."""
    fields: List[str] = []
    seen = set()
    try:
        with open(txt_file_path, "r", encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            header = None
            for row in reader:
                if not row:
                    continue
                first_col = row[0].strip()
                if first_col.startswith("#Author") or first_col.startswith("#Date"):
                    continue
                if _is_header_row(first_col):
                    header = [h.strip().lstrip("#") for h in row]
                    break
            if header is None:
                return fields
            col = {name: idx for idx, name in enumerate(header)}
            tc_id_idx = find_column(col, HEADER_ALIASES["TC_ID"])
            desc_idx = find_column(col, HEADER_ALIASES["DESCRIPTION"])
            if tc_id_idx is None or desc_idx is None:
                return fields
            for row in reader:
                if not row or len(row) <= max(tc_id_idx, desc_idx):
                    continue
                tc_id = row[tc_id_idx].strip()
                desc = row[desc_idx].strip()
                if tc_id.startswith("ECU_INFO") and desc and desc not in seen:
                    seen.add(desc)
                    fields.append(desc)
    except Exception as exc:
        logging.warning(f"Failed to derive ECU info field list from testcase file: {exc}")
    return fields
