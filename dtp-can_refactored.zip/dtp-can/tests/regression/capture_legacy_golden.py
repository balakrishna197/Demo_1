"""Capture golden-master artefacts from the ORIGINAL (V6.2.1) code base.

Usage::

    python -I tests/regression/capture_legacy_golden.py --legacy-root /path/to/V6.2.1

The legacy ``drivers`` package is copied to a scratch directory, its
``UDSClient`` is driven against the ECU simulator, and the following files are
written to ``tests/fixtures/golden``:

* ``legacy_run_requests.json``  - request payloads the ECU received (run_testcase)
* ``legacy_ecu_info.json``      - get_ecu_information() result + requests
* ``golden_run_20250101_120000.asc`` - CAN log produced by the legacy run
* ``golden_report_20250101_120000.html`` - legacy report regenerated from that
  fixed ASC with deterministic metadata (byte-for-byte regression target)

Only needs python-can / can-isotp / udsoncan; no Raspberry Pi hardware.
"""

from __future__ import annotations

import argparse
import datetime
import json
import os
import shutil
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
FIXTURES = os.path.join(PROJECT_ROOT, "tests", "fixtures")
GOLDEN = os.path.join(FIXTURES, "golden")
sys.path.insert(0, PROJECT_ROOT)

from tests.support import virtual_bus  # noqa: E402
from tests.support.ecu_simulator import EcuSimulator, UdpKeyServer  # noqa: E402

virtual_bus.install()

FIXED_START = datetime.datetime(2025, 1, 1, 12, 0, 0)
FIXED_END = datetime.datetime(2025, 1, 1, 12, 0, 30)
FIXED_MTIME = datetime.datetime(2025, 1, 1, 12, 0, 7).timestamp()


class RecordingDisplay:
    def __init__(self):
        self.messages = []

    def display_centered_text(self, text):
        self.messages.append(text)

    def display_text(self, text, line=0):
        self.messages.append(text)

    def clear(self):
        pass

    def set_wifi_status(self, status):
        pass


def write_config(dest_path, port):
    with open(os.path.join(FIXTURES, "sim_config.json")) as fh:
        cfg = json.load(fh)
    cfg["uds"]["udp_server"]["port"] = port
    with open(dest_path, "w") as fh:
        json.dump(cfg, fh, indent=2)
    return cfg


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--legacy-root", required=True)
    args = parser.parse_args()

    os.makedirs(GOLDEN, exist_ok=True)
    scratch = tempfile.mkdtemp(prefix="legacy_")
    shutil.copytree(
        os.path.join(args.legacy_root, "drivers"),
        os.path.join(scratch, "drivers"),
    )
    sys.path.insert(0, scratch)

    from drivers import uds_client  # type: ignore
    from drivers.report_generator import generate_report  # type: ignore

    drivers_dir = os.path.join(scratch, "drivers")
    support_dir = os.path.join(drivers_dir, "supportfiles")
    os.makedirs(support_dir, exist_ok=True)
    shutil.copy(os.path.join(FIXTURES, "sim_testcases.txt"), support_dir)
    with open(os.path.join(drivers_dir, "selected_testcase.txt"), "w") as fh:
        fh.write("sim_testcases.txt")

    repo = os.path.join(scratch, "repo")
    os.makedirs(repo)

    with UdpKeyServer() as keysrv, EcuSimulator("SIMBUS") as ecu:
        cfg_path = os.path.join(scratch, "sim_config.json")
        cfg = write_config(cfg_path, keysrv.port)
        client = uds_client.UDSClient(cfg, config_path=cfg_path)
        client.repo_path = repo
        client.report_branch_name = "golden/branch"
        client.report_branch_url = "https://example.invalid/golden"
        display = RecordingDisplay()

        ecu_info = client.get_ecu_information(display)
        ecu_info_requests = list(ecu.requests)
        ecu.requests.clear()
        time.sleep(0.2)

        client.run_testcase(display, tester_name="Golden Tester")
        run_requests = list(ecu.requests)
        seeds = [s.decode() for s in keysrv.seeds]

    asc_dir = os.path.join(scratch, "output", "can_logs")
    asc_files = sorted(os.listdir(asc_dir))
    asc_src = os.path.join(asc_dir, asc_files[-1])

    with open(os.path.join(GOLDEN, "legacy_run_requests.json"), "w") as fh:
        json.dump({"requests": run_requests, "seeds_sent_to_udp": seeds}, fh, indent=2)
    with open(os.path.join(GOLDEN, "legacy_ecu_info.json"), "w") as fh:
        json.dump({"result": ecu_info, "requests": ecu_info_requests}, fh, indent=2)

    asc_fixed = os.path.join(GOLDEN, "golden_run_20250101_120000.asc")
    shutil.copy(asc_src, asc_fixed)
    cfg_fixed = os.path.join(GOLDEN, "golden_config.json")
    shutil.copy(os.path.join(FIXTURES, "sim_config.json"), cfg_fixed)
    os.utime(cfg_fixed, (FIXED_MTIME, FIXED_MTIME))

    html_out = os.path.join(GOLDEN, "golden_report_20250101_120000.html")
    generate_report(
        asc_file_path=asc_fixed,
        txt_file_path=os.path.join(FIXTURES, "sim_testcases.txt"),
        output_html_file=html_out,
        allowed_tx_ids=client.allowed_tx_ids,
        allowed_rx_ids=client.allowed_rx_ids,
        ecu_info_data={},
        target_ecu=client.target_ecu,
        ecu_info_field_map=client.info_dids,
        tester_name="Golden Tester",
        input_json_file=cfg_fixed,
        test_start_time=FIXED_START,
        test_end_time=FIXED_END,
        branch_name="golden/branch",
        branch_url="https://example.invalid/golden",
    )
    # Also keep the legacy live-run report (timestamps differ run to run).
    live_reports = os.listdir(os.path.join(repo, "output", "html_reports"))
    shutil.copy(
        os.path.join(repo, "output", "html_reports", live_reports[0]),
        os.path.join(GOLDEN, "legacy_live_report.html"),
    )
    print("Requests:", run_requests)
    print("ECU info:", ecu_info)
    print("Golden artefacts written to", GOLDEN)


if __name__ == "__main__":
    main()
