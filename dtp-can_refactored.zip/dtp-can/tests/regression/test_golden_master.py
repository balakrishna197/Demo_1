"""Regression against artefacts captured from the ORIGINAL V6.2.1 code.

See ``capture_legacy_golden.py`` for how they were produced.
"""

import datetime
import json
import os
import re
import time

import pytest

from dtp_can.config.uds_config import UdsConfig
from dtp_can.diagnostics.factory import build_diagnostics
from dtp_can.diagnostics.runner import ReportContext
from dtp_can.reporting import generate_report
from tests.conftest import GOLDEN, SIM_TESTCASES
from tests.support import virtual_bus

pytestmark = pytest.mark.integration


def _golden(name):
    with open(os.path.join(GOLDEN, name)) as fh:
        return json.load(fh)


def test_report_is_byte_identical_to_v621(tmp_path):
    out = tmp_path / "golden_report_20250101_120000.html"
    generate_report(
        asc_file_path=os.path.join(GOLDEN, "golden_run_20250101_120000.asc"),
        txt_file_path=SIM_TESTCASES,
        output_html_file=str(out),
        allowed_tx_ids=[0x7E0, 0x7DF],
        allowed_rx_ids=[0x7E8, 0x7E8],
        ecu_info_data={},
        target_ecu="SIM_ECU",
        ecu_info_field_map={"F190": "VIN Number", "F18C": "ECU Serial Number"},
        tester_name="Golden Tester",
        input_json_file=os.path.join(GOLDEN, "golden_config.json"),
        test_start_time=datetime.datetime(2025, 1, 1, 12, 0, 0),
        test_end_time=datetime.datetime(2025, 1, 1, 12, 0, 30),
        branch_name="golden/branch",
        branch_url="https://example.invalid/golden",
    )
    with open(os.path.join(GOLDEN, "golden_report_20250101_120000.html"), encoding="utf-8") as fh:
        expected = fh.read()
    assert out.read_text(encoding="utf-8") == expected


def _verdicts(html):
    return re.findall(r"<summary>(.*?) - <span class='\w+'>(\w+)</span>", html)


def _rows(html):
    """Response rows without the run-specific timestamp column."""
    return re.findall(
        r"<td>(Response Received|No Response|Not Observed in ASC)</td>\s*<td>(.*?)</td>"
        r"<td>(\w+)</td>\s*<td>(.*?)</td>",
        html,
    )


@pytest.fixture
def stack(simulated_ecu, workspace, tmp_path):
    ecu, keysrv, cfg = simulated_ecu
    diag = build_diagnostics(
        UdsConfig(cfg, path=os.path.join(GOLDEN, "golden_config.json")),
        workspace,
        str(tmp_path / "output" / "can_logs"),
        report_context=ReportContext(str(tmp_path / "repo"), "golden/branch", "u"),
        bus_factory=virtual_bus.create_bus,
    )
    yield diag, ecu, keysrv, tmp_path
    diag.close()


def test_live_run_matches_v621_traffic_and_verdicts(stack, display):
    diag, ecu, keysrv, tmp_path = stack
    ecu_info = diag.ecu_info.read(display)
    golden_info = _golden("legacy_ecu_info.json")
    assert ecu_info == golden_info["result"]
    assert ecu.requests == golden_info["requests"]

    ecu.requests.clear()
    time.sleep(0.2)
    result = diag.runner.run(display, tester_name="Golden Tester")
    golden_run = _golden("legacy_run_requests.json")
    assert ecu.requests == golden_run["requests"]
    assert [s.decode() for s in keysrv.seeds] == golden_run["seeds_sent_to_udp"]

    # Report produced from the new run has the same verdicts and response
    # rows as the report produced by V6.2.1 from its own run.
    new_html = open(result.report, encoding="utf-8").read()
    with open(os.path.join(GOLDEN, "legacy_live_report.html"), encoding="utf-8") as fh:
        legacy_html = fh.read()
    assert _verdicts(new_html) == _verdicts(legacy_html)
    assert _rows(new_html) == _rows(legacy_html)
    assert os.path.basename(result.can_log).startswith("sim_testcases_")
    assert result.report.startswith(str(tmp_path / "repo" / "output" / "html_reports"))


def test_can_logger_releases_bus(stack):
    diag, *_ = stack
    diag.can_logger.start("x.asc")
    bus = diag.can_logger.bus
    diag.can_logger.stop()
    assert diag.can_logger.bus is None
    assert bus._is_shutdown  # V6.2.1 leaked this socket (B-03)
