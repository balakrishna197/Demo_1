import itertools
import json
import os
import sys

import pytest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

FIXTURES = os.path.join(ROOT, "tests", "fixtures")
GOLDEN = os.path.join(FIXTURES, "golden")
SIM_TESTCASES = os.path.join(FIXTURES, "sim_testcases.txt")
SIM_CONFIG = os.path.join(FIXTURES, "sim_config.json")

_channel_counter = itertools.count(1)


@pytest.fixture
def sim_config_dict():
    with open(SIM_CONFIG) as fh:
        return json.load(fh)


@pytest.fixture
def uds_config(sim_config_dict):
    from dtp_can.config.uds_config import UdsConfig

    return UdsConfig(sim_config_dict, path=SIM_CONFIG)


@pytest.fixture
def workspace(tmp_path):
    from dtp_can.testcases.workspace import TestcaseWorkspace

    ws = TestcaseWorkspace(str(tmp_path / "supportfiles"), str(tmp_path / "selected_testcase.txt"))
    ws.install_testcase(SIM_TESTCASES)
    return ws


@pytest.fixture
def simulated_ecu(sim_config_dict):
    """Running ECU + UDP key server on a fresh virtual channel.

    Yields ``(ecu, keyserver, config_dict)`` where the config points at both.
    """
    from tests.support.ecu_simulator import EcuSimulator, UdpKeyServer

    channel = f"SIM{next(_channel_counter)}"
    with UdpKeyServer() as keysrv, EcuSimulator(channel) as ecu:
        cfg = json.loads(json.dumps(sim_config_dict))
        cfg["uds"]["can"]["channel"] = channel
        cfg["uds"]["udp_server"]["port"] = keysrv.port
        yield ecu, keysrv, cfg


class RecordingDisplay:
    def __init__(self):
        self.messages = []
        self.wifi = []

    def display_centered_text(self, text):
        self.messages.append(text)

    def display_text(self, text, line=0):
        self.messages.append(text)

    def clear(self):
        pass

    def set_wifi_status(self, status):
        self.wifi.append(status)


@pytest.fixture
def display():
    return RecordingDisplay()
