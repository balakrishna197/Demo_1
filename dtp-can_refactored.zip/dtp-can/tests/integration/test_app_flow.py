"""Application-level flow: startup pipeline + menu features on the simulator."""

import os

import pytest

from dtp_can.app.bootstrap import build_context
from dtp_can.app.events import REPORTS_PUSHED, SESSION_READY, TEST_RUN_FINISHED, WIFI_STATUS
from dtp_can.app.features import FEATURES
from dtp_can.app.paths import AppPaths
from dtp_can.app.startup import StartupPipeline
from dtp_can.app.workflows.session_setup import SessionSetupWorkflow, offline_session
from dtp_can.config.settings import AppSettings
from dtp_can.platform.shell import RecordingRunner
from dtp_can.ui.interaction import UserInterface
from dtp_can.vcs.git_client import GitClient
from tests.conftest import SIM_TESTCASES, RecordingDisplay
from tests.support import virtual_bus
from tests.support.fakes import ScriptedKeys

pytestmark = pytest.mark.integration


def scripted_ui(keys):
    return UserInterface(display=RecordingDisplay(), terminal_input=ScriptedKeys(keys),
                         sleep=lambda s: None, clear_console=lambda: None, echo=lambda s: None)


@pytest.fixture
def app(simulated_ecu, tmp_path):
    _ecu, _keys, cfg = simulated_ecu
    import json

    cfg_path = tmp_path / "bench.json"
    cfg_path.write_text(json.dumps(cfg))
    paths = AppPaths(str(tmp_path / "app"))
    paths.ensure()
    runner = RecordingRunner()
    ctx = build_context(paths, AppSettings(), runner=runner)
    ctx.bus_factory = virtual_bus.create_bus
    ctx.sleep = lambda s: None
    ctx.session = offline_session(str(cfg_path), SIM_TESTCASES, ctx.workspace, str(tmp_path / "repo"))
    events = []
    for topic in (SESSION_READY, TEST_RUN_FINISHED, REPORTS_PUSHED, WIFI_STATUS):
        ctx.events.subscribe(topic, lambda p, t=topic: events.append(t))
    yield ctx, events, runner
    if ctx.diagnostics:
        ctx.diagnostics.close()


def test_offline_startup_and_features(app):
    ctx, events, runner = app
    ctx.ui = scripted_ui(["B", "e", "n", "c", "h", "ENTER"])
    StartupPipeline(["user_interface", "test_session", "diagnostics", "can_readiness",
                     "usb_storage"]).run(ctx)
    assert ctx.diagnostics.seed_key.available is True
    assert SESSION_READY in events

    features = {f.feature_id: f for f in FEATURES.create(
        ["ecu_info", "run_tests", "push_reports", "usb_transfer"], ctx)}
    features["ecu_info"].run()
    assert "Reading\nECU Info" in ctx.ui.display.messages
    assert "VIN Number\nWDB1234567890ABCD" in ctx.ui.display.messages

    features["run_tests"].run()
    assert TEST_RUN_FINISHED in events
    new_files = ctx.report_tracker.current_run_reports
    assert len(new_files) == 1 and new_files[0].endswith(".asc")
    reports = os.listdir(os.path.join(ctx.session.repo_path, "output", "html_reports"))
    assert len(reports) == 1
    html = open(os.path.join(ctx.session.repo_path, "output", "html_reports", reports[0])).read()
    assert "<td>Tester Name</td><td>Bench</td>" in html

    # Offline: push fails gracefully, nothing is executed
    features["push_reports"].run()
    assert ctx.ui.display.messages[-1] == "Bitbucket Push\nFailed"

    ctx.events.publish(WIFI_STATUS, "W~")
    assert ctx.ui.display.wifi[-1] == "W~"


def test_push_reports_with_git(app, tmp_path):
    ctx, events, runner = app
    ctx.ui = scripted_ui([])
    ctx.git = GitClient("git@bitbucket.org:org/r.git", str(tmp_path), runner)
    ctx.git.branch, ctx.git.repo_path = "E1/V1/T/S/D", ctx.session.repo_path
    (tmp_path / "app" / "output" / "can_logs").mkdir(parents=True, exist_ok=True)
    ctx.report_tracker.start()
    (tmp_path / "app" / "output" / "can_logs" / "run.asc").write_text("asc")
    ctx.report_tracker.finish()
    FEATURES.create(["push_reports"], ctx)[0].run()
    assert ctx.ui.display.messages[-1] == "Upload\nComplete"
    assert REPORTS_PUSHED in events
    assert runner.calls[-1][-4:] == ["push", "-u", "origin", "E1/V1/T/S/D"]
    assert os.path.exists(os.path.join(ctx.session.repo_path, "output", "can_logs", "run.asc"))


def test_session_setup_workflow_selects_branch_and_files(tmp_path):
    repo_url = "git@bitbucket.org:org/r.git"
    branch = "E1/V1/SYS/S1/2025-01-01"
    runner = RecordingRunner(responses={
        f"git ls-remote --heads {repo_url}": (0, f"a\trefs/heads/{branch}\nb\trefs/heads/main\n", ""),
        "git -C {} rev-parse HEAD".format(tmp_path / branch.replace("/", "_")): (0, "abc123\n", ""),
    })
    checkout = tmp_path / branch.replace("/", "_")
    checkout.mkdir()
    (checkout / "tc.txt").write_text(open(SIM_TESTCASES).read())
    import shutil

    shutil.copy(os.path.join(os.path.dirname(SIM_TESTCASES), "sim_config.json"), checkout / "cfg.json")
    from dtp_can.testcases.workspace import TestcaseWorkspace

    ws = TestcaseWorkspace(str(tmp_path / "sf"), str(tmp_path / "sel.txt"))
    ui = scripted_ui(["ENTER"] * 5)
    session = SessionSetupWorkflow(ui, GitClient(repo_url, str(tmp_path), runner), ws,
                                   AppSettings().git.branch_levels, lambda s: None).run()
    assert session.branch == branch
    assert session.branch_url == f"https://bitbucket.org/org/r/src/abc123/?at={branch}"
    assert session.selections["Employee"] == "E1"
    assert ws.active_testcase().endswith("tc.txt")
    assert ui.display.messages[-1] == "Repository\nReady"


def test_can_readiness_brings_up_can_and_reuses_transport(app):
    """B-05: readiness check re-uses/reset the main transport (no leaked clients)."""
    ctx, _events, runner = app
    ctx.ui = scripted_ui([])
    ctx.session.uds_config.can["bringup_on_startup"] = True
    runner.responses["ip link show can0"] = (0, "3: can0: <NOARP,UP> mtu 72", "")
    StartupPipeline(["user_interface", "test_session", "diagnostics"]).run(ctx)
    transport = ctx.diagnostics.transport
    old_bus = transport.physical_conn.bus
    StartupPipeline(["can_readiness"]).run(ctx)
    assert ["sudo", "ip", "link", "set", "can0", "up", "type", "can", "bitrate", "500000",
            "dbitrate", "2000000", "restart-ms", "1000", "berr-reporting", "on", "fd", "on"] in runner.calls
    assert ctx.diagnostics.transport is transport          # same stack, no throw-away client
    assert old_bus._is_shutdown and transport.physical_conn.bus is not old_bus
