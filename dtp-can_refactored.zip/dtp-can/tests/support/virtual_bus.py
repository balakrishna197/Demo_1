"""A python-can virtual bus that filters like SocketCAN does (in the kernel).

python-can's ``VirtualBus`` applies ``can_filters`` in software inside
``BusABC.recv``.  With ``timeout=0`` a single non-matching frame at the head of
the queue makes ``recv`` return ``None`` even when matching frames are queued
behind it.  On a Raspberry Pi with SocketCAN the kernel drops non-matching
frames before they reach the socket, so a zero-timeout drain empties the
socket completely.  The diagnostic transport relies on that behaviour, so the
simulator must reproduce it to be representative.
"""

from __future__ import annotations

import queue
import time
from copy import deepcopy

import can
from can.interfaces.virtual import VirtualBus

_ORIGINAL_BUS = can.interface.Bus


class KernelFilteredVirtualBus(VirtualBus):
    """Virtual bus instance that represents a socket *on the Raspberry Pi*.

    Frames sent from such a socket are delivered to other local sockets with
    ``is_rx=False`` - exactly what SocketCAN reports for locally originated
    loop-back frames (MSG_DONTROUTE), so the ASC log shows them as ``Tx``.
    Frames from the ECU simulator (a plain ``VirtualBus``) stay ``Rx``.
    """

    def send(self, msg, timeout=None):
        self._check_if_open()
        timestamp = msg.timestamp if self.preserve_timestamps else time.time()
        for bus_queue in self.channel:
            if bus_queue is self.queue and not self.receive_own_messages:
                continue
            msg_copy = deepcopy(msg)
            msg_copy.timestamp = timestamp
            msg_copy.channel = self.channel_id
            msg_copy.is_rx = False
            bus_queue.put(msg_copy, block=True, timeout=timeout)

    def _recv_internal(self, timeout):
        deadline = None if timeout is None else time.monotonic() + timeout
        while True:
            remaining = None
            if deadline is not None:
                remaining = max(0.0, deadline - time.monotonic())
            try:
                msg = self.queue.get(block=True, timeout=remaining)
            except queue.Empty:
                return None, True
            if self._matches_filters(msg):
                return msg, True
            if deadline is not None and time.monotonic() >= deadline:
                # keep draining non-matching frames without blocking
                continue


def create_bus(*args, **kwargs):
    """Drop-in replacement for ``can.interface.Bus`` used by tests."""
    interface = kwargs.get("interface") or kwargs.get("bustype")
    if interface == "virtual":
        kwargs.pop("interface", None)
        kwargs.pop("bustype", None)
        return KernelFilteredVirtualBus(*args, **kwargs)
    return _ORIGINAL_BUS(*args, **kwargs)


def install() -> None:
    """Patch ``can.interface.Bus`` and ``can.Bus`` globally (test only)."""
    can.interface.Bus = create_bus  # type: ignore[assignment]
    can.Bus = create_bus  # type: ignore[assignment]
