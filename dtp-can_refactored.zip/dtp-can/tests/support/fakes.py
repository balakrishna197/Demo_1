"""Hand-written test doubles shared by unit tests."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Dict, List, Optional


class FakeTransport:
    """Records raw requests; answers from a ``{hex: bytes}`` table."""

    def __init__(self, responses: Optional[Dict[str, Optional[bytes]]] = None):
        self.responses = responses or {}
        self.sent: List[dict] = []
        self.active_conn = object()
        self.mode_switches: List[str] = []
        self.drains = 0

    def send_request_and_wait(self, client, raw_request, tc_id, step_desc,
                              post_wait=0.0, expected_bytes=None):
        key = bytes(raw_request).hex().upper()
        self.sent.append({"raw": key, "post_wait": post_wait, "expected": expected_bytes})
        return self.responses.get(key)

    def switch_mode(self, mode):
        self.mode_switches.append(mode)

    def drain(self, conn):
        self.drains += 1

    @contextmanager
    def open_client(self, use_active_config=True):
        yield object()


class FakeSeedKey:
    def __init__(self, key=b"KEY1", available=True, server_ok=True):
        self.key = key
        self.available = available
        self.server_ok = server_ok
        self.seeds = []

    def check_server(self):
        return self.server_ok

    def request_key(self, seed):
        self.seeds.append(seed)
        return self.key


class ScriptedButtons:
    """Button pad that returns a scripted sequence of presses."""

    def __init__(self, presses):
        self.presses = list(presses)

    def get_pressed_nonblocking(self):
        return self.presses.pop(0) if self.presses else None


class ScriptedKeys:
    """Terminal input double returning scripted keys/actions."""

    def __init__(self, keys):
        self.keys = list(keys)

    def is_available(self):
        return True

    def read_key(self, timeout=0):
        return self.keys.pop(0) if self.keys else None

    def poll_action(self, timeout=0.1):
        from dtp_can.ui.terminal import TerminalInput

        key = self.read_key()
        if key is None:
            return None
        return TerminalInput.poll_action.__get__(_Once(key))(timeout)

    def restore(self):
        pass


class _Once:
    def __init__(self, key):
        self._key = key

    def read_key(self, timeout=0):
        key, self._key = self._key, None
        return key
