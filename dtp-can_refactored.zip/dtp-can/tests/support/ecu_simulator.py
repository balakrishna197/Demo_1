"""Deterministic UDS ECU simulator on a python-can *virtual* bus.

Used by the integration and regression tests so the complete execution
pipeline (transport -> service handlers -> CAN logging -> report) can run
without hardware.  The simulator implements just enough ISO-TP (SF, FF/FC/CF
in both directions) for the diagnostic services exercised by the fixtures.

Response rules are keyed by the upper-case hex request payload.  A rule value
can be:

* ``bytes``                  - single positive/negative response
* ``("pending", bytes)``     - 7F xx 78 first, then the final response
* ``None``                   - stay silent (no response)
* ``callable(payload)``      - computed response (returns any of the above)
"""

from __future__ import annotations

import socket
import threading
import time
from typing import Callable, Dict, Optional, Union

import can
from can.interfaces.virtual import VirtualBus

Rule = Union[bytes, tuple, None, Callable[[bytes], object]]

PAD = 0xAA
SEED = bytes([0x12, 0x34, 0x56, 0x78])
KEY = b"KEY1"  # 4 bytes, matches expected_key_length in the fixture config


def default_rules() -> Dict[str, Rule]:
    vin = b"WDB1234567890ABCD"
    return {
        "1001": bytes([0x50, 0x01, 0x00, 0x32, 0x01, 0xF4]),
        "1003": bytes([0x50, 0x03, 0x00, 0x32, 0x01, 0xF4]),
        "10": bytes([0x7F, 0x10, 0x13]),
        "22F190": bytes([0x62, 0xF1, 0x90]) + vin,
        "22F18C": bytes([0x62, 0xF1, 0x8C]) + b"SN0042",
        "22F18B": bytes([0x62, 0xF1, 0x8B, 0x20, 0x25, 0x08, 0x01]),
        "22F187": ("pending", bytes([0x62, 0xF1, 0x87]) + b"PN-998877"),
        "221234": bytes([0x7F, 0x22, 0x31]),
        "22F199": None,
        "3E00": bytes([0x7E, 0x00]),
        "3E80": None,
        "2701": bytes([0x67, 0x01]) + SEED,
        "2702" + KEY.hex().upper(): bytes([0x67, 0x02]),
        "2EF190": lambda p: bytes([0x6E, 0xF1, 0x90]),
        "1902FF": bytes([0x59, 0x02, 0xFF, 0x12, 0x34, 0x56, 0x2F]),
        "14FFFFFF": bytes([0x54]),
        "8502": bytes([0xC5, 0x02]),
        "280301": bytes([0x68, 0x03]),
        "2FF1000301": bytes([0x6F, 0xF1, 0x00, 0x03, 0x01]),
        "1101": bytes([0x51, 0x01]),
    }


class EcuSimulator:
    def __init__(
        self,
        channel: str,
        phys_rx: int = 0x7E0,
        func_rx: int = 0x7DF,
        tx_id: int = 0x7E8,
        rules: Optional[Dict[str, Rule]] = None,
        fd: bool = True,
    ):
        self.channel = channel
        self.phys_rx = phys_rx
        self.func_rx = func_rx
        self.tx_id = tx_id
        self.rules = rules if rules is not None else default_rules()
        self.fd = fd
        self.requests: list[str] = []
        self._stop = threading.Event()
        self._bus = VirtualBus(channel=channel, fd=fd)  # "remote" node: plain bus
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._fc_event = threading.Event()

    # -- lifecycle -------------------------------------------------------
    def start(self) -> "EcuSimulator":
        self._thread.start()
        return self

    def stop(self) -> None:
        self._stop.set()
        self._thread.join(timeout=2)
        self._bus.shutdown()

    def __enter__(self):
        return self.start()

    def __exit__(self, *exc):
        self.stop()

    # -- ISO-TP helpers --------------------------------------------------
    def _send(self, data: list[int]) -> None:
        data = list(data) + [PAD] * (8 - len(data))
        self._bus.send(
            can.Message(
                arbitration_id=self.tx_id,
                is_extended_id=False,
                is_fd=self.fd,
                data=bytes(data[:8]),
            )
        )

    def _respond(self, payload: bytes) -> None:
        if len(payload) <= 7:
            self._send([len(payload)] + list(payload))
            return
        total = len(payload)
        self._fc_event.clear()
        self._send([0x10 | ((total >> 8) & 0x0F), total & 0xFF] + list(payload[:6]))
        # Wait for the tester's flow control (sent by the tester stack).
        self._fc_event.wait(timeout=1.0)
        idx, sn = 6, 1
        while idx < total:
            time.sleep(0.002)
            self._send([0x20 | (sn & 0x0F)] + list(payload[idx:idx + 7]))
            idx += 7
            sn += 1

    def _resolve(self, payload: bytes):
        key = payload.hex().upper()
        rule = self.rules.get(key, "__missing__")
        if callable(rule):
            rule = rule(payload)
        if rule == "__missing__":
            # Generic fallback: serviceNotSupported
            return bytes([0x7F, payload[0], 0x11]) if payload else None
        return rule

    def _handle_request(self, payload: bytes) -> None:
        self.requests.append(payload.hex().upper())
        rule = self._resolve(payload)
        if rule is None:
            return
        if isinstance(rule, tuple) and rule and rule[0] == "pending":
            self._send([3, 0x7F, payload[0], 0x78])
            time.sleep(0.05)
            rule = rule[1]
        time.sleep(0.003)
        self._respond(rule)

    # -- main loop -------------------------------------------------------
    def _run(self) -> None:
        rx_buffer: Optional[bytearray] = None
        rx_total = 0
        while not self._stop.is_set():
            msg = self._bus.recv(timeout=0.05)
            if msg is None:
                continue
            if msg.arbitration_id not in (self.phys_rx, self.func_rx):
                continue
            data = bytes(msg.data)
            if not data:
                continue
            ftype = data[0] >> 4
            if ftype == 0x3:  # flow control from tester
                self._fc_event.set()
                continue
            if ftype == 0x0:
                length = data[0] & 0x0F
                self._handle_request(data[1:1 + length])
            elif ftype == 0x1:
                rx_total = ((data[0] & 0x0F) << 8) | data[1]
                rx_buffer = bytearray(data[2:])
                self._send([0x30, 0x00, 0x00])
            elif ftype == 0x2 and rx_buffer is not None:
                rx_buffer.extend(data[1:])
                if len(rx_buffer) >= rx_total:
                    payload = bytes(rx_buffer[:rx_total])
                    rx_buffer = None
                    self._handle_request(payload)


class UdpKeyServer:
    """Stand-in for the PC seed/key UDP service."""

    def __init__(self, key: bytes = KEY):
        self.key = key
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("127.0.0.1", 0))
        self.sock.settimeout(0.1)
        self.port = self.sock.getsockname()[1]
        self.seeds: list[bytes] = []
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        while not self._stop.is_set():
            try:
                data, addr = self.sock.recvfrom(1024)
            except socket.timeout:
                continue
            except OSError:
                return
            self.seeds.append(data)
            self.sock.sendto(self.key, addr)

    def __enter__(self):
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        self._thread.join(timeout=2)
        self.sock.close()
