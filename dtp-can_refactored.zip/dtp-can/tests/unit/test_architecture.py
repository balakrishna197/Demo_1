"""Executable architecture rules (dependency validation)."""

import ast
import os
import re
import subprocess
import sys

import pytest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
PKG = os.path.join(ROOT, "dtp_can")

# layer -> layers it may import (besides itself)
ALLOWED = {
    "core": set(),
    "config": {"core"},
    "testcases": {"core", "config"},
    "reporting": {"core", "testcases"},
    "diagnostics": {"core", "config", "testcases", "reporting"},
    "ui": {"core", "config"},
    "platform": {"core", "config"},
    "vcs": {"core", "platform"},
    "app": {"core", "config", "testcases", "reporting", "diagnostics", "ui", "platform", "vcs"},
}
HARDWARE_MODULES = {"RPi", "board", "busio", "adafruit_ssd1306"}


def modules():
    for dirpath, _dirs, files in os.walk(PKG):
        for f in files:
            if f.endswith(".py"):
                path = os.path.join(dirpath, f)
                rel = os.path.relpath(path, ROOT)[:-3].replace(os.sep, ".")
                yield rel.replace(".__init__", ""), path


def imports(path, top_level_only=False):
    tree = ast.parse(open(path, encoding="utf-8").read())
    nodes = tree.body if top_level_only else ast.walk(tree)
    for node in nodes:
        if isinstance(node, ast.Import):
            for alias in node.names:
                yield alias.name
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            for alias in node.names:
                candidate = f"{node.module}.{alias.name}"
                if os.path.exists(os.path.join(ROOT, *candidate.split(".")) + ".py"):
                    yield candidate  # "from pkg import submodule"
                else:
                    yield node.module


def layer(module):
    parts = module.split(".")
    return parts[1] if len(parts) > 1 else None


@pytest.mark.parametrize("module,path", sorted(modules()))
def test_layer_dependencies(module, path):
    own = layer(module)
    if own is None:
        return
    for imported in imports(path):
        if imported.startswith("dtp_can."):
            target = layer(imported)
            assert target == own or target in ALLOWED[own], f"{module} -> {imported}"


def test_no_import_cycles_between_modules():
    graph = {m: {i for i in imports(p) if i.startswith("dtp_can.")} for m, p in modules()}
    names = set(graph)

    def resolve(name):
        while name and name not in names:
            name = name.rpartition(".")[0]
        return name

    graph = {m: {resolve(i) for i in deps} - {m, None, ""} for m, deps in graph.items()}
    state = {}

    def visit(node, stack):
        state[node] = 1
        for dep in graph.get(node, ()):
            if dep.endswith(".__init__") or dep == "dtp_can":
                continue
            if state.get(dep) == 1 and not module_is_package(dep):
                raise AssertionError("cycle: " + " -> ".join(stack + [dep]))
            if dep not in state:
                visit(dep, stack + [dep])
        state[node] = 2

    for node in graph:
        if node not in state:
            visit(node, [node])


def module_is_package(name):
    return os.path.exists(os.path.join(ROOT, *name.split("."), "__init__.py"))


@pytest.mark.parametrize("module,_path", sorted(modules()))
def test_every_module_imports_in_isolation(module, _path):
    result = subprocess.run([sys.executable, "-c", f"import {module}"], cwd=ROOT,
                            capture_output=True, text=True)
    assert result.returncode == 0, result.stderr


def test_subprocess_only_in_platform_layer():
    for module, path in modules():
        if "subprocess" in set(imports(path)):
            assert layer(module) == "platform", module


def test_hardware_libraries_never_imported_at_module_level():
    for module, path in modules():
        top = {name.split(".")[0] for name in imports(path, top_level_only=True)}
        assert not (top & HARDWARE_MODULES), module


def test_no_private_key_material_in_tree():
    pattern = re.compile(r"BEGIN (OPENSSH|RSA|EC) PRIVATE KEY")
    for dirpath, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", ".pytest_cache", "venv"}]
        for f in files:
            if f.endswith((".py", ".json", ".txt", ".md", ".sh", ".cfg", ".ini")):
                text = open(os.path.join(dirpath, f), encoding="utf-8", errors="ignore").read()
                assert not pattern.search(text), os.path.join(dirpath, f)
