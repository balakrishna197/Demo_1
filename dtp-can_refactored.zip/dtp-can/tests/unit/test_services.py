"""Per-SID request construction and error policy (pins V6.2.1 behaviour)."""

import pytest

from dtp_can.core.models import TestStep
from dtp_can.diagnostics.services import StepContext, StepOutcome, default_registry
from dtp_can.diagnostics.services.base import ServiceHandler
from dtp_can.diagnostics.services.generic import BareServiceHandler, UnsupportedServiceHandler
from dtp_can.diagnostics.services.registry import ServiceRegistry
from tests.support.fakes import FakeSeedKey, FakeTransport


def make_step(service, sub="", expected="", write="", status_mask="", comm="", control="",
              tc_id="TC", desc="desc", addressing="physical"):
    return TestStep(tc_id, desc, service, sub, expected, write, addressing, "Hex",
                    status_mask, comm, control)


def run(step, responses=None, state=None, seed_key=None, display=None):
    transport = FakeTransport(responses)
    sid = int(step.service, 16)
    ctx = StepContext(
        step=step,
        sid=sid,
        expected_bytes=[int(b, 16) for b in step.expected.split()],
        write_bytes=[int(b, 16) for b in step.write_data.split()] if step.write_data else [],
        client=object(),
        transport=transport,
        display=display,
        state=state if state is not None else {},
        seed_key=seed_key,
        sleep=lambda s: None,
    )
    outcome = default_registry().resolve(sid, step).execute(ctx)
    return transport, outcome, ctx


@pytest.mark.parametrize(
    "step, expected_raw",
    [
        (make_step("10", "01"), "1001"),
        (make_step("10", "0x03"), "1003"),
        (make_step("10", ""), "10"),
        (make_step("11", "01"), "1101"),
        (make_step("11", ""), "11"),
        (make_step("22", "F190"), "22F190"),
        (make_step("22", "190"), "220190"),           # odd length padded
        (make_step("22", "0xF1 90"), "22F190"),
        (make_step("2E", "F190", write="41 42"), "2EF1904142"),
        (make_step("2F", "F100", write="01", control="03"), "2FF1000301"),
        (make_step("2F", "F100"), "2FF10000"),           # default control 0
        (make_step("2F", ""), "2F"),
        (make_step("19", "02", status_mask="FF"), "1902FF"),
        (make_step("19", "0x06", status_mask="FF", write="12 34 56"), "1906FF123456"),
        (make_step("14", "FFFFFF"), "14FFFFFF"),
        (make_step("14", "FFF"), "140FFF"),
        (make_step("14", ""), "14"),
        (make_step("3E", "00"), "3E00"),
        (make_step("85", "02"), "8502"),
        (make_step("85", "01", write="FF FF FF"), "8501FFFFFF"),
        (make_step("28", "03", comm="01"), "280301"),
        (make_step("28", "03"), "280303"),   # V6.2.1: comm type defaults to last sub byte
        (make_step("28", ""), "28"),
        (make_step("27", ""), "27"),
        (make_step("27", "0102"), "270102"),  # multi-byte sub-function sent verbatim
        (make_step("31", ""), "31"),          # no handler + empty sub -> bare
    ],
)
def test_request_bytes_match_legacy(step, expected_raw):
    transport, _, _ = run(step)
    assert [s["raw"] for s in transport.sent] == [expected_raw]


@pytest.mark.parametrize("step", [make_step("3E", ""), make_step("31", "01FF00")])
def test_steps_that_send_nothing(step):
    """0x3E without sub-function and unsupported SIDs are not transmitted."""
    transport, _, _ = run(step)
    assert transport.sent == []


def test_read_did_passes_expected_and_post_wait():
    transport, _, _ = run(make_step("22", "F190", expected="62 F1 90"))
    assert transport.sent[0]["post_wait"] == 0.05
    assert transport.sent[0]["expected"] == [0x62, 0xF1, 0x90]


def test_write_did_without_data_raises():
    with pytest.raises(ValueError, match="No write data"):
        run(make_step("2E", "F190"))


@pytest.mark.parametrize("step", [make_step("19", "ZZ"), make_step("14", "XY")])
def test_invalid_hex_propagates_for_fail_status(step):
    with pytest.raises(ValueError):
        run(step)


@pytest.mark.parametrize(
    "step", [make_step("10", "ZZ"), make_step("22", "GG"), make_step("85", "QQ"),
             make_step("28", "ZZ"), make_step("2F", "XYZW")]
)
def test_invalid_hex_swallowed_where_legacy_swallowed(step):
    transport, _, _ = run(step)  # must not raise
    assert transport.sent == []


def test_security_access_seed_then_key_flow():
    seed_key = FakeSeedKey(key=b"KEY1")
    state = {}
    responses = {"2701": bytes([0x67, 0x01, 0x12, 0x34, 0x56, 0x78])}
    run(make_step("27", "01", expected="67 01"), responses, state, seed_key)
    assert seed_key.seeds == [bytes([0x12, 0x34, 0x56, 0x78])]
    assert state["seed_1"] == bytes([0x12, 0x34, 0x56, 0x78])
    assert state["key_2"] == b"KEY1"

    responses = {"2702" + b"KEY1".hex().upper(): bytes([0x67, 0x02])}
    transport, outcome, _ = run(make_step("27", "02", expected="67 02"), responses, state, seed_key)
    assert transport.sent[0]["raw"] == "2702" + b"KEY1".hex().upper()
    assert isinstance(outcome, StepOutcome) and outcome.skip_post_step_delay


def test_security_access_negative_seed_raises():
    with pytest.raises(Exception, match="Negative|Expected Positive"):
        run(make_step("27", "01", expected="67 01"), {"2701": bytes([0x7F, 0x27, 0x35])},
            seed_key=FakeSeedKey())


def test_security_access_no_response_raises():
    with pytest.raises(Exception, match="No response received"):
        run(make_step("27", "01", expected="67 01"), {}, seed_key=FakeSeedKey())


def test_security_access_unavailable_server_raises_and_displays(display):
    provider = FakeSeedKey(available=False, server_ok=False)
    with pytest.raises(Exception, match="UDP Server not available"):
        run(make_step("27", "01", expected="67 01"), {"2701": bytes([0x67, 0x01, 1, 2])},
            seed_key=provider, display=display)
    assert "UDP Server\nUnavailable" in display.messages


def test_security_access_key_without_seed_sends_bare_level():
    transport, _, _ = run(make_step("27", "04", expected="67 04"), {"2704": bytes([0x67, 0x04])})
    assert transport.sent[0]["raw"] == "2704"


def test_session_control_no_response_shows_message(display):
    run(make_step("10", "01", tc_id="TCX"), {}, display=display)
    assert "TCX\nNo Response" in display.messages


# --- registry ----------------------------------------------------------------
def test_registry_resolution_order():
    registry = default_registry()
    assert registry.service_ids == [0x10, 0x11, 0x14, 0x19, 0x22, 0x27, 0x28, 0x2E, 0x2F, 0x3E, 0x85]
    assert isinstance(registry.resolve(0x31, make_step("31", "")), BareServiceHandler)
    assert isinstance(registry.resolve(0x31, make_step("31", "01")), UnsupportedServiceHandler)


class RoutineControlHandler(ServiceHandler):
    service_id = 0x31

    def execute(self, ctx):
        ctx.send(bytes([0x31]) + bytes.fromhex(ctx.step.subfunction))


def test_registry_extension_without_touching_runner():
    registry = default_registry()
    registry.register(RoutineControlHandler())
    step = make_step("31", "01FF00")
    transport = FakeTransport()
    ctx = StepContext(step, 0x31, [], [], object(), transport, sleep=lambda s: None)
    registry.resolve(0x31, step).execute(ctx)
    assert transport.sent[0]["raw"] == "3101FF00"


def test_registry_rejects_duplicates_unless_replace():
    registry = default_registry()
    custom_read = type("CustomRead", (BareServiceHandler,), {"service_id": 0x22})()
    with pytest.raises(ValueError, match="already handled"):
        registry.register(custom_read)
    registry.register(custom_read, replace=True)
    assert registry.get(0x22) is custom_read


def test_registry_plugin_loading():
    registry = ServiceRegistry()
    registry.load_plugins(["tests.unit.test_services:RoutineControlHandler"])
    assert registry.get(0x31).__class__.__name__ == "RoutineControlHandler"
    with pytest.raises(ValueError):
        registry.load_plugins(["no_colon_path"])
