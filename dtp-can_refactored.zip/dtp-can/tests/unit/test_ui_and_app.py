import pytest

from dtp_can.app.events import EventBus
from dtp_can.app.features.base import FeatureRegistry, MenuFeature
from dtp_can.app.menu import MainMenu
from dtp_can.app.startup import StartupPipeline
from dtp_can.config.settings import DEFAULT_STARTUP, UiSettings
from dtp_can.ui.factory import build_user_interface
from dtp_can.ui.interaction import UserInterface
from dtp_can.ui.router import DisplayRouter
from tests.conftest import RecordingDisplay
from tests.support.fakes import ScriptedButtons, ScriptedKeys


def make_ui(buttons=None, keys=None):
    display = RecordingDisplay()
    hw = RecordingDisplay() if buttons is not None else None
    ui = UserInterface(display=display, hardware_display=hw, buttons=buttons,
                       terminal_input=keys, sleep=lambda s: None,
                       clear_console=lambda: None, echo=lambda s: None)
    return ui, display, hw


def test_select_from_list_buttons():
    ui, _d, hw = make_ui(buttons=ScriptedButtons([None, 1, 1, 0, 2]))
    assert ui.select_from_list("WiFi", ["a", "b", "c"]) == 1
    assert hw.messages[0] == "WiFi\n\na"


def test_select_from_list_keyboard_digits_and_cancel():
    ui, *_ = make_ui(keys=ScriptedKeys(["3"]))
    assert ui.select_from_list("T", ["a", "b", "c"]) == 2
    ui, *_ = make_ui(keys=ScriptedKeys(["q", "q"]))
    assert ui.select_from_list("T", ["a"], allow_cancel=True) is None


def test_enter_text_keyboard_and_buttons():
    ui, *_ = make_ui(keys=ScriptedKeys(["K", "a", "r", "SPACE", "x", "BACKSPACE", "ENTER"]))
    assert ui.enter_text("Tester Name") == "Kar"
    ui, *_ = make_ui(buttons=ScriptedButtons([2, 0, 2, 3]))  # 'A', next->'B', submit
    assert ui.enter_text("Tester Name") == "AB"


def test_enter_password_buttons():
    ui, display, _ = make_ui(buttons=ScriptedButtons([2, 1, 2, 3]))
    # B2 adds 'A'; B1 moves to previous char ('>'); B2 on '>' submits
    assert ui.enter_password("Lab") == "A"
    assert display.messages[0] == "Password:\n\n\n[A]"


def test_choose_menu_option_buttons_and_digits():
    ui, *_ = make_ui(buttons=ScriptedButtons([None, 3]))
    assert ui.choose_menu_option(4) == 3
    ui, *_ = make_ui(keys=ScriptedKeys(["9", "2"]))
    assert ui.choose_menu_option(4) == 1


def test_ui_factory_auto_falls_back_to_terminal():
    def broken(_):
        raise RuntimeError("no i2c")

    class NoTty:
        def is_available(self):
            return False

    ui = build_user_interface(UiSettings(mode="auto"), oled_factory=broken, terminal_input_factory=NoTty)
    assert ui.mode == "terminal" and ui.buttons is None
    with pytest.raises(RuntimeError):
        build_user_interface(UiSettings(mode="hardware"), oled_factory=broken)


def test_ui_factory_hybrid():
    ui = build_user_interface(
        UiSettings(mode="auto"),
        oled_factory=lambda s: RecordingDisplay(),
        buttons_factory=lambda pins: ScriptedButtons([]),
        terminal_input_factory=lambda: ScriptedKeys([]),
        terminal_display_factory=RecordingDisplay,
    )
    assert ui.mode == "hybrid" and isinstance(ui.display, DisplayRouter)


def test_event_bus_isolates_failing_handlers():
    bus, seen = EventBus(), []
    bus.subscribe("t", lambda p: 1 / 0)
    unsubscribe = bus.subscribe("t", seen.append)
    bus.publish("t", 1)
    unsubscribe()
    bus.publish("t", 2)
    assert seen == [1]


class _F(MenuFeature):
    feature_id = "f"
    oled_label = "F"
    terminal_label = "Feature F"
    runs = 0

    def run(self):
        type(self).runs += 1
        raise RuntimeError("boom")


def test_feature_registry_and_menu():
    reg = FeatureRegistry()
    reg.register(_F)
    feats = reg.create(["f", "missing"], context=None)
    assert [f.feature_id for f in feats] == ["f"]
    ui, display, _ = make_ui(buttons=ScriptedButtons([0]))
    MainMenu(ui, feats).run_once()  # failure is contained
    assert _F.runs == 1 and display.messages[-1] == "F\nFailed"


def test_builtin_menu_text_matches_v621():
    from dtp_can.app.features import FEATURES

    feats = FEATURES.create(["ecu_info", "run_tests", "shutdown", "push_reports"], context=None)
    ui, *_ = make_ui()
    assert MainMenu(ui, feats).oled_text() == "1 ECU info\n2 Run TestCases\n3 ShutDown\n4 Push to Bitbucket"


def test_startup_pipeline_defaults_and_validation():
    assert [s.name for s in StartupPipeline(DEFAULT_STARTUP).steps] == DEFAULT_STARTUP
    with pytest.raises(ValueError, match="Unknown startup steps"):
        StartupPipeline(["gpio_cleanup", "nope"])
