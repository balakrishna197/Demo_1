import json
import logging

import pytest

from dtp_can.config.json_loader import load_json
from dtp_can.config.settings import AppSettings, load_settings, resolve_ui_mode
from dtp_can.config.uds_config import UdsConfig
from dtp_can.core.errors import ConfigError


def test_settings_defaults_equal_v621_hardcoded_values(tmp_path):
    s = load_settings(str(tmp_path), environ={})
    assert s.ui.mode == "auto"
    assert (s.ui.display.width, s.ui.display.height, s.ui.display.address) == (128, 64, "0x3C")
    assert s.ui.buttons.pins() == [12, 16, 20, 21]
    assert s.git.repo_url == "git@bitbucket.org:mobase-rnd/dtp-can.git"
    assert s.git.commit_message == "Updated Reports"
    assert s.hardware.boot_config == "/boot/firmware/config.txt"
    assert (s.hardware.can_init.bitrate, s.hardware.can_init.dbitrate) == (1000000, 8000000)
    assert s.hardware.canfd_overlays == [
        "dtoverlay=mcp251xfd, spi0-0, interrupt=25",
        "dtoverlay=mcp251xfd, spi1-0, interrupt=24",
    ]
    assert s.wifi.monitor_interval_s == 10
    assert s.diagnostics.udp_check_retries == 3
    assert s.diagnostics.can_ready_timeout_s == 60
    assert s.diagnostics.min_free_disk_mb == 50
    assert s.service.name == "uds.service"
    assert s.menu == ["ecu_info", "run_tests", "shutdown", "push_reports"]
    assert s.report.app_version == "DTP-CAN Diagnostic Application V6.2.1"


def test_settings_file_and_env_override(tmp_path, caplog):
    (tmp_path / "app_settings.json").write_text(json.dumps({
        "ui": {"mode": "terminal", "buttons": {"enter": 26}},
        "menu": ["run_tests"],
        "bogus": 1,
    }))
    with caplog.at_level(logging.WARNING):
        s = load_settings(str(tmp_path), environ={})
    assert s.ui.mode == "terminal" and s.ui.buttons.enter == 26 and s.ui.buttons.first == 12
    assert s.menu == ["run_tests"]
    assert "Unknown setting ignored: bogus" in caplog.text
    s = load_settings(str(tmp_path), environ={"DTP_UI_MODE": "oled"})
    assert s.ui.mode == "hardware"


def test_settings_invalid_files(tmp_path):
    (tmp_path / "app_settings.json").write_text("{not json")
    with pytest.raises(ConfigError):
        load_settings(str(tmp_path), environ={})
    (tmp_path / "app_settings.json").write_text(json.dumps({"ui": 5}))
    with pytest.raises(ConfigError):
        load_settings(str(tmp_path), environ={})


def test_resolve_ui_mode():
    assert resolve_ui_mode("console") == "terminal"
    assert resolve_ui_mode("OLED") == "hardware"
    assert resolve_ui_mode("weird") == "auto"


def test_default_settings_are_independent():
    a, b = AppSettings(), AppSettings()
    a.menu.append("x")
    assert b.menu == ["ecu_info", "run_tests", "shutdown", "push_reports"]


def test_json_loader(tmp_path):
    (tmp_path / "c.json").write_text('{"a": 1}')
    assert load_json("c.json", base_dir=str(tmp_path)) == {"a": 1}
    with pytest.raises(ConfigError, match="not found"):
        load_json(str(tmp_path / "missing.json"))
    (tmp_path / "bad.json").write_text("{")
    with pytest.raises(ConfigError, match="Invalid JSON"):
        load_json(str(tmp_path / "bad.json"))


def test_uds_config_view(uds_config):
    assert uds_config.target_ecu == "SIM_ECU"
    assert uds_config.allowed_tx_ids == [0x7E0, 0x7DF]
    assert uds_config.allowed_rx_ids == [0x7E8, 0x7E8]
    assert uds_config.default_session == 1 and uds_config.extended_session == 3
    assert uds_config.uds_can_filters() is None
    assert uds_config.step_delay_for("22") == 0.0


def test_uds_config_filters_and_validation(sim_config_dict):
    sim_config_dict["uds"]["logging"]["filters"] = True
    filters = UdsConfig(sim_config_dict).uds_can_filters()
    assert [f["can_id"] for f in filters] == [0x7E0, 0x7E8, 0x7DF, 0x7E8]
    del sim_config_dict["uds"]["isotp"]
    with pytest.raises(ConfigError, match="isotp"):
        UdsConfig(sim_config_dict)
    with pytest.raises(ConfigError):
        UdsConfig({"nope": {}})
