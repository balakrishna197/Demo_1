import os

import pytest

from dtp_can.config.settings import GitSettings, HardwareSettings, ServiceSettings, SshSettings
from dtp_can.core.errors import ConfigError, SessionSetupError
from dtp_can.platform.hardware_setup import CanInterface, HardwareInterfaceSetup
from dtp_can.platform.service_installer import ServiceInstaller
from dtp_can.platform.shell import RecordingRunner
from dtp_can.platform.ssh import SshSetup
from dtp_can.platform.wifi import WifiManager, WifiMonitor
from dtp_can.vcs.branch_catalog import BranchCatalog
from dtp_can.vcs.git_client import GitClient, repo_web_url
from dtp_can.vcs.report_tracker import ReportTracker

LEVELS = ["Employee", "Variant", "Type", "Stage", "Date"]
BRANCHES = [
    "E1/V1/SYS/S1/2025-01-01", "E1/V1/SYS/S2/2025-01-02", "E1/V2/SYS/S1/2025-01-03",
    "E2/V1/REG/S1/2025-02-01", "main", "E3/too/short", "E1/V1/SYS/S1/2025-01-01/extra",
]


def test_branch_catalog_levels():
    cat = BranchCatalog(BRANCHES, LEVELS)
    assert cat.options([]) == ["E1", "E2"]
    assert cat.options(["E1"]) == ["V1", "V2"]
    assert cat.options(["E1", "V1", "SYS"]) == ["S1", "S2"]
    assert cat.options(["E1", "V1", "SYS", "S1"]) == ["2025-01-01"]
    assert cat.require_match(["E1", "V1", "SYS", "S1", "2025-01-01"]) == "E1/V1/SYS/S1/2025-01-01"
    with pytest.raises(SessionSetupError):
        cat.require_match(["E9", "V1", "SYS", "S1", "x"])


def test_git_client_commands(tmp_path):
    runner = RecordingRunner(responses={
        "git ls-remote --heads git@bitbucket.org:org/r.git":
            (0, "a1\trefs/heads/E1/V1/SYS/S1/D\nb2\trefs/heads/main\n", ""),
    })
    git = GitClient("git@bitbucket.org:org/r.git", str(tmp_path), runner)
    assert git.list_remote_branches() == ["E1/V1/SYS/S1/D", "main"]
    path = git.clone("E1/V1/SYS/S1/D")
    assert path == os.path.join(str(tmp_path), "E1_V1_SYS_S1_D")
    git.pull()
    git.add_all()
    git.commit()
    git.push()
    assert runner.calls[-4:] == [
        ["git", "-C", path, "pull", "origin", "E1/V1/SYS/S1/D"],
        ["git", "-C", path, "add", "."],
        ["git", "-C", path, "commit", "-m", "Updated Reports"],
        ["git", "-C", path, "push", "-u", "origin", "E1/V1/SYS/S1/D"],
    ]
    assert git.branch_url("abc") == "https://bitbucket.org/org/r/src/abc/?at=E1/V1/SYS/S1/D"
    assert repo_web_url("git@bitbucket.org:a/b.git") == "https://bitbucket.org/a/b"


def test_report_tracker(tmp_path):
    out, repo = tmp_path / "output", tmp_path / "repo"
    (out / "can_logs").mkdir(parents=True)
    (out / "can_logs" / "old.asc").write_text("old")
    tracker = ReportTracker(str(out))
    tracker.start()
    (out / "can_logs" / "new.asc").write_text("new")
    assert tracker.finish() == [os.path.join("can_logs", "new.asc")]
    assert tracker.copy_to(str(repo)) == 1
    assert (repo / "output" / "can_logs" / "new.asc").read_text() == "new"
    tracker.start()
    tracker.finish()
    with pytest.raises(Exception, match="No new reports"):
        tracker.copy_to(str(repo))


def test_wifi_manager_and_monitor():
    runner = RecordingRunner(responses={
        "nmcli -t -f ACTIVE,SSID device wifi": (0, "no:Other\nyes:Lab\n", ""),
    }, default_stdout="Lab\nLab\nGuest\n")
    wifi = WifiManager(runner)
    assert wifi.scan() == ["Lab", "Guest"]
    wifi.mark_connected("Lab")
    published = []
    monitor = WifiMonitor(wifi, published.append, interval_s=0)
    assert monitor.check_once() == "W+"
    wifi.current_ssid = "Gone"
    runner.responses["nmcli connection up Gone"] = (1, "", "")
    assert monitor.check_once() == "W-"
    assert published == ["W+", "W~", "W-"]
    assert wifi.connect("Lab", "pw") is True
    assert runner.calls[-1] == [
        "nmcli", "--wait", "15", "device", "wifi", "connect", "Lab", "password", "pw"
    ]


def test_wifi_monitor_start_is_idempotent():
    """B-06: a second start() must not spawn a second monitor thread."""
    monitor = WifiMonitor(WifiManager(RecordingRunner()), lambda s: None, interval_s=60)
    monitor.start()
    first = monitor._thread
    monitor.start()
    assert monitor._thread is first
    monitor.stop()


def test_hardware_setup_issues_v621_commands():
    runner = RecordingRunner(responses={
        "grep -q mcp251xfd /boot/firmware/config.txt": (1, "", ""),
        "ip link show can0": (0, "can0: <NOARP,ECHO> state DOWN", ""),
    }, default_returncode=1)
    exits = []
    setup = HardwareInterfaceSetup(HardwareSettings(), runner, path_exists=lambda p: True,
                                   exit_process=exits.append)
    setup.initialize()
    cmds = [c for c in runner.calls if isinstance(c, str)]
    assert (
        "echo 'dtoverlay=mcp251xfd, spi0-0, interrupt=25' | "
        "sudo tee -a /boot/firmware/config.txt > /dev/null"
    ) in cmds
    assert "sudo reboot" in cmds and exits == [0]
    assert ("sudo ip link set can0 up type can bitrate 1000000 dbitrate 8000000 "
            "restart-ms 1000 berr-reporting on fd on") in cmds


def test_can_interface_bringup_uses_test_config_rates():
    runner = RecordingRunner()
    assert CanInterface("can0", runner).bring_up(500000, 2000000, 100)
    assert runner.calls[1] == ["sudo", "ip", "link", "set", "can0", "up", "type", "can", "bitrate",
                               "500000", "dbitrate", "2000000", "restart-ms", "100",
                               "berr-reporting", "on", "fd", "on"]


def _ssh(tmp_path, runner, search=None):
    ssh = SshSettings(
        ssh_dir=str(tmp_path / "ssh"), key_search_paths=search or ["{base_dir}/credentials"]
    )
    return SshSetup(ssh, GitSettings(user_name="Bench", user_email="b@x"), str(tmp_path), runner,
                    prompt=lambda m: "", environ={"SSH_AUTH_SOCK": "x"})


def test_ssh_installs_provisioned_key(tmp_path):
    (tmp_path / "credentials").mkdir()
    (tmp_path / "credentials" / "diagtestpi_bitbucket").write_text("PRIVATE")
    (tmp_path / "credentials" / "diagtestpi_bitbucket.pub").write_text("PUB")
    runner = RecordingRunner()
    path = _ssh(tmp_path, runner).ensure_keys()
    assert open(path).read() == "PRIVATE"
    assert oct(os.stat(path).st_mode & 0o777) == "0o600"


def test_ssh_without_key_fails_with_actionable_error(tmp_path):
    with pytest.raises(ConfigError, match="diagtestpi_bitbucket"):
        _ssh(tmp_path, RecordingRunner()).ensure_keys()


def test_ssh_git_identity_from_settings(tmp_path):
    runner = RecordingRunner()
    _ssh(tmp_path, runner).configure_git_identity()
    assert ["git", "config", "--global", "user.name", "Bench"] in runner.calls


def test_service_unit_text(tmp_path):
    runner = RecordingRunner()
    inst = ServiceInstaller(
        ServiceSettings(), runner, home=str(tmp_path), exe_path="/opt/dtp/uds", uid=os.getuid()
    )
    assert inst.install() is True
    text = (tmp_path / ".config/systemd/user/uds.service").read_text()
    assert "ExecStart=/opt/dtp/uds" in text and "WorkingDirectory=/opt/dtp" in text
    assert inst.install() is False  # unchanged -> not rewritten
