import os

import pytest

from dtp_can.core import hexutil, isotp_frames as tp
from dtp_can.core.did_decoder import decode_special_did_value
from dtp_can.core.models import TestStep, WaitStep
from dtp_can.core.nrc import describe_nrc
from dtp_can.testcases.discovery import find_testcases_and_configs
from dtp_can.testcases.metadata import (
    get_expected_ecu_info_fields,
    get_testcase_author,
    get_testcase_generated_metadata,
)
from dtp_can.testcases.parser import load_testcase_sequence, load_testcases, parse_testcase_file
from tests.conftest import SIM_TESTCASES


# --- hexutil -------------------------------------------------------------------
def test_hex_field_to_bytes():
    assert hexutil.hex_field_to_bytes("0x01,02") == bytes([0x01, 0x02])
    assert hexutil.hex_field_to_bytes("FFF") == bytes([0x0F, 0xFF])
    assert hexutil.hex_field_to_bytes("") == b""
    with pytest.raises(ValueError):
        hexutil.hex_field_to_bytes("XYZ")


def test_split_hex_pairs_is_strict():
    assert hexutil.split_hex_pairs("0xF1 90") == ["F1", "90"]
    assert hexutil.split_hex_pairs("F1F") == []
    assert hexutil.split_hex_pairs("-") == []
    assert hexutil.split_hex_pairs("ZZ") == []


def test_trim_and_padding():
    assert hexutil.trim_trailing([1, 0xAA, 0x00], (0x00, 0xAA)) == [1]
    assert hexutil.remove_trailing_padding(["62", "AA", "aa"], "AA") == ["62"]


def test_did_helpers():
    assert hexutil.looks_like_did("0xF190")
    assert not hexutil.looks_like_did("VIN Number")


# --- ISO-TP helpers -----------------------------------------------------------
def test_isotp_payload_extraction():
    assert tp.extract_payload_tokens(["03", "62", "F1", "90", "AA"]) == ["62", "F1", "90"]
    assert tp.extract_payload_tokens(["10", "09", "62", "F1"]) == ["62", "F1"]
    assert tp.build_display_frame(["3E", "00"]) == ["02", "3E", "00"]
    assert tp.build_display_frame(["00"] * 20)[:2] == ["10", "14"]
    assert tp.is_response_pending([0x7F, 0x22, 0x78])
    assert tp.stmin_to_seconds(10) == 0.01
    assert tp.stmin_to_seconds(0xF5) == pytest.approx(0.0005)
    assert tp.stmin_to_seconds("0x80") == 0.0


def test_nrc_and_did_decoder():
    assert describe_nrc("31") == "requestOutOfRange"
    assert describe_nrc("zz").startswith("Unknown NRC")
    assert decode_special_did_value("ECU Manufacturing Date", ["20", "25", "08", "01"]) == "2025-08-01"
    assert decode_special_did_value("SW Version", [0x41, 0x42, 0x00]) == "AB"


# --- parser --------------------------------------------------------------------
def test_parser_sequence_and_grouping():
    sequence = load_testcase_sequence(SIM_TESTCASES)
    grouped = load_testcases(SIM_TESTCASES)
    steps = [s for s in sequence if isinstance(s, TestStep)]
    waits = [s for s in sequence if isinstance(s, WaitStep)]
    assert len(steps) == 23 and len(waits) == 1
    assert waits[0] == ("WAIT", 0x64)  # tuple compatible, hex milliseconds
    assert list(grouped)[:3] == ["ECU_INFO_1", "ECU_INFO_2", "ECU_INFO_3"]
    assert grouped["TC_002"][-1] == waits[0]  # WAIT attaches to the previous testcase


def test_parser_merges_description_commas_and_lowercases_addressing():
    step = [s for s in load_testcase_sequence(SIM_TESTCASES) if s[0] == "TC_020"][0]
    assert step.description == "Serial, read again"
    assert step.service == "22" and step.subfunction == "F18C"
    assert step.addressing == "physical"
    tc4 = [s for s in load_testcase_sequence(SIM_TESTCASES) if s[0] == "TC_004"][0]
    assert tc4.addressing == "functional"
    assert len(tc4) == 11  # positional compatibility


def test_parser_aliases_and_missing_optional_columns(tmp_path):
    path = tmp_path / "alias.txt"
    path.write_text(
        "TC_ID,Description,SID,DID,Expected,Data,Mode,Format\n"
        "TC_1,Read,22,F190,62 F1 90,,PHYSICAL,Ascii\n"
    )
    step = load_testcase_sequence(str(path))[0]
    assert step.service == "22" and step.addressing == "physical"
    assert step.status_mask == "" and step.control_type == ""


def test_parser_without_header_reports_error(tmp_path, capsys):
    path = tmp_path / "bad.txt"
    path.write_text("nothing,here\n")
    result = parse_testcase_file(str(path))
    assert result.error == "TXT header row not found"
    assert result.grouped == {} and result.sequence == []
    assert "Error parsing testcases" in capsys.readouterr().out


def test_metadata_helpers():
    assert get_testcase_author(SIM_TESTCASES) == "Karan"
    meta = get_testcase_generated_metadata(SIM_TESTCASES)
    assert meta == {"filename": "sim_testcases.txt", "generated_at": "2025-11-10 10:30:00"}
    assert get_expected_ecu_info_fields(SIM_TESTCASES) == [
        "VIN Number", "ECU Serial Number", "ECU Manufacturing Date"
    ]


def test_discovery(tmp_path):
    (tmp_path / ".git").mkdir()
    (tmp_path / ".git" / "x.txt").write_text("ignored")
    (tmp_path / "a.txt").write_text("")
    (tmp_path / "cfg.json").write_text("{}")
    (tmp_path / "git_credentials.json").write_text("{}")
    tcs, cfgs = find_testcases_and_configs(str(tmp_path))
    assert [os.path.basename(p) for p in tcs] == ["a.txt"]
    assert [os.path.basename(p) for p in cfgs] == ["cfg.json"]


def test_workspace_selection(tmp_path):
    from dtp_can.testcases.workspace import TestcaseWorkspace

    ws = TestcaseWorkspace(str(tmp_path / "sf"), str(tmp_path / "sel.txt"))
    with pytest.raises(FileNotFoundError):
        ws.active_testcase()
    ws.install_testcase(SIM_TESTCASES)
    assert ws.active_testcase().endswith("sim_testcases.txt")
    os.remove(tmp_path / "sel.txt")
    assert ws.active_testcase().endswith("sim_testcases.txt")  # first .txt fallback
