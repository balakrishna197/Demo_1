import os

from dtp_can.core.models import TestStep
from dtp_can.reporting.asc_parser import get_request_match_bytes, parse_line
from dtp_can.reporting.matcher import TestcaseMatcher, build_testcase_definitions
from dtp_can.reporting.verdict import get_status
from dtp_can.diagnostics.live_verify import verify_response
from tests.conftest import FIXTURES


def test_get_status_variants():
    assert get_status(["03", "7E", "00", "AA"], ["7E", "00"]) == ("Pass", "")
    assert get_status([], ["7E"]) == ("Fail", "No response received")
    assert get_status(["7E", "00"], []) == ("Fail", "Expected response not specified")
    assert get_status(["7F", "22", "31"], ["62", "F1"]) == (
        "Fail", "Negative Response (0x31: requestOutOfRange)")
    assert get_status(["62", "F1", "90", "41"], ["62", "F1", "90", "42"]) == ("Fail", "Response mismatch")
    assert get_status(["62", "F1", "90"], ["62", "F1", "91"]) == ("Fail", "Empty response data")


def test_parse_asc_line():
    line = (" 1.016396 CANFD   1 Rx        7E8          0 0 8  8 21 31 32 33 34 35 36 37"
            "        0    0     1000        0        0        0        0        0")
    msg = parse_line(line)
    assert msg["can_id"] == "7E8" and msg["direction"] == "Rx"
    assert msg["data_bytes"] == ["21", "31", "32", "33", "34", "35", "36", "37"]
    assert parse_line("date Sun Nov 15") is None


def test_request_match_bytes_keeps_unpadded_extra():
    assert get_request_match_bytes(["02", "3E", "00", "AA", "AA"]) == ["3E", "00"]


def _step(tc, sid, sub, exp=""):
    return TestStep(tc, "d", sid, sub, exp, "", "physical", "Hex", "", "", "")


def test_matcher_exact_then_dynamic_security_key():
    defs = build_testcase_definitions([_step("A", "22", "F18B"), _step("B", "22", "F18C"),
                                       _step("C", "27", "02")])
    matcher = TestcaseMatcher(defs)
    assert matcher.match(["22", "F1", "8C"]).tc_id == "B"
    assert matcher.match(["22", "F1"]) is None           # no partial prefix matches
    assert matcher.match(["27", "02", "AB", "CD"]).tc_id == "C"  # key bytes are dynamic
    assert matcher.has_matched_payload(["22", "F1", "8C"])


def test_live_verify_rules():
    assert verify_response([0x50, 0x01], [0x50, 0x01], "T", "d")[0] == "Pass"
    assert verify_response([0x7F, 0x10, 0x12], [0x7F], "T", "d")[0] == "Pass"
    assert verify_response([0x7F, 0x10, 0x12], [0x7F, 0x10, 0x13], "T", "d") == (
        "Fail", "Expected NRC 0x13, got 0x12")
    assert verify_response([], [0x50], "T", "d") == ("Fail", "No response received")


def test_incomplete_multiframe_followed_by_single_frame_does_not_crash():
    """B-04: V6.2.1 raised AttributeError (finalize_message(None, ...)) here."""
    from dtp_can.reporting.asc_parser import parse_asc_log

    asc = os.path.join(FIXTURES, "incomplete_multiframe.asc")
    steps = [_step("A", "22", "F190", "62 F1 90"), _step("B", "3E", "00", "7E 00")]
    messages, _start, _end = parse_asc_log(asc, [0x7E0], [0x7E8], steps)
    a = messages["A__occurrence_1"][0]
    assert a["status"] == "Fail" and a["failure_reason"].startswith("Incomplete multi-frame response")
    assert messages["B__occurrence_1"][0]["status"] == "Pass"
