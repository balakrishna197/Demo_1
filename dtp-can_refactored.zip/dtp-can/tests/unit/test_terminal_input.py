"""Terminal key decoding on a real pseudo-terminal (regression for B-08)."""

import os

import pytest

from dtp_can.ui.terminal import TerminalInput

pytestmark = pytest.mark.skipif(not hasattr(os, "openpty"), reason="needs a POSIX pty")


@pytest.fixture
def pty_input():
    master, slave = os.openpty()
    slave_file = os.fdopen(slave, "r")
    term = TerminalInput(stdin=slave_file)
    assert term.is_available()
    yield term, master
    term.restore()
    slave_file.close()
    os.close(master)


def test_escape_sequences_and_burst_input(pty_input):
    term, master = pty_input
    os.write(master, b"\x1b[A\x1b[Bab\x7f\r")
    keys = [term.read_key(timeout=1) for _ in range(6)]
    assert keys == ["UP", "DOWN", "a", "b", "BACKSPACE", "ENTER"]
    assert term.read_key(timeout=0.05) is None


def test_poll_action_mapping(pty_input):
    term, master = pty_input
    os.write(master, b"\x1b[Ds7q")
    assert [term.poll_action(timeout=1) for _ in range(4)] == ["prev", "select", ("digit", 7), "cancel"]


def test_utf8_input(pty_input):
    term, master = pty_input
    os.write(master, "é".encode())
    assert term.read_key(timeout=1) == "é"
