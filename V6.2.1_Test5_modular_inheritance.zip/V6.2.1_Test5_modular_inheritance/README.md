# V6.2.1 Test5 - Modular / SOLID-oriented structure

## Structure

```text
V6.2.1_Test5_modular_inheritance/
├── main.py
├── build_on_pi.sh
└── drivers/
    ├── __init__.py              # only package initializer
    ├── git_handler.py           # Git + repository workflow
    ├── testcase_handler.py      # testcase parsing/loading + handler abstraction
    ├── input_handler.py         # USB + local input-file handling
    ├── config_handler.py        # configuration loading
    ├── diagnostic_handler.py    # UDS diagnostic client
    ├── did_handler.py           # DID decoding
    ├── report_handler.py        # report generation
    ├── can_handler.py           # CAN logging
    ├── ui_handler.py            # OLED + terminal + button UI
    ├── network_handler.py       # Wi-Fi handling
    └── system_handler.py        # Pi interfaces + SSH + service
```

There are no nested Python packages. Only `drivers/__init__.py` is used as the package initializer.

## Design

Each functional area has one owning module. Replaceable behavior is expressed through a small base class/contract and the concrete implementation inherits from it. The application composes these handlers instead of making handlers depend on `UDSApp`.

Examples:

- `RepositoryHandler -> GitManager`
- `ConfigurationHandler -> JsonConfigurationHandler`
- `TestCaseHandler -> TextTestCaseHandler`
- `InputFileHandler -> USBTransfer`
- `DiagnosticClient -> UDSClient`
- `ReportHandler -> HTMLReportHandler`
- `CANLoggerBase -> CANLogger`
- `SystemHandler -> RaspberryPiSystemHandler`

`main.py` is the composition/orchestration layer.

## Change isolation

- Git changes: `drivers/git_handler.py`
- Testcase input/sequence changes: `drivers/testcase_handler.py`
- USB/local file changes: `drivers/input_handler.py`
- JSON configuration changes: `drivers/config_handler.py`
- UDS behavior: `drivers/diagnostic_handler.py`
- DID decoding: `drivers/did_handler.py`
- Report behavior: `drivers/report_handler.py`
- CAN logging: `drivers/can_handler.py`
- UI behavior: `drivers/ui_handler.py`
- Wi-Fi behavior: `drivers/network_handler.py`
- Raspberry Pi/SSH/service behavior: `drivers/system_handler.py`

The proven parsing, UDS and report algorithms were retained rather than rewritten, reducing functional regression risk.
