"""User-interface implementations and reusable selection/input behavior."""

from abc import ABC, abstractmethod
import os
import time
import logging
from typing import Callable

try:
    import board  # type: ignore[import-not-found]
    import busio  # type: ignore[import-not-found]
    import adafruit_ssd1306  # type: ignore[import-not-found]
    from PIL import Image, ImageDraw, ImageFont  # type: ignore[import-not-found]
except ImportError:
    board = None
    busio = None
    adafruit_ssd1306 = None
    Image = None
    ImageDraw = None
    ImageFont = None

try:
    import RPi.GPIO as GPIO  # type: ignore[import-not-found]
except ImportError:
    GPIO = None


class OLEDDisplay:

    def __init__(self, config):
        if any(item is None for item in (board, busio, adafruit_ssd1306, Image, ImageDraw, ImageFont)):
            raise RuntimeError("OLED hardware dependencies are not available")
        self.i2c = busio.I2C(board.SCL, board.SDA)
        self.display = adafruit_ssd1306.SSD1306_I2C(
            config['width'], config['height'], self.i2c
        )
        self.width = self.display.width
        self.height = self.display.height
        self.image = Image.new("1", (self.width, self.height))
        self.draw = ImageDraw.Draw(self.image)
        self.font = ImageFont.load_default()
        self.wifi_status = "W-"

        self.clear()
        self.draw_status_bar()
        self.display.image(self.image)
        self.display.show()

    def set_wifi_status(self, status):
        self.wifi_status = status

    def draw_status_bar(self):
        self.draw.text(
            (100, 0),
            self.wifi_status,
            font=self.font,
            fill=255
        )

    def clear(self):
        self.draw.rectangle(
            (0, 0, self.width, self.height),
            outline=0,
            fill=0
        )

    def display_text(self, text, line=10):
        self.clear()
        self.draw_status_bar()
        self.draw.text(
            (0, line),
            text,
            font=self.font,
            fill=255
        )
        self.display.image(self.image)
        self.display.show()

    def display_centered_text(self, text):
        self.clear()
        self.draw_status_bar()
        lines = text.split('\n')

        line_height = self.draw.textbbox((0, 0), "A", font=self.font)[3]
        total_text_height = line_height * len(lines)
        y_offset = ((self.height - 8) - total_text_height) // 2 + 8

        for i, line in enumerate(lines):
            bbox = self.draw.textbbox((0, 0), line, font=self.font)
            line_width = bbox[2] - bbox[0]
            x = (self.width - line_width) // 2
            y = y_offset + i * line_height
            self.draw.text((x, y), line, font=self.font, fill=255)

        self.display.image(self.image)
        self.display.show()


import atexit
import getpass
import select
import sys

try:
    import termios
    import tty
except ImportError:
    termios = None
    tty = None


class TerminalDisplay:
    def __init__(self):
        self.wifi_status = "W-"
        self._last_rendered_output = None

    def set_wifi_status(self, status):
        self.wifi_status = status

    def clear(self):
        self._last_rendered_output = None
        # Clear terminal and move cursor to top-left.
        print("\033[2J\033[H", end="")

    def display_text(self, text, line=0):
        del line
        self.display_centered_text(text)

    def display_centered_text(self, text):
        rendered_output = f"[WiFi: {self.wifi_status}]\n{text}"
        if rendered_output == self._last_rendered_output:
            return
        self._last_rendered_output = rendered_output
        print("\033[2J\033[H", end="")
        print(rendered_output)


class DisplayRouter:
    def __init__(self, *displays):
        self.displays = [
            display for display in displays if display is not None
        ]

    def set_wifi_status(self, status):
        for display in self.displays:
            display.set_wifi_status(status)

    def clear(self):
        for display in self.displays:
            display.clear()

    def display_text(self, text, line=0):
        for display in self.displays:
            display.display_text(text, line=line)

    def display_centered_text(self, text):
        for display in self.displays:
            display.display_centered_text(text)


class TerminalInput:
    def __init__(self):
        self.stdin = sys.stdin
        self.enabled = False
        self._original_termios = None
        self._line_buffer = ""
        self._setup_terminal()

    def _setup_terminal(self):
        if termios is None or tty is None:
            return
        if not self.stdin.isatty():
            return
        try:
            tcgetattr = getattr(termios, "tcgetattr", None)
            setcbreak = getattr(tty, "setcbreak", None)
            if tcgetattr is None or not callable(setcbreak):
                return
            self._original_termios = tcgetattr(self.stdin.fileno())
            setcbreak(self.stdin.fileno())
            atexit.register(self.restore)
            self.enabled = True
        except Exception:
            self.enabled = False

    def restore(self):
        if not self.enabled or self._original_termios is None:
            return
        try:
            if termios is None:
                return
            tcsetattr = getattr(termios, "tcsetattr", None)
            tcsadrain = getattr(termios, "TCSADRAIN", None)
            if not callable(tcsetattr) or tcsadrain is None:
                return
            tcsetattr(
                self.stdin.fileno(),
                tcsadrain,
                self._original_termios
            )
        except Exception:
            pass

    def is_available(self):
        return self.enabled

    def _read_char(self, timeout: float = 0):
        if not self.enabled:
            return None
        readable, _, _ = select.select([self.stdin], [], [], timeout)
        if not readable:
            return None
        return self.stdin.read(1)

    def read_key(self, timeout: float = 0):
        char = self._read_char(timeout=timeout)
        if char is None:
            return None

        if char == "\x1b":
            next_char = self._read_char(timeout=0.01)
            if next_char == "[":
                arrow = self._read_char(timeout=0.01)
                if not isinstance(arrow, str):
                    return "ESC"
                return {
                    "A": "UP",
                    "B": "DOWN",
                    "C": "RIGHT",
                    "D": "LEFT"
                }.get(arrow, "ESC")
            return "ESC"

        if char in ("\r", "\n"):
            return "ENTER"
        if char in ("\x08", "\x7f"):
            return "BACKSPACE"
        if char == "\t":
            return "TAB"
        if char == " ":
            return "SPACE"
        return char

    def poll_action(self, timeout=0.1):
        key = self.read_key(timeout=timeout)
        if key is None:
            return None
        if key in {"LEFT", "UP", "a", "A", "p", "P"}:
            return "prev"
        if key in {"RIGHT", "DOWN", "d", "D", "n", "N"}:
            return "next"
        if key in {"ENTER", "s", "S"}:
            return "select"
        if key in {"ESC", "q", "Q"}:
            return "cancel"
        if isinstance(key, str) and key.isdigit():
            return ("digit", int(key))
        return None

    def prompt_password(self, ssid):
        self.restore()
        try:
            return getpass.getpass(f"Enter password for '{ssid}': ")
        finally:
            self._setup_terminal()


import time


class ButtonInput:
    def __init__(self, pins):
        if GPIO is None:
            raise RuntimeError("RPi.GPIO is not available")
        self.pins = pins
        GPIO.setmode(GPIO.BCM)
        for pin in self.pins:
            GPIO.setup(pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)

    def wait_for_press(self):
        while True:
            for i, pin in enumerate(self.pins):
                if GPIO.input(pin) == GPIO.LOW:
                    time.sleep(0.2)
                    return i

    def get_pressed_nonblocking(self):
        for idx, pin in enumerate(self.pins):
            if GPIO.input(pin) == GPIO.LOW:
                return idx
        return None


class DisplayInterface(ABC):
    @abstractmethod
    def display_centered_text(self, text):
        raise NotImplementedError

    @abstractmethod
    def clear(self):
        raise NotImplementedError


class UIHandler:
    """Coordinates hardware/terminal UI and owns reusable input selection."""

    def __init__(self, ui_mode="auto", display_config=None):
        self.ui_mode = ui_mode
        self.display_config = display_config or {"width": 128, "height": 64, "address": "0x3C"}
        self.hardware_display = None
        self.buttons = None
        self.terminal_input = None
        self.terminal_display = None
        self.oled = None
        self.btn_map = {}
        self.initialize()

    def initialize(self):
        self.hardware_display = None
        self.buttons = None
        if self.ui_mode in {"hardware", "auto"}:
            try:
                self.hardware_display = OLEDDisplay(self.display_config)
                self.btn_map = {"first": 12, "second": 16, "enter": 20, "power": 21}
                self.buttons = ButtonInput(list(self.btn_map.values()))
            except Exception as exc:
                if self.ui_mode == "hardware":
                    raise
                logging.warning("Hardware UI unavailable, using terminal UI: %s", exc)

        if self.ui_mode in {"terminal", "auto"}:
            candidate = TerminalInput()
            if candidate.is_available() or self.ui_mode == "terminal":
                self.terminal_input = candidate
                self.terminal_display = TerminalDisplay()

        if self.hardware_display and self.terminal_display:
            self.oled = DisplayRouter(self.hardware_display, self.terminal_display)
            self.ui_mode = "hybrid"
        elif self.hardware_display:
            self.oled = self.hardware_display
            self.ui_mode = "hardware"
        else:
            self.oled = self.terminal_display or TerminalDisplay()
            self.ui_mode = "terminal"

    def has_terminal_input(self):
        return self.terminal_input is not None and self.terminal_input.is_available()

    def has_hardware_input(self):
        return self.buttons is not None

    def poll_combined_action(self, options_count=None, allow_cancel=False, timeout=0.1):
        if self.buttons is not None:
            button = self.buttons.get_pressed_nonblocking()
            if button == 0: return "prev"
            if button == 1: return "next"
            if button == 2: return "select"
            if button == 3 and allow_cancel: return "cancel"
        if self.terminal_input is not None and self.terminal_input.is_available():
            action = self.terminal_input.poll_action(timeout=timeout)
            if isinstance(action, tuple) and action[0] == "digit":
                digit = action[1]
                if options_count and 1 <= digit <= options_count:
                    return ("index", digit - 1)
                return None
            if action == "cancel" and not allow_cancel:
                return None
            return action
        if self.has_hardware_input():
            time.sleep(timeout)
        return None

    def select_from_list(self, title, items, formatter: Callable = str, allow_cancel=False):
        if not items:
            return None
        index = 0
        last_displayed_index = None
        while True:
            if index != last_displayed_index:
                label = formatter(items[index])
                if self.hardware_display is not None:
                    self.hardware_display.display_centered_text(f"{title}\n\n{label}")
                if self.has_terminal_input():
                    os.system("clear")
                    print("=" * 50)
                    print(f"Select {title}")
                    print("=" * 50)
                    for i, item in enumerate(items):
                        print(f"{">" if i == index else " "} {i + 1}. {formatter(item)}")
                    print("\nControls:")
                    print("A / P      : Previous")
                    print("D / N      : Next")
                    print("S / Enter  : Select")
                    if allow_cancel: print("Q          : Cancel")
                    print("1-9        : Direct Selection")
                last_displayed_index = index
            action = self.poll_combined_action(min(len(items), 9), allow_cancel, 0.15)
            if action == "prev": index = (index - 1) % len(items)
            elif action == "next": index = (index + 1) % len(items)
            elif action == "select": return index
            elif action == "cancel": return None
            elif isinstance(action, tuple) and action[0] == "index" and 0 <= action[1] < len(items): return action[1]

    def enter_text(self, title, default_text=""):
        if self.has_terminal_input():
            self.terminal_input.restore()
            try:
                value = input(f"{title}: ")
            finally:
                self.terminal_input._setup_terminal()
            return value.strip()
        # Reuse the original keypad-style behavior for hardware-only mode.
        chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 ._- >"
        value = default_text or ""
        index = 0
        while True:
            current = chars[index]
            if self.hardware_display:
                self.hardware_display.display_centered_text(f"{title}\n{value[-14:] or '<empty>'}\n\n[{current}]")
            if self.buttons is not None:
                button = self.buttons.get_pressed_nonblocking()
                if button == 0: index = (index + 1) % len(chars)
                elif button == 1: index = (index - 1) % len(chars)
                elif button == 2:
                    if current == ">": return value.strip()
                    value += current
                elif button == 3: return value.strip()
            time.sleep(0.15)

    def show_text(self, text):
        self.oled.clear()
        self.oled.display_text(text)


def _ui_poll_main_menu_selection(self):
    while True:
        if self.buttons is not None:
            button = self.buttons.get_pressed_nonblocking()
            if button == 0: return "1"
            if button == 1: return "2"
            if button == 2: return "3"
            if button == 3: return "4"
        if self.terminal_input is not None and self.terminal_input.is_available():
            action = self.terminal_input.poll_action(timeout=0.15)
            if isinstance(action, tuple) and action[0] == "digit" and 1 <= action[1] <= 4:
                return str(action[1])
        else:
            time.sleep(0.15)

UIHandler.poll_main_menu_selection = _ui_poll_main_menu_selection
