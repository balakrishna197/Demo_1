"""Flat driver layer for the DTP-CAN diagnostics application."""
