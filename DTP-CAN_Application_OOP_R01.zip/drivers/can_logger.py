import logging
import os
from datetime import datetime

import can
from can.io.asc import ASCWriter


class CANLogger:
    """Capture raw CAN/CAN-FD traffic into a Vector-compatible ASC file."""

    def __init__(
        self,
        channel="can0",
        interface="socketcan",
        can_fd=True,
        filters=None,
        log_dir=None,
    ):
        self.channel = channel
        self.interface = interface
        self.can_fd = can_fd
        self.log_dir = log_dir or os.getcwd()
        self.filters = filters

        self.bus = None
        self.notifier = None
        self.writer = None
        self.file = None
        self.log_path = None

    def _open_bus(self):
        """Open a dedicated receive bus for the ASC logger.

        receive_own_messages=True is important for SocketCAN because the
        logger must capture tester Tx frames as well as ECU Rx frames.
        """
        bus_kwargs = {
            "channel": self.channel,
            "bustype": self.interface,
            "can_filters": self.filters,
            "fd": self.can_fd,
        }

        try:
            return can.interface.Bus(**bus_kwargs, receive_own_messages=True)
        except TypeError:
            logging.warning(
                "[CANLogger] Backend does not support receive_own_messages; "
                "falling back to default bus creation"
            )
            return can.interface.Bus(**bus_kwargs)

    def start(self, filename=None):
        """Start raw CAN capture using python-can ASCWriter.

        ASCWriter generates the Vector-style header, trigger block, timestamps,
        Tx/Rx frames and End TriggerBlock. No Python logging text is written
        into the ASC file.
        """
        if self.notifier or self.writer or self.bus or self.file:
            self.stop()

        os.makedirs(self.log_dir, exist_ok=True)

        if filename:
            self.log_path = os.path.join(self.log_dir, filename)
        else:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            self.log_path = os.path.join(self.log_dir, f"can_log_{timestamp}.asc")

        try:
            # ASCWriter owns the Vector ASC header/footer generation.
            self.file = open(
                self.log_path,
                "w",
                buffering=1,
                encoding="utf-8",
                newline="",
            )

            self.bus = self._open_bus()
            self.writer = ASCWriter(self.file)
            self.notifier = can.Notifier(self.bus, [self.writer])

            logging.info("CAN ASC logging started: %s", self.log_path)
            logging.info("CAN ASC filters: %s", self.filters if self.filters else "ALL")

        except Exception:
            logging.exception("[CANLogger] Failed to start CAN ASC logging")
            self._cleanup_resources()
            raise

    def stop(self):
        """Stop capture and let ASCWriter finalize the trigger block."""
        path = self.log_path
        try:
            # Stop the notifier first so no new messages are dispatched while
            # the ASCWriter is being finalized.
            if self.notifier is not None:
                self.notifier.stop()
                self.notifier = None

            if self.writer is not None:
                self.writer.stop()
                self.writer = None

            if self.file is not None:
                self.file.flush()
                os.fsync(self.file.fileno())
                self.file.close()
                self.file = None

            if self.bus is not None:
                try:
                    self.bus.shutdown()
                except Exception as exc:
                    logging.warning("[CANLogger] Bus shutdown warning: %s", exc)
                self.bus = None

            if path:
                logging.info("CAN ASC logging stopped: %s", path)
                print(f"[CANLogger] Log file saved to: {path}")

        except Exception:
            logging.exception("[CANLogger] Error during stop")
            self._cleanup_resources()

    def _cleanup_resources(self):
        if self.notifier is not None:
            try:
                self.notifier.stop()
            except Exception:
                pass
            self.notifier = None

        if self.writer is not None:
            try:
                self.writer.stop()
            except Exception:
                pass
            self.writer = None

        if self.file is not None:
            try:
                self.file.close()
            except Exception:
                pass
            self.file = None

        if self.bus is not None:
            try:
                self.bus.shutdown()
            except Exception:
                pass
            self.bus = None

    def get_log_path(self):
        return self.log_path
