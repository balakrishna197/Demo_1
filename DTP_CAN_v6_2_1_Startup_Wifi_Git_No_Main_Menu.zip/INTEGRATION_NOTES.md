# DTP-CAN v6.2.1 Path/Configuration Integration

Integrated changes:
- `main.py` now uses `AppPaths` and `ConfigLoader` instead of resolving `config.json` from the current working directory.
- Added `drivers/config/paths.py`.
- Updated `drivers/config/loader.py` to resolve configuration through `AppPaths`.
- Updated `drivers/config/__init__.py` exports.
- Kept `drivers/config/` in its existing location.
- Kept `main.py` as the application entry point.
- `main_updated.py` is included as a reference copy of the integrated `main.py`; it is not used as a second entry point.
- Output directories are created under the project/application root.
- Source execution resolves from the project root.
- PyInstaller one-file execution resolves from the executable location; when the executable is in `dist/`, the project root is its parent.
- A missing configuration now produces an explicit message showing the expected path.

Expected configuration location:
`drivers/config/config.json`

The supplied scaffold did not contain a config.json, so no configuration content was invented or changed.
