"""Absolute runtime paths for DTP-CAN v6.2.1.

The configuration file is intentionally resolved to an absolute path.  The
build script supplies DTP_CAN_CONFIG_PATH so a PyInstaller executable does
not depend on its current working directory.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


class AppPaths:
    """Centralized absolute path handling for the application."""

    CONFIG_FILENAME = "config.json"
    CONFIG_ENV_VAR = "DTP_CAN_CONFIG_PATH"

    def __init__(self, base_dir: str | Path | None = None) -> None:
        self.base_dir = self._detect_base_dir(base_dir)

        configured_path = os.environ.get(self.CONFIG_ENV_VAR)
        if configured_path:
            self.config_file = Path(configured_path).expanduser().resolve()
        else:
            self.config_file = (
                self.base_dir / "drivers" / "config" / self.CONFIG_FILENAME
            ).resolve()

        self.config_dir = self.config_file.parent
        self.output_dir = (self.base_dir / "output").resolve()
        self.html_reports_dir = (self.output_dir / "html_reports").resolve()
        self.can_logs_dir = (self.output_dir / "can_logs").resolve()
        self.logs_dir = (self.output_dir / "logs").resolve()

    @staticmethod
    def _detect_base_dir(base_dir: str | Path | None) -> Path:
        if base_dir is not None:
            return Path(base_dir).expanduser().resolve()

        if getattr(sys, "frozen", False):
            executable_dir = Path(sys.executable).resolve().parent
            if executable_dir.name.lower() == "dist":
                return executable_dir.parent
            return executable_dir

        # paths.py -> config -> drivers -> project root
        return Path(__file__).resolve().parents[2]

    def resolve_config(self, path: str | Path | None = None) -> Path:
        """Return an absolute configuration path and validate it."""
        if path is None:
            candidate = self.config_file
        else:
            requested = Path(path).expanduser()
            candidate = (
                requested.resolve()
                if requested.is_absolute()
                else (self.config_dir / requested).resolve()
            )

        if not candidate.is_file():
            raise FileNotFoundError(
                "DTP-CAN configuration file not found.\n"
                f"ABSOLUTE CONFIGURATION PATH: {candidate}\n"
                f"Environment variable: {self.CONFIG_ENV_VAR}"
            )

        return candidate

    def ensure_output_dirs(self) -> None:
        for directory in (
            self.output_dir,
            self.html_reports_dir,
            self.can_logs_dir,
            self.logs_dir,
        ):
            directory.mkdir(parents=True, exist_ok=True)
