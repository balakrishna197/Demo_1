"""DTP-CAN v6.2.1 modular driver package.

The package exposes only package-level metadata.  Individual modules remain
responsible for their own infrastructure concerns.
"""

__version__ = "6.2.1"
