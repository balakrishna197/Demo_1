"""Startup workflow for the DTP-CAN application.

This module contains only the interactive startup steps that are required
before diagnostics: Wi-Fi selection and Git branch selection.  The diagnostic
main menu is intentionally NOT started here.
"""

from __future__ import annotations

from dataclasses import dataclass

from drivers.config.models import AppConfig
from drivers.network.wifi import WiFiManager, WifiNetwork
from drivers.repository.git import GitRepository, RepositorySelection
from drivers.ui.terminal import TerminalUI


@dataclass(frozen=True)
class StartupResult:
    wifi_ssid: str | None
    branch: str | None
    commit: str | None


class StartupCoordinator:
    """Run only the mandatory startup selections.

    The coordinator deliberately does not invoke a diagnostic/main menu.
    """

    def __init__(
        self,
        ui: TerminalUI,
        wifi: WiFiManager,
        git: GitRepository,
        config: AppConfig,
    ) -> None:
        self.ui = ui
        self.wifi = wifi
        self.git = git
        self.config = config

    def run(self) -> StartupResult:
        ssid = self._select_wifi() if self.config.network.wifi_enabled else None
        branch = self._select_git_branch()
        commit = self.git.current_commit()

        self.ui.show("")
        self.ui.show("Startup selection completed.")
        if ssid:
            self.ui.show(f"Wi-Fi: {ssid}")
        if branch:
            self.ui.show(f"Git branch: {branch}")
        if commit:
            self.ui.show(f"Git commit: {commit}")
        self.ui.show("Diagnostic main menu is intentionally not started.")

        return StartupResult(ssid, branch, commit)

    def _select_wifi(self) -> str | None:
        self.ui.show("\n=== Wi-Fi Selection ===")

        networks = self.wifi.scan()
        if not networks:
            self.ui.error("No Wi-Fi networks found.")
            return None

        for index, network in enumerate(networks, start=1):
            marker = " (saved)" if network.ssid == self.config.network.saved_ssid else ""
            self.ui.show(f"{index}. {network.ssid}{marker}")

        selection = self._read_number("Select Wi-Fi network number: ", len(networks))
        selected = networks[selection - 1]

        if self.wifi.is_connected(selected.ssid):
            self.ui.show(f"Already connected to: {selected.ssid}")
            return selected.ssid

        if selected.ssid == self.config.network.saved_ssid:
            if self.wifi.connect_saved(selected.ssid):
                self.ui.show(f"Connected to: {selected.ssid}")
                return selected.ssid

        password = input(f"Enter Wi-Fi password for '{selected.ssid}': ")
        if not self.wifi.connect(selected.ssid, password):
            raise RuntimeError(f"Failed to connect to Wi-Fi: {selected.ssid}")

        self.ui.show(f"Connected to: {selected.ssid}")
        return selected.ssid

    def _select_git_branch(self) -> str | None:
        self.ui.show("\n=== Git Branch Selection ===")

        branches = self.git.list_remote_branches()
        if not branches:
            self.ui.error("No remote Git branches found.")
            return None

        for index, branch in enumerate(branches, start=1):
            self.ui.show(f"{index}. {branch}")

        selection = self._read_number("Select Git branch number: ", len(branches))
        selected = branches[selection - 1]
        self.git.checkout_branch(selected)
        self.ui.show(f"Selected Git branch: {selected}")
        return selected

    @staticmethod
    def _read_number(prompt: str, maximum: int) -> int:
        while True:
            try:
                value = int(input(prompt).strip())
            except ValueError:
                print("Please enter a valid number.")
                continue
            if 1 <= value <= maximum:
                return value
            print(f"Please enter a number from 1 to {maximum}.")
