#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="$PROJECT_DIR/dist/uds_diagnostics"
CONFIG_PATH="$PROJECT_DIR/drivers/config/config.json"

if [[ ! -f "$CONFIG_PATH" ]]; then
    echo "Configuration file not found: $CONFIG_PATH" >&2
    exit 1
fi

export DTP_CAN_CONFIG_PATH="$CONFIG_PATH"

if [[ ! -x "$APP" ]]; then
    echo "Executable not found: $APP"
    echo "Run ./build_on_pi.sh first."
    exit 1
fi

exec "$APP" "$@"
