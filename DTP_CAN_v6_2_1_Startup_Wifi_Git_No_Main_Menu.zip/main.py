"""DTP-CAN v6.2.1 modular application composition root.

Startup behavior:
    1. Load the configuration from the absolute drivers/config/config.json path.
    2. Allow the operator to select/connect to Wi-Fi.
    3. Allow the operator to select the Git branch.
    4. Stop after startup selection.

The diagnostic/main menu is intentionally NOT started by this executable.
"""

from __future__ import annotations

from drivers.application.application import Application
from drivers.application.startup import StartupCoordinator
from drivers.config.loader import ConfigLoader
from drivers.config.paths import AppPaths
from drivers.network.wifi import WiFiManager
from drivers.network.udp_client import UdpSeedKeyClient
from drivers.network.connectivity import ConnectivityService
from drivers.repository.git import GitRepository
from drivers.testcase.parser import TestcaseParser
from drivers.diagnostic.executor import TestcaseExecutor
from drivers.diagnostic.verifier import DefaultResponseVerifier
from drivers.diagnostic.udsoncan_transport import UdsoncanTransport
from drivers.reporting.asc_parser import AscParser
from drivers.reporting.report_manager import ReportManager, HtmlReportRenderer
from drivers.ui.terminal import TerminalUI


def build_application(config: object, project_dir: str) -> tuple[Application, StartupCoordinator]:
    """Construct the application and the startup-only workflow."""
    ui = TerminalUI()

    wifi = WiFiManager()
    udp = None
    if config.network.udp_ip and config.network.udp_port:
        udp = UdpSeedKeyClient(
            config.network.udp_ip,
            config.network.udp_port,
            config.network.udp_timeout,
            config.network.expected_key_length,
        )

    network = ConnectivityService(wifi, udp)
    transport = UdsoncanTransport(
        config.raw.get("can", {}),
        config.raw.get("uds", {}).get("isotp", {}),
        config.raw.get("uds", {}).get("addressing", {}),
    )
    diagnostic = TestcaseExecutor(transport, DefaultResponseVerifier())
    reporting = ReportManager(AscParser(), HtmlReportRenderer())

    app = Application(
        ui=ui,
        network=network,
        repository=None,
        testcase_repo=TestcaseParser(),
        diagnostic=diagnostic,
        reporting=reporting,
    )

    git = GitRepository(project_dir)
    startup = StartupCoordinator(ui, wifi, git, config)
    return app, startup


def main(config_path: str | None = None) -> Application:
    """Run Wi-Fi/Git startup selection only; do not start the main menu."""
    print("DTP-CAN v6.2.1 - modular application")

    paths = AppPaths()
    paths.ensure_output_dirs()

    config = ConfigLoader(paths).load(config_path)
    app, startup = build_application(config, str(paths.base_dir))
    startup.run()
    return app


if __name__ == "__main__":
    main()
