"""DTP-CAN v6.2.1 modular composition root.

The composition root remains at the project root.  Runtime paths are resolved
through drivers.config.paths so the application works independently of the
shell's current working directory.
"""

from __future__ import annotations

from drivers.application.application import Application
from drivers.config.loader import ConfigLoader
from drivers.config.paths import AppPaths
from drivers.network.wifi import WiFiManager
from drivers.network.udp_client import UdpSeedKeyClient
from drivers.network.connectivity import ConnectivityService
from drivers.testcase.parser import TestcaseParser
from drivers.diagnostic.executor import TestcaseExecutor
from drivers.diagnostic.verifier import DefaultResponseVerifier
from drivers.diagnostic.udsoncan_transport import UdsoncanTransport
from drivers.reporting.asc_parser import AscParser
from drivers.reporting.report_manager import ReportManager, HtmlReportRenderer
from drivers.ui.terminal import TerminalUI


def build_application(config: object) -> Application:
    """Composition root: construct concrete adapters and inject them."""
    ui = TerminalUI()

    wifi = WiFiManager()
    udp = None

    if config.network.udp_ip and config.network.udp_port:
        udp = UdpSeedKeyClient(
            config.network.udp_ip,
            config.network.udp_port,
            config.network.udp_timeout,
            config.network.expected_key_length,
        )

    network = ConnectivityService(wifi, udp)

    transport = UdsoncanTransport(
        config.raw.get("can", {}),
        config.raw.get("uds", {}).get("isotp", {}),
        config.raw.get("uds", {}).get("addressing", {}),
    )

    diagnostic = TestcaseExecutor(
        transport,
        DefaultResponseVerifier(),
    )

    reporting = ReportManager(
        AscParser(),
        HtmlReportRenderer(),
    )

    return Application(
        ui=ui,
        network=network,
        repository=None,
        testcase_repo=TestcaseParser(),
        diagnostic=diagnostic,
        reporting=reporting,
    )


def main(config_path: str | None = None) -> Application:
    """Load configuration and construct the application.

    ``config_path`` may be an absolute path.  If omitted, config.json is
    resolved from drivers/config/ rather than from the shell's CWD.
    """
    print("DTP-CAN v6.2.1 - modular application")

    paths = AppPaths()
    paths.ensure_output_dirs()

    config = ConfigLoader(paths).load(config_path)
    app = build_application(config)
    return app


if __name__ == "__main__":
    main()
