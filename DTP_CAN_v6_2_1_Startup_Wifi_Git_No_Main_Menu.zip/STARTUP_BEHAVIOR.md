# DTP-CAN v6.2.1 Startup Behavior Fix

## Required runtime behavior

The generated `uds_diagnostics` executable now performs only these startup steps:

1. Loads `drivers/config/config.json` using the absolute configuration path embedded by `build_on_pi.sh`.
2. Displays available Wi-Fi networks and allows the operator to select/connect to one.
3. Displays remote Git branches and allows the operator to select one.
4. Checks out the selected Git branch.
5. Displays the selected branch and commit.
6. Stops.

The diagnostic/main menu is **not started** by `main.py`.

## Run

```bash
chmod +x build_on_pi.sh run_on_pi.sh build_and_run.sh
./build_on_pi.sh
./run_on_pi.sh
```

Expected startup sequence:

```text
DTP-CAN v6.2.1 - modular application
Using absolute configuration path: /absolute/path/.../drivers/config/config.json

=== Wi-Fi Selection ===
1. <SSID 1>
2. <SSID 2>
Select Wi-Fi network number:

=== Git Branch Selection ===
1. origin/<branch 1>
2. origin/<branch 2>
Select Git branch number:

Startup selection completed.
Wi-Fi: <selected SSID>
Git branch: <selected branch>
Git commit: <commit>
Diagnostic main menu is intentionally not started.
```

`drivers/application/startup.py` owns this startup workflow. The existing folder structure is retained.
