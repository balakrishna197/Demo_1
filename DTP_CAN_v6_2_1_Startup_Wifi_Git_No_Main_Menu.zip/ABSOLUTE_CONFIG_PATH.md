# Absolute configuration path fix

The executable now uses an absolute configuration path supplied at build time.

The build script calculates:

```text
<absolute project directory>/drivers/config/config.json
```

For example, if the project is located at:

```text
/home/pi/DTP-CAN-v6.2.1
```

the executable will use:

```text
/home/pi/DTP-CAN-v6.2.1/drivers/config/config.json
```

Do not change the folder structure. Keep `config.json` at:

```text
<project>/drivers/config/config.json
```

The PyInstaller runtime hook embeds the absolute path into the generated executable, so launching `dist/uds_diagnostics` directly does not depend on the current working directory.

The build intentionally stops with a clear error if the configuration file does not exist before building.
