from dtp_can.diagnostic.verifier import DefaultResponseVerifier
from dtp_can.testcase.models import TestcaseStep

def test_matching_response():
    step=TestcaseStep("TC1","demo",bytes.fromhex("22 f1 90"),bytes.fromhex("62 f1 90"))
    assert DefaultResponseVerifier().verify(step,bytes.fromhex("62 f1 90"))[0]

def test_mismatch_response():
    step=TestcaseStep("TC1","demo",bytes.fromhex("22 f1 90"),bytes.fromhex("62 f1 90"))
    assert not DefaultResponseVerifier().verify(step,bytes.fromhex("7f 22 13"))[0]
