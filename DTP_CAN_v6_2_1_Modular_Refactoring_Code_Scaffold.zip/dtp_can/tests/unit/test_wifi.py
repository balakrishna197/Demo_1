from types import SimpleNamespace
from dtp_can.network.wifi import WiFiManager

def fake_run(cmd, **kwargs):
    return SimpleNamespace(returncode=0, stdout="yes:TestNet\nno:Other\n", stderr="")

def test_wifi_status():
    assert WiFiManager(command_runner=fake_run).is_connected("TestNet")
