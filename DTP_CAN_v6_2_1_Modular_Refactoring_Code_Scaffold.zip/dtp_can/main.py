"""Composition root example. Replace adapters with the real v6.2.1 implementations during migration."""
from .ui.terminal import TerminalUI
from .network.wifi import WiFiManager
from .network.udp_client import UdpSeedKeyClient
from .network.connectivity import ConnectivityService
from .testcase.parser import TestcaseParser
from .diagnostic.executor import TestcaseExecutor
from .diagnostic.verifier import DefaultResponseVerifier
from .diagnostic.udsoncan_transport import UdsoncanTransport
from .reporting.asc_parser import AscParser
from .reporting.report_manager import ReportManager, HtmlReportRenderer


def build_application(config):
    ui=TerminalUI()
    wifi=WiFiManager()
    udp=None
    if config.network.udp_ip and config.network.udp_port:
        udp=UdpSeedKeyClient(config.network.udp_ip,config.network.udp_port,config.network.udp_timeout,config.network.expected_key_length)
    network=ConnectivityService(wifi,udp)
    transport=UdsoncanTransport(config.raw.get("can",{}),config.raw.get("uds",{}).get("isotp",{}),config.raw.get("uds",{}).get("addressing",{}))
    diagnostic=TestcaseExecutor(transport,DefaultResponseVerifier())
    reporting=ReportManager(AscParser(),HtmlReportRenderer())
    return ui,network,TestcaseParser(),diagnostic,reporting

if __name__ == "__main__":
    print("DTP-CAN modular architecture scaffold. Wire the existing v6.2.1 adapters before hardware execution.")
