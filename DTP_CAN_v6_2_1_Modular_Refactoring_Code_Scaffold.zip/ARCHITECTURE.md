# DTP-CAN v6.2.1 Updated Architecture

```text
                         main.py
                            |
                    Application / Use Cases
                            |
       +------------+-------+--------+------------+
       |            |                |            |
    CONFIG       NETWORK        REPOSITORY     TESTCASE
                    |                |            |
                 +--+--+             |            |
                 |     |             |            |
                WiFi  UDP            Git          CSV
                    \   /             |            |
                     \ /              |            |
                  connectivity        |            |
                         \            |            /
                          +-----------+-----------+
                                      |
                                 DIAGNOSTIC
                                  /        \
                              UDS/ISO-TP   Verifier
                                  |
                                 CAN
                                  |
                              CAN Logger
                                  |
                              REPORTING
                         /         |          \
                       ASC      Matcher     Metadata/HTML
                                      |
                                      v
                                      UI
```

## Module rule
A module is a functional capability, not a single function. Related functions stay together. Avoid creating a file for every helper.

## Target boundaries
- Network owns Wi-Fi and UDP.
- Diagnostic owns UDS execution policy.
- CAN owns Linux SocketCAN and logging adapters.
- Repository owns Git CLI.
- Testcase owns CSV/domain conversion.
- Reporting owns ASC/result/report transformations.
- UI owns presentation/input.
- System owns SSH/USB/systemd.
- Application owns sequencing.
