# v6.2.1 Current -> Modular Migration Map

| Current code | Target module | Rule |
|---|---|---|
| `main.py` Wi-Fi scan/connect/status/reconnect/monitor | `network/wifi.py` | Move unchanged first, then clean API |
| `main.py` Wi-Fi setup/menu workflow | `application/use_cases.py` | Workflow remains application-owned |
| `uds_client.py` `check_udp_server()` | `network/udp_client.py` | Move socket ownership |
| `uds_client.py` seed/key UDP block | `network/udp_client.py` | Move socket/retry/timeout |
| `main.py` CAN bring-up | `can/interface.py` | Move Linux command ownership |
| `initialize_interfaces.py` | `can/interface.py` | Merge/refactor |
| `can_logger.py` | `can/logger.py` | Adapter behind logger port |
| `Parse_handler.py` | `testcase/parser.py` | Return `TestcaseStep` |
| `uds_client.py` connection creation | `diagnostic/udsoncan_transport.py` | Third-party imports isolated |
| `uds_client.py` request/response execution | `diagnostic/executor.py` + transport | Separate orchestration from I/O |
| `uds_client.py` `verify_response()` | `diagnostic/verifier.py` | Pure policy |
| `did_decoder.py` | `diagnostic/did.py` | Domain-specific decoder |
| `git_manager.py` | `repository/git.py` | Git CLI adapter |
| `report_generator.py` parsing | `reporting/asc_parser.py` | Pure parsing |
| `report_generator.py` matching | `reporting/matcher.py` | Pure matching |
| `report_generator.py` timestamps | `reporting/metadata.py` | Explicit timestamp source/precedence |
| `report_generator.py` HTML | `reporting/report_manager.py` / renderer | Presentation only |
| `terminal_ui.py`, `oled_display.py`, `button_input.py` | `ui/` | Hardware adapters |
| `ssh_setup.py`, `install_service.py`, `transfer_file.py` | `system/` | OS/infrastructure |
