# DTP-CAN v6.2.1 Modular Refactoring Scaffold

This package is the target architecture and migration scaffold for the supplied DTP-CAN v6.2.1 source.
It is intentionally not a drop-in replacement for the existing ECU/CAN behavior yet. The existing behavior must be moved behind the indicated adapters in phases.

## Key modules
- `network/`: Wi-Fi and UDP seed/key
- `diagnostic/`: UDS testcase execution and response verification
- `can/`: Linux SocketCAN and logging
- `testcase/`: CSV/testcase models
- `repository/`: Git/Bitbucket
- `reporting/`: ASC parsing and report generation
- `ui/`: terminal/OLED/buttons
- `system/`: SSH/USB/systemd
- `application/`: workflow/use cases

## First migration steps
1. Move current Wi-Fi functions from `main.py` to `network/wifi.py`.
2. Move UDP server/seed-key code from `uds_client.py` to `network/udp_client.py`.
3. Move CAN interface setup to `can/interface.py`.
4. Wrap current `Parse_handler.py` in `TestcaseParser`.
5. Move current `_send_request_and_wait` and connection creation behind `DiagnosticTransport`.
6. Move current response comparison to `DefaultResponseVerifier`.
7. Split `report_generator.py` into parser/matcher/metadata/renderer while keeping report output identical.
8. Only then make `main.py` the composition root.

## Important
The `UdsoncanTransport` deliberately contains `NotImplementedError` placeholders. This prevents accidentally claiming the scaffold is hardware-ready. The existing v6.2.1 CAN/ISO-TP logic must be moved there with regression tests.
