# Testcase Run Flow: Old vs New

## Old v6.2.1

`main.py::main()` -> `UDSApp()` -> UI/setup -> Wi-Fi functions in `UDSApp` -> CAN bring-up -> `GitManager` -> `UDSClient` -> `UDSClient.run_testcase()` -> testcase parser -> CAN/ISO-TP/UDS -> UDP seed/key directly in `UDSClient` when needed -> `CANLogger` -> `UDSClient` directly calls `generate_report()` -> `report_generator.py` parses/matches/renders.

### Main problem
`main.py` and `UDSClient` cross multiple functional boundaries. Report generation also depends on a large number of independent parameters and internal parsing state.

## New modular flow

`main.py` -> `Application` -> `RunDiagnosticUseCase`

1. `ConfigLoader` creates typed configuration.
2. `NetworkManager` owns Wi-Fi.
3. `UdpSeedKeyClient` owns UDP seed/key.
4. `GitRepository` owns Git operations.
5. `TestcaseParser` returns `TestcaseStep` objects.
6. `TestcaseExecutor` owns testcase sequencing.
7. `DiagnosticTransport` owns UDS/ISO-TP/CAN I/O.
8. `ResponseVerifier` decides PASS/FAIL.
9. `CanLogger` owns CAN logging.
10. `ReportManager` receives `ReportContext` and coordinates parser/matcher/metadata/renderer.
11. `UI` only presents status/results.

## Dependency rule
Application -> ports/models -> infrastructure implementations.

Infrastructure must not control application workflow or UI.
