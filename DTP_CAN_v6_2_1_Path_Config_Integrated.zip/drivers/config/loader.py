"""JSON configuration loading for DTP-CAN v6.2.1."""

from __future__ import annotations

import json
from pathlib import Path

from .models import AppConfig, NetworkConfig, CanConfig
from .paths import AppPaths


class ConfigLoader:
    """Infrastructure boundary for JSON configuration.

    Configuration lookup is delegated to AppPaths so the application does not
    depend on the directory from which the user starts the program.
    """

    def __init__(self, paths: AppPaths | None = None) -> None:
        self.paths = paths or AppPaths()

    def load(self, path: str | Path | None = None) -> AppConfig:
        config_path = self.paths.resolve_config(path)
        data = json.loads(config_path.read_text(encoding="utf-8"))

        uds = data.get("uds", {})
        udp = uds.get("udp_server", {})
        can = data.get("can", {})

        return AppConfig(
            raw=data,
            network=NetworkConfig(
                wifi_enabled=data.get("wifi_enabled", True),
                saved_ssid=data.get("wifi_ssid"),
                udp_ip=udp.get("ip"),
                udp_port=udp.get("port"),
                udp_timeout=float(udp.get("timeout", 2.0)),
                expected_key_length=int(udp.get("expected_key_length", 0) or 0),
            ),
            can=CanConfig(
                channel=can.get("channel", "can0"),
                interface=can.get("interface", "socketcan"),
                bitrate=int(can.get("bitrate", 500000)),
                data_bitrate=can.get("data_bitrate"),
                fd=bool(can.get("fd", False)),
            ),
            testcase_path=data.get("testcase_path"),
            report_dir=data.get("report_dir", "output/html_reports"),
        )
