"""Application path resolution for DTP-CAN v6.2.1.

All path resolution is kept in this module so the application does not depend
on the shell's current working directory.  This is important both when the
project is started from source and when it is executed as a PyInstaller
one-file executable on Raspberry Pi.
"""

from __future__ import annotations

import sys
from pathlib import Path


class AppPaths:
    """Resolve project/config/output paths independently of the current CWD."""

    CONFIG_FILENAME = "config.json"

    def __init__(self, base_dir: str | Path | None = None) -> None:
        if base_dir is not None:
            self.base_dir = Path(base_dir).expanduser().resolve()
        else:
            self.base_dir = self._detect_base_dir()

        self.config_dir = self.base_dir / "drivers" / "config"
        self.config_file = self.config_dir / self.CONFIG_FILENAME
        self.output_dir = self.base_dir / "output"
        self.html_reports_dir = self.output_dir / "html_reports"
        self.can_logs_dir = self.output_dir / "can_logs"
        self.logs_dir = self.output_dir / "logs"

    @staticmethod
    def _detect_base_dir() -> Path:
        """Return the directory that should be treated as the application root.

        Source execution:
            <project>/main.py

        PyInstaller one-file execution:
            <project>/dist/uds_diagnostics
            sys.executable points to the executable.

        We intentionally do not use Path.cwd(), because the application may
        be started from a different working directory.
        """
        if getattr(sys, "frozen", False):
            # For a PyInstaller executable, keep external configuration beside
            # the project/application directory rather than inside _MEIPASS.
            executable_dir = Path(sys.executable).resolve().parent

            # If executable is in <project>/dist, the project root is its parent.
            if executable_dir.name.lower() == "dist":
                return executable_dir.parent

            # If the executable is copied elsewhere, its directory is the
            # safest application root.
            return executable_dir

        # In normal source execution, this file is:
        # <project>/drivers/config/paths.py
        return Path(__file__).resolve().parents[2]

    def resolve_config(self, path: str | Path | None = None) -> Path:
        """Resolve a configuration path.

        Supported forms:
        - None / "config.json": drivers/config/config.json
        - absolute path: used as-is
        - relative path: first resolved from application root, then from
          drivers/config/ for compatibility with the existing layout.
        """
        if path is None:
            candidate = self.config_file
        else:
            requested = Path(path).expanduser()

            if requested.is_absolute():
                candidate = requested
            else:
                candidates = (
                    self.base_dir / requested,
                    self.config_dir / requested,
                )
                candidate = next(
                    (item for item in candidates if item.is_file()),
                    candidates[0],
                )

        candidate = candidate.resolve()

        if not candidate.is_file():
            raise FileNotFoundError(
                "Configuration file not found. "
                f"Expected: {candidate}. "
                "Place config.json in drivers/config/ or provide an "
                "absolute configuration path."
            )

        return candidate

    def ensure_output_dirs(self) -> None:
        """Create the standard runtime output directories."""
        for directory in (
            self.output_dir,
            self.html_reports_dir,
            self.can_logs_dir,
            self.logs_dir,
        ):
            directory.mkdir(parents=True, exist_ok=True)
