import unittest

from diagnostic_app.application.selection import SelectionService, UIContext


class FakeDisplay:
    def __init__(self):
        self.messages = []

    def display_centered_text(self, text):
        self.messages.append(text)

    def display_text(self, text, line=0):
        self.messages.append(text)

    def clear(self):
        pass

    def set_wifi_status(self, status):
        pass


class FakeButtons:
    def __init__(self, actions):
        self.actions = iter(actions)

    def get_pressed_nonblocking(self):
        try:
            return next(self.actions)
        except StopIteration:
            return None

    def wait_for_press(self):
        return 0


class SelectionServiceTests(unittest.TestCase):
    def test_select_next_then_select(self):
        display = FakeDisplay()
        buttons = FakeButtons([1, 2])
        ui = UIContext(display=display, buttons=buttons)
        service = SelectionService(ui)
        self.assertEqual(service.select_from_list("Item", ["A", "B"]), 1)


if __name__ == "__main__":
    unittest.main()
