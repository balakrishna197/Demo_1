"""UDS Diagnostics application entry point.

The entry point only creates the application. Business logic and hardware
integration are intentionally kept outside this module.
"""

import logging
import os
import sys

from diagnostic_app.application.app import DiagnosticApplication


def get_base_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def configure_logging(base_dir: str) -> None:
    log_dir = os.path.join(base_dir, "logs")
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, "uds_debug.log")
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(log_file, mode="w"),
            logging.StreamHandler(),
        ],
    )


def main() -> None:
    base_dir = get_base_dir()
    configure_logging(base_dir)
    application = DiagnosticApplication(base_dir)
    try:
        application.run()
    finally:
        application.shutdown()


if __name__ == "__main__":
    main()
