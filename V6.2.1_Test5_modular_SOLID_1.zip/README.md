# DTP-CAN UDS Diagnostics – Modular Structure

This version refactors the original application into a layered structure while keeping the existing UDS/reporting implementation and public `drivers.*` imports compatible.

## Architecture

```text
main.py
   │
   ▼
diagnostic_app.application.app
   │
   ├── startup.py
   ├── repository.py
   ├── selection.py
   ├── wifi.py
   └── menu.py
   │
   ▼
domain
   ├── models.py
   └── interfaces.py
   │
   ▼
infrastructure
   ├── diagnostics
   ├── testcases
   ├── reporting
   ├── can
   ├── git
   ├── configuration
   ├── hardware
   ├── ui
   ├── network
   ├── storage
   └── system
```

## SOLID changes

### Single Responsibility
- Test-case parsing is isolated in `testcase_parser.py`.
- Repository selection is handled by `RepositoryWorkflow`.
- Wi-Fi operations are handled by `WiFiService`.
- Menu operations are handled by `MainMenuController`.
- Startup sequencing is handled by `StartupCoordinator`.
- Hardware/UI construction is handled by `UIFactory`.

### Open/Closed
The application depends on interfaces such as `UDSInterface`, `RepositoryInterface`, `DisplayInterface`, and `USBTransferInterface`. New implementations can be added without changing the application services.

### Liskov Substitution
The UDS, Git and USB adapters implement the application-facing contracts and can be replaced with test doubles.

### Interface Segregation
Interfaces are small and responsibility-specific rather than using one large device interface.

### Dependency Inversion
Application services depend on domain interfaces. Raspberry Pi, CAN, Git, NetworkManager and UDS implementation details stay in infrastructure.

## Backward compatibility

The `drivers/` directory now contains thin compatibility shims. Existing imports such as:

```python
from drivers.uds_client import UDSClient
```

continue to work, while the implementation lives under `diagnostic_app/infrastructure/`.

## Recommended next step

The large legacy `UDSClient` and `report_generator` implementations can now be split further behind their interfaces without changing the application layer. This is deliberately a second-stage refactor so that diagnostic behavior is not changed during the architectural migration.
