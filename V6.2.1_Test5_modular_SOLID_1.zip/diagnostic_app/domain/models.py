"""Domain models used by the diagnostic application.

These classes intentionally contain no Raspberry Pi, CAN, UDS, Git or UI code.
They provide stable data contracts between application services.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


@dataclass(frozen=True)
class RepositorySelection:
    employee: str
    variant: str
    test_type: str
    stage: str
    date: str
    branch: str
    testcase_path: Path
    config_path: Path
    repo_path: Path
    commit: str
    branch_url: str


@dataclass
class ApplicationContext:
    base_dir: Path
    config: dict[str, Any] = field(default_factory=dict)
    selected_testcase: Optional[Path] = None
    selected_config: Optional[Path] = None
    selected_branch: Optional[str] = None
    report_branch_name: str = "N/A"
    report_branch_url: str = ""
    report_branch_commit: str = "N/A"
    uds: Any = None
    repository: Any = None
    usb: Any = None
    display: Any = None
    hardware_display: Any = None
    terminal_display: Any = None
    buttons: Any = None
    terminal_input: Any = None
