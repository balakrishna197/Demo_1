import logging
import subprocess
import threading
import time

from diagnostic_app.application.selection import SelectionService, UIContext


class WiFiService:
    """Owns NetworkManager interaction and Wi-Fi reconnect monitoring."""

    def __init__(self, ui: UIContext, selector: SelectionService, monitor_interval: float = 10.0):
        self.ui = ui
        self.selector = selector
        self.monitor_interval = monitor_interval
        self.current_ssid = None
        self.wifi_connected = False
        self.last_wifi_status = True
        self._stop_monitor = False
        self._monitor_thread = None

    def scan(self) -> list[str]:
        try:
            result = subprocess.check_output(
                ["nmcli", "-t", "-f", "SSID", "dev", "wifi"],
                text=True,
            )
            networks = []
            for ssid in result.splitlines():
                ssid = ssid.strip()
                if ssid and ssid not in networks:
                    networks.append(ssid)
            return networks
        except Exception as exc:
            logging.error("WiFi Scan Error: %s", exc)
            return []

    def connect(self, ssid: str, password: str) -> bool:
        if self.ui.display:
            self.ui.display.display_centered_text(f"Connecting\n{ssid}")
        result = subprocess.run(
            [
                "nmcli", "--wait", "15", "device", "wifi", "connect",
                ssid, "password", password,
            ],
            capture_output=True,
            text=True,
        )
        logging.info(result.stdout)
        if result.stderr:
            logging.warning(result.stderr)
        return result.returncode == 0

    def is_connected(self, ssid: str) -> bool:
        result = subprocess.run(
            ["nmcli", "-t", "-f", "ACTIVE,SSID", "device", "wifi"],
            capture_output=True,
            text=True,
        )
        return any(line == f"yes:{ssid}" for line in result.stdout.splitlines())

    def try_saved_connection(self, ssid: str) -> bool:
        result = subprocess.run(
            ["nmcli", "connection", "up", ssid],
            capture_output=True,
            text=True,
        )
        return result.returncode == 0

    def setup(self) -> bool:
        display = self.ui.display
        if display is None:
            raise RuntimeError("Display is not initialized")

        logging.info("------------- Wifi Setup -------------")
        display.display_centered_text("Scanning\nWiFi...")
        networks = self.scan()
        if not networks:
            display.display_centered_text("No WiFi\nFound")
            time.sleep(2)
            return False

        while True:
            selected_index = self.selector.select_from_list(
                "WiFi", networks, allow_cancel=True
            )
            if selected_index is None:
                display.display_centered_text("No WiFi\nConnected")
                time.sleep(1)
                return False

            ssid = networks[selected_index]
            saved = subprocess.run(
                ["nmcli", "-t", "-f", "NAME", "connection", "show"],
                capture_output=True,
                text=True,
            )
            saved_connections = saved.stdout.splitlines()

            if ssid in saved_connections:
                if self.is_connected(ssid) or self.try_saved_connection(ssid):
                    self._mark_connected(ssid, "Connected" if not self.is_connected(ssid) else "Using")
                    return True
                subprocess.run(
                    ["nmcli", "connection", "delete", ssid],
                    capture_output=True,
                    text=True,
                )

            while True:
                password = self.selector.enter_password(ssid)
                if self.connect(ssid, password):
                    self._mark_connected(ssid, "Connected")
                    return True
                display.display_centered_text("Wrong Password\nTry Again")
                time.sleep(1)

    def _mark_connected(self, ssid: str, message: str):
        self.current_ssid = ssid
        self.wifi_connected = True
        if self.ui.display:
            self.ui.display.set_wifi_status("W+")
            self.ui.display.display_centered_text(f"{message}\n{ssid}")
        time.sleep(1)

    def start_monitor(self):
        self._stop_monitor = False
        self._monitor_thread = threading.Thread(
            target=self._monitor,
            name="wifi-monitor",
            daemon=True,
        )
        self._monitor_thread.start()

    def stop_monitor(self):
        self._stop_monitor = True
        if self._monitor_thread and self._monitor_thread.is_alive():
            self._monitor_thread.join(timeout=2)

    def reconnect(self) -> bool:
        if not self.current_ssid:
            return False
        success = self.try_saved_connection(self.current_ssid)
        self.wifi_connected = success
        return success

    def _monitor(self):
        if self.ui.display is None:
            logging.warning("WiFi monitor disabled: display is not initialized")
            return

        while not self._stop_monitor:
            connected = bool(self.current_ssid and self.is_connected(self.current_ssid))
            if connected:
                self.ui.display.set_wifi_status("W+")
                if not self.last_wifi_status:
                    logging.info("WiFi Reconnected")
                self.last_wifi_status = True
            else:
                if self.last_wifi_status:
                    logging.warning("WiFi Lost")
                self.last_wifi_status = False
                self.ui.display.set_wifi_status("W~")
                if self.reconnect():
                    self.ui.display.set_wifi_status("W+")
                    self.last_wifi_status = True
                    logging.info("WiFi Reconnected")
                else:
                    self.ui.display.set_wifi_status("W-")
            time.sleep(self.monitor_interval)
