import logging
from pathlib import Path

from diagnostic_app.application.menu import MainMenuController
from diagnostic_app.application.startup import StartupCoordinator
from diagnostic_app.infrastructure.configuration.config_repository import JsonConfigRepository
from diagnostic_app.infrastructure.ui.ui_factory import UIFactory


class DiagnosticApplication:
    """Composition root facade for the complete application."""

    def __init__(self, base_dir: str | Path):
        self.base_dir = Path(base_dir)
        self.startup = StartupCoordinator(
            base_dir=self.base_dir,
            ui_factory=UIFactory(),
            config_loader=JsonConfigRepository(),
        )
        self.context = None
        self.selector = None
        self.wifi = None
        self.menu = None

    def initialize(self):
        self.context, self.selector, self.wifi = self.startup.initialize()
        self.menu = MainMenuController(
            context=self.context,
            selector=self.selector,
            wifi=self.wifi,
            repository=self.context.repository,
        )
        return self

    def run(self):
        if self.menu is None:
            self.initialize()
        self.menu.run()

    def shutdown(self):
        if self.wifi is not None:
            self.wifi.stop_monitor()
        logging.info("Application shutdown complete")
