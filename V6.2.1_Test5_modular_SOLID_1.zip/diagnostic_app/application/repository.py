import logging
import os
import shutil
import subprocess
import time
from pathlib import Path

from diagnostic_app.application.selection import SelectionService, UIContext
from diagnostic_app.domain.models import RepositorySelection
from diagnostic_app.domain.interfaces import ConfigLoaderInterface, RepositoryInterface


class RepositoryWorkflow:
    """Coordinates Git selection without making GitManager aware of the UI."""

    def __init__(
        self,
        repository: RepositoryInterface,
        config_loader: ConfigLoaderInterface,
        selector: SelectionService,
        ui: UIContext,
        base_dir: Path,
    ):
        self.repository = repository
        self.config_loader = config_loader
        self.selector = selector
        self.ui = ui
        self.base_dir = Path(base_dir)

    def _select(self, title, items, formatter=str):
        if not items:
            raise RuntimeError(f"No {title.lower()} found")
        index = self.selector.select_from_list(title, items, formatter=formatter)
        if index is None:
            raise RuntimeError(f"{title} selection cancelled")
        return items[index]

    def run(self) -> tuple[RepositorySelection, dict]:
        display = self.ui.display
        if display is None:
            raise RuntimeError("User interface display is not initialized")

        display.display_centered_text("Checking\nRepository...")

        employee = self._select("Employee", self.repository.get_employee_ids())
        variant = self._select("Variant", self.repository.get_variants(employee))
        test_type = self._select("Type", self.repository.get_types(employee, variant))
        stage = self._select("Stage", self.repository.get_stages(employee, variant, test_type))
        date = self._select("Date", self.repository.get_dates(employee, variant, test_type, stage))
        branch = self.repository.get_matching_branch(employee, variant, test_type, stage, date)

        logging.info("Selected branch: %s", branch)
        display.display_centered_text("Updating\nRepository...")
        self.repository.clone_repository(branch)
        self.repository.pull_repository()

        repo_path = Path(self.repository.repo_path)
        commit = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()

        repo_web_url = (
            self.repository.repo_url
            .replace("git@bitbucket.org:", "https://bitbucket.org/")
            .replace(".git", "")
        )
        branch_url = f"{repo_web_url}/src/{commit}/?at={branch}"

        testcases, configs = self.repository.get_testcases_and_configs()
        testcase = self._auto_or_select("Testcase", testcases, os.path.basename)
        config_path = self._auto_or_select("Config", configs, os.path.basename)

        self._copy_selected_testcase(testcase)
        config = self.config_loader.load(config_path)

        logging.info("Repository selection complete")
        display.display_centered_text("Repository\nReady")
        time.sleep(2)

        return RepositorySelection(
            employee=employee,
            variant=variant,
            test_type=test_type,
            stage=stage,
            date=date,
            branch=branch,
            testcase_path=Path(testcase),
            config_path=Path(config_path),
            repo_path=repo_path,
            commit=commit,
            branch_url=branch_url,
        ), config

    def _auto_or_select(self, title, items, formatter):
        if len(items) == 1:
            item = items[0]
            self.ui.display.display_centered_text(f"{title}\nAuto Selected")
            time.sleep(1)
            return item
        return self._select(title, items, formatter=formatter)

    def _copy_selected_testcase(self, testcase):
        support_dir = self.base_dir / "supportfiles"
        support_dir.mkdir(parents=True, exist_ok=True)
        for file_path in support_dir.glob("*.txt"):
            file_path.unlink()

        destination = support_dir / Path(testcase).name
        shutil.copy(testcase, destination)
        (self.base_dir / "selected_testcase.txt").write_text(destination.name)
