import logging
import os
import subprocess
import time
from pathlib import Path

from diagnostic_app.application.repository import RepositoryWorkflow
from diagnostic_app.application.selection import SelectionService, UIContext
from diagnostic_app.application.wifi import WiFiService
from diagnostic_app.domain.models import ApplicationContext
from diagnostic_app.infrastructure.diagnostics.uds_adapter import UDSClientAdapter
from diagnostic_app.infrastructure.git.repository_adapter import GitRepositoryAdapter
from diagnostic_app.infrastructure.hardware.interface_initializer import HardwareInitializer
from diagnostic_app.infrastructure.storage.usb_adapter import USBTransferAdapter
from diagnostic_app.infrastructure.system.service_installer import ServiceInstaller
from diagnostic_app.infrastructure.system.ssh_setup import ssh_key_setup


class StartupCoordinator:
    """Initializes external resources in a controlled, testable sequence."""

    def __init__(self, base_dir: Path, ui_factory, config_loader):
        self.base_dir = Path(base_dir)
        self.ui_factory = ui_factory
        self.config_loader = config_loader

    @staticmethod
    def resolve_ui_mode() -> str:
        requested_mode = os.environ.get("DTP_UI_MODE", "auto").strip().lower()
        if requested_mode in {"oled", "hardware"}:
            return "hardware"
        if requested_mode in {"terminal", "console"}:
            return "terminal"
        return "auto"

    def initialize(self) -> tuple[ApplicationContext, SelectionService, WiFiService]:
        context = ApplicationContext(base_dir=self.base_dir)

        try:
            import RPi.GPIO as GPIO  # type: ignore[import-not-found]
            GPIO.cleanup()
        except Exception as exc:
            logging.debug("GPIO cleanup skipped: %s", exc)

        HardwareInitializer().initialize()
        ssh_key_setup.setup_ssh()

        ui_data = self.ui_factory.create(self.resolve_ui_mode())
        context.display = ui_data["display"]
        context.hardware_display = ui_data["hardware_display"]
        context.buttons = ui_data["buttons"]
        context.terminal_display = ui_data["terminal_display"]
        context.terminal_input = ui_data["terminal_input"]

        ui = UIContext(
            display=context.display,
            hardware_display=context.hardware_display,
            buttons=context.buttons,
            terminal_display=context.terminal_display,
            terminal_input=context.terminal_input,
        )
        selector = SelectionService(ui)
        wifi = WiFiService(ui, selector)
        wifi.setup()
        wifi.start_monitor()

        repository = GitRepositoryAdapter(self.base_dir)
        workflow = RepositoryWorkflow(
            repository=repository,
            config_loader=self.config_loader,
            selector=selector,
            ui=ui,
            base_dir=self.base_dir,
        )
        selection, config = workflow.run()

        context.repository = repository
        context.config = config
        context.selected_testcase = selection.testcase_path
        context.selected_config = selection.config_path
        context.selected_branch = selection.branch
        context.report_branch_name = selection.branch
        context.report_branch_url = selection.branch_url
        context.report_branch_commit = selection.commit

        uds = UDSClientAdapter(
            context.config,
            config_path=str(context.selected_config),
            repo_path=str(selection.repo_path),
        )
        uds.client.repo_path = str(selection.repo_path)
        uds.client.report_branch_name = selection.branch
        uds.client.report_branch_url = selection.branch_url
        context.uds = uds

        self._check_udp_server(context)
        self._wait_for_ecu_if_configured(context)
        context.usb = USBTransferAdapter(context.display)

        try:
            ServiceInstaller.install()
        except Exception:
            logging.exception("Service installation failed during startup")

        return context, selector, wifi

    def _check_udp_server(self, context: ApplicationContext):
        max_retries = 3
        connected = False
        for retry in range(1, max_retries + 1):
            context.display.display_centered_text(
                f"Checking\nUDP Server...\n\n{retry}/{max_retries}"
            )
            try:
                if context.uds.check_udp_server():
                    connected = True
                    context.display.display_centered_text("UDP Server\nConnected")
                    time.sleep(2)
                    break
            except Exception:
                logging.exception("UDP server check failed")

            if retry < max_retries:
                context.display.display_centered_text(
                    f"UDP Server\nNot Found\n\nRetry {retry}/{max_retries}"
                )
                time.sleep(2)

        if not connected:
            logging.warning("UDP server unavailable; continuing startup")
            context.display.display_centered_text(
                "UDP Server\nUnavailable\n\nContinuing..."
            )
            time.sleep(3)

        context.uds.client.udp_server_available = connected

    def _wait_for_ecu_if_configured(self, context: ApplicationContext):
        can_config = (context.config or {}).get("uds", {}).get("can", {})
        if not can_config.get("bringup_on_startup", False):
            logging.info("CAN bring-up skipped (bringup_on_startup = false)")
            return

        timeout_seconds = 60
        start_time = time.time()
        bitrate = can_config.get("bitrate", 500000)
        dbitrate = can_config.get("dbitrate", 2000000)
        restart_ms = can_config.get("restart_ms", 1000)

        while time.time() - start_time < timeout_seconds:
            if not self._can_present():
                logging.warning("CAN0 not detected. Retrying...")
                time.sleep(1)
                continue

            self._bringup_can_interface(bitrate, dbitrate, restart_ms, context)
            time.sleep(1)
            try:
                temp_uds = UDSClientAdapter(context.config)
                if temp_uds.try_basic_communication():
                    logging.info("UDS communication successful")
                    return
                context.display.display_centered_text("Waiting for ECU...")
            except Exception:
                logging.exception("Exception during UDS handshake")
                context.display.display_centered_text("ECU Comm Fail")
            time.sleep(2)

        context.display.display_centered_text("CAN/ECU Timeout\nCheck Setup")
        time.sleep(5)
        raise SystemExit("Initialization failed: CAN or ECU not responding.")

    @staticmethod
    def _can_present() -> bool:
        result = subprocess.run(
            "ip link show can0",
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        return "can0" in result.stdout.decode(errors="ignore")

    @staticmethod
    def _bringup_can_interface(bitrate, dbitrate, restart_ms, context):
        try:
            subprocess.run(["sudo", "ip", "link", "set", "can0", "down"], check=True)
            subprocess.run([
                "sudo", "ip", "link", "set", "can0", "up", "type", "can",
                "bitrate", str(bitrate), "dbitrate", str(dbitrate),
                "restart-ms", str(restart_ms), "berr-reporting", "on", "fd", "on",
            ], check=True)
            subprocess.run(["sudo", "ifconfig", "can0", "up"], check=True)
        except subprocess.CalledProcessError:
            logging.exception("CAN bring-up failed")
            context.display.display_centered_text("CAN init failed")
            time.sleep(2)
