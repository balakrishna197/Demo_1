import os
import time
from dataclasses import dataclass
from typing import Callable, Any


@dataclass
class UIContext:
    display: Any
    hardware_display: Any = None
    buttons: Any = None
    terminal_display: Any = None
    terminal_input: Any = None


class SelectionService:
    """Reusable selection/input behavior for both OLED and terminal UIs."""

    def __init__(self, ui: UIContext):
        self.ui = ui

    def has_terminal_input(self) -> bool:
        return (
            self.ui.terminal_input is not None
            and self.ui.terminal_input.is_available()
        )

    def has_hardware_input(self) -> bool:
        return self.ui.buttons is not None

    def print_terminal_instructions(self, lines):
        if not self.has_terminal_input():
            return
        print()
        for line in lines:
            print(line)

    def poll_combined_action(self, options_count=None, allow_cancel=False, timeout=0.1):
        if self.ui.buttons is not None:
            button = self.ui.buttons.get_pressed_nonblocking()
            if button == 0:
                return "prev"
            if button == 1:
                return "next"
            if button == 2:
                return "select"
            if button == 3 and allow_cancel:
                return "cancel"

        terminal_input = self.ui.terminal_input
        if terminal_input is not None and terminal_input.is_available():
            action = terminal_input.poll_action(timeout=timeout)
            if isinstance(action, tuple) and action[0] == "digit":
                digit = action[1]
                if options_count and 1 <= digit <= options_count:
                    return ("index", digit - 1)
                return None
            if action == "cancel" and not allow_cancel:
                return None
            return action

        if self.has_hardware_input():
            time.sleep(timeout)
        return None

    def select_from_list(
        self,
        title: str,
        items,
        formatter: Callable[[Any], str] = str,
        allow_cancel: bool = False,
    ):
        if not items:
            return None

        index = 0
        last_displayed_index = None

        while True:
            if index != last_displayed_index:
                label = formatter(items[index])

                if self.ui.hardware_display is not None:
                    self.ui.hardware_display.display_centered_text(
                        f"{title}\n\n{label}"
                    )

                if self.has_terminal_input():
                    os.system("clear")
                    print("=" * 50)
                    print(f"Select {title}")
                    print("=" * 50)
                    for i, item in enumerate(items):
                        prefix = ">" if i == index else " "
                        print(f"{prefix} {i + 1}. {formatter(item)}")
                    print()
                    print("Controls:")
                    print("A / P      : Previous")
                    print("D / N      : Next")
                    print("S / Enter  : Select")
                    if allow_cancel:
                        print("Q          : Cancel")
                    print("1-9        : Direct Selection")

                last_displayed_index = index

            action = self.poll_combined_action(
                options_count=min(len(items), 9),
                allow_cancel=allow_cancel,
                timeout=0.15,
            )

            if action == "prev":
                index = (index - 1) % len(items)
            elif action == "next":
                index = (index + 1) % len(items)
            elif action == "select":
                return index
            elif action == "cancel":
                return None
            elif isinstance(action, tuple) and action[0] == "index":
                selected_index = action[1]
                if 0 <= selected_index < len(items):
                    return selected_index

    def poll_main_menu_selection(self):
        while True:
            if self.ui.buttons is not None:
                button = self.ui.buttons.get_pressed_nonblocking()
                if button == 0:
                    return "1"
                if button == 1:
                    return "2"
                if button == 2:
                    return "3"
                if button == 3:
                    return "4"

            terminal_input = self.ui.terminal_input
            if terminal_input is not None and terminal_input.is_available():
                action = terminal_input.poll_action(timeout=0.15)
                if isinstance(action, tuple) and action[0] == "digit":
                    digit = action[1]
                    if 1 <= digit <= 4:
                        return str(digit)
            else:
                time.sleep(0.15)

    def enter_password(self, ssid: str) -> str:
        chars = (
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            "abcdefghijklmnopqrstuvwxyz"
            "0123456789"
            "@._-!#$%&*+=<>"
        )
        password = ""
        index = 0

        if self.has_terminal_input():
            self.print_terminal_instructions([
                f"Entering password for {ssid}",
                "Keyboard: type password directly, Backspace deletes, Enter submits, Q or Esc submits current text.",
                "Keypad still works in parallel.",
            ])

        while True:
            current_char = chars[index]
            masked_password = "*" * min(len(password), 8)
            if self.ui.display is not None:
                self.ui.display.display_centered_text(
                    f"Password:\n{masked_password}\n\n[{current_char}]"
                )

            if self.ui.buttons is not None:
                button = self.ui.buttons.get_pressed_nonblocking()
                if button == 0:
                    index = (index + 1) % len(chars)
                    time.sleep(0.15)
                    continue
                if button == 1:
                    index = (index - 1) % len(chars)
                    time.sleep(0.15)
                    continue
                if button == 2:
                    if current_char == "<":
                        password = password[:-1]
                    elif current_char == ">":
                        return password
                    else:
                        password += current_char
                    time.sleep(0.15)
                    continue
                if button == 3:
                    return password

            terminal_input = self.ui.terminal_input
            if terminal_input is not None and terminal_input.is_available():
                key = terminal_input.read_key(timeout=0.15)
                if key is None:
                    continue
                if key == "ENTER":
                    return password
                if key == "BACKSPACE":
                    password = password[:-1]
                    continue
                if key in {"ESC", "q", "Q"}:
                    return password
                if isinstance(key, str) and len(key) == 1 and key.isprintable():
                    password += key
            else:
                time.sleep(0.15)

    def enter_text(self, title: str, default_text: str = "") -> str:
        chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 ._- >"
        value = default_text or ""
        index = 0
        last_display = None

        if self.has_terminal_input():
            self.print_terminal_instructions([
                f"{title}:",
                "Keyboard: type directly, Backspace deletes, Enter submits.",
                "Keypad: UP/DOWN select char, OK adds char, BACK submits.",
            ])

        while True:
            current_char = chars[index]
            preview = value[-14:] if value else "<empty>"
            display_key = (preview, current_char)

            if display_key != last_display:
                if self.ui.hardware_display is not None:
                    self.ui.hardware_display.display_centered_text(
                        f"{title}\n{preview}\n\n[{current_char}]"
                    )
                if self.has_terminal_input():
                    os.system("clear")
                    print("=" * 50)
                    print(title)
                    print("=" * 50)
                    print(f"Value: {value}")
                    print()
                    print("Type directly and press Enter")
                last_display = display_key

            if self.ui.buttons is not None:
                button = self.ui.buttons.get_pressed_nonblocking()
                if button == 0:
                    index = (index + 1) % len(chars)
                    time.sleep(0.15)
                    continue
                if button == 1:
                    index = (index - 1) % len(chars)
                    time.sleep(0.15)
                    continue
                if button == 2:
                    if current_char == ">":
                        return value.strip()
                    value += current_char
                    time.sleep(0.15)
                    continue
                if button == 3:
                    return value.strip()

            terminal_input = self.ui.terminal_input
            if terminal_input is not None and terminal_input.is_available():
                key = terminal_input.read_key(timeout=0.15)
                if key is None:
                    continue
                if key == "ENTER":
                    return value.strip()
                if key == "BACKSPACE":
                    value = value[:-1]
                    continue
                if key == "ESC":
                    return value.strip()
                if key == "SPACE":
                    value += " "
                    continue
                if isinstance(key, str) and len(key) == 1 and key.isprintable():
                    value += key
            else:
                time.sleep(0.15)
