from typing import Any

from diagnostic_app.domain.interfaces import UDSInterface
from diagnostic_app.infrastructure.diagnostics.uds_client import UDSClient


class UDSClientAdapter(UDSInterface):
    """Application-facing adapter around the existing UDS implementation."""

    def __init__(self, config: dict, config_path=None, repo_path=None):
        self.client = UDSClient(
            config,
            config_path=config_path,
            repo_path=repo_path,
        )

    def check_udp_server(self) -> bool:
        return self.client.check_udp_server()

    def try_basic_communication(self) -> bool:
        return self.client.try_basic_communication()

    def get_ecu_information(self, oled: Any = None, logging_enable: bool = True):
        return self.client.get_ecu_information(oled, logging_enable=logging_enable)

    def run_testcase(self, oled: Any, tester_name: str = "N/A"):
        return self.client.run_testcase(oled, tester_name=tester_name)

    def __getattr__(self, name):
        # Compatibility for code that still needs implementation-specific
        # runtime attributes (repo_path, branch metadata, etc.).
        return getattr(self.client, name)
