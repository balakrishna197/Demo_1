import logging

from diagnostic_app.infrastructure.ui.button_input import ButtonInput
from diagnostic_app.infrastructure.ui.oled_display import OLEDDisplay
from diagnostic_app.infrastructure.ui.terminal_ui import (
    DisplayRouter,
    TerminalDisplay,
    TerminalInput,
)


class UIFactory:
    """Creates UI implementations without exposing hardware details to services."""

    DEFAULT_BUTTON_MAP = {
        "first": 12,
        "second": 16,
        "enter": 20,
        "power": 21,
    }

    def create(self, mode: str):
        requested = mode
        hardware_display = None
        buttons = None
        terminal_display = None
        terminal_input = None
        button_map = dict(self.DEFAULT_BUTTON_MAP)

        if requested in {"hardware", "auto"}:
            try:
                hardware_display = OLEDDisplay({
                    "width": 128,
                    "height": 64,
                    "address": "0x3C",
                })
                buttons = ButtonInput(list(button_map.values()))
            except Exception as exc:
                if requested == "hardware":
                    raise
                logging.warning(
                    "Hardware UI unavailable, falling back to terminal UI: %s",
                    exc,
                )

        if requested in {"terminal", "auto"}:
            candidate = TerminalInput()
            if candidate.is_available():
                terminal_input = candidate
                terminal_display = TerminalDisplay()
            elif requested == "terminal":
                terminal_display = TerminalDisplay()

        if hardware_display and terminal_display:
            display = DisplayRouter(hardware_display, terminal_display)
            ui_mode = "hybrid"
        elif hardware_display:
            display = hardware_display
            ui_mode = "hardware"
        else:
            display = terminal_display or TerminalDisplay()
            ui_mode = "terminal"

        return {
            "display": display,
            "hardware_display": hardware_display,
            "buttons": buttons,
            "terminal_display": terminal_display,
            "terminal_input": terminal_input,
            "button_map": button_map,
            "mode": ui_mode,
        }
