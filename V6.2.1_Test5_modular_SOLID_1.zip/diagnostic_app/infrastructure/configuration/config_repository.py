from pathlib import Path
from typing import Any

from diagnostic_app.domain.interfaces import ConfigLoaderInterface
from diagnostic_app.infrastructure.configuration.config_loader import load_config


class JsonConfigRepository(ConfigLoaderInterface):
    """Adapter around the JSON configuration loader."""

    def load(self, path: str | Path) -> dict[str, Any]:
        return load_config(str(path))
