from diagnostic_app.domain.interfaces import DisplayInterface, USBTransferInterface
from diagnostic_app.infrastructure.storage.usb_transfer import USBTransfer


class USBTransferAdapter(USBTransferInterface):
    def __init__(self, display: DisplayInterface):
        self._transfer = USBTransfer(display)

    def fetch_testcase_and_config_from_usb(self) -> bool:
        return bool(self._transfer.fetch_testcase_and_config_from_usb())

    def transfer_files_to_usb(self) -> None:
        self._transfer.transfer_files_to_usb()
