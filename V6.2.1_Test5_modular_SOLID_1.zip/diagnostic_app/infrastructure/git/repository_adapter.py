from diagnostic_app.domain.interfaces import RepositoryInterface
from diagnostic_app.infrastructure.git.git_manager import GitManager


class GitRepositoryAdapter(RepositoryInterface):
    """Application-facing repository adapter."""

    def __init__(self, base_dir):
        self.manager = GitManager(base_dir)

    def __getattr__(self, name):
        return getattr(self.manager, name)
