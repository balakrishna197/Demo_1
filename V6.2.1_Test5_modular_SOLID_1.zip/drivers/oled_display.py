"""Backward-compatible import shim."""
from diagnostic_app.infrastructure.ui.oled_display import *  # noqa: F401,F403
