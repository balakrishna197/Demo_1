"""Backward-compatible import shim."""
from diagnostic_app.infrastructure.configuration.config_loader import *  # noqa: F401,F403
