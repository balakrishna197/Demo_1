"""Backward-compatible import shim."""
from diagnostic_app.infrastructure.ui.terminal_ui import *  # noqa: F401,F403
