"""Backward-compatible import shim."""
from diagnostic_app.infrastructure.git.git_manager import *  # noqa: F401,F403
