"""Backward-compatible import shim."""
from diagnostic_app.infrastructure.system.service_installer import *  # noqa: F401,F403
