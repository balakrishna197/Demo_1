"""Backward-compatible import shim."""
from diagnostic_app.infrastructure.hardware.interface_initializer import *  # noqa: F401,F403
