"""Backward-compatible import shim."""
from diagnostic_app.infrastructure.diagnostics.uds_client import *  # noqa: F401,F403
