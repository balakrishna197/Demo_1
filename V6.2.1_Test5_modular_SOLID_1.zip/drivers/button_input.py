"""Backward-compatible import shim."""
from diagnostic_app.infrastructure.ui.button_input import *  # noqa: F401,F403
