"""Backward-compatible import shim."""
from diagnostic_app.infrastructure.can.can_logger import *  # noqa: F401,F403
