"""Backward-compatible import shim."""
from diagnostic_app.infrastructure.reporting.report_generator import *  # noqa: F401,F403
