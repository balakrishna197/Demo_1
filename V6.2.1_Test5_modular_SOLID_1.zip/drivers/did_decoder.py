"""Backward-compatible import shim."""
from diagnostic_app.infrastructure.diagnostics.did_decoder import *  # noqa: F401,F403
