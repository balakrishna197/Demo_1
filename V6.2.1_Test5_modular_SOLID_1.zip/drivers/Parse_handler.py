"""Backward-compatible import shim. Use diagnostic_app.infrastructure.testcases.testcase_parser."""
from diagnostic_app.infrastructure.testcases.testcase_parser import *  # noqa: F401,F403
