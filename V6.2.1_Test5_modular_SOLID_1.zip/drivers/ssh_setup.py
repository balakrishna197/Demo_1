"""Backward-compatible import shim."""
from diagnostic_app.infrastructure.system.ssh_setup import *  # noqa: F401,F403
