import csv
from collections import defaultdict
from typing import Literal, overload

HEADER_ALIASES = {
    "TC_ID": ["TC_ID/PC_ID", "TC_ID", "PC_ID"],
    "DESCRIPTION": ["Testcase_Description", "Description", "Test Description"],
    "SERVICE": ["Service_ID", "SID", "Service"],
    "SUBFUNC": ["SubService_ID", "SubFunction", "DID"],
    "EXPECTED": ["Expected_Response_Data", "Expected", "Response"],
    "WRITE": ["Write_Data", "Data", "Payload"],
    "ADDRESSING": ["Addressing", "Mode"],
    "FORMAT": ["Format"],
    "STATUS_MASK": ["Status_Mask", "StatusMask"],
    "COMM_TYPE": ["Communication_Type", "CommunicationType"],
    "CONTROLTYPE": ["controltype", "ControlType"],
}


def normalize_header_name(value):
    # Remove BOM and comment markers in either order.  Some CSV readers leave
    # the BOM attached to the first header, while others expose it before '#'.
    return str(value).strip().lstrip("\ufeff#").strip().upper()


@overload
def find_column(col, aliases, required: Literal[True] = True) -> int:
    ...


@overload
def find_column(col, aliases, required: Literal[False]) -> int | None:
    ...


def find_column(col, aliases, required: bool = True) -> int | None:
    normalized_aliases = [normalize_header_name(alias) for alias in aliases]
    for alias in normalized_aliases:
        if alias in col:
            return col[alias]
    if required:
        raise KeyError(f"Column not found. Tried: {aliases}")
    return None


grouped_cases = defaultdict(list)
ordered_testcases = []


def normalize_row(row, header_len, description_idx):
    if len(row) > header_len and description_idx is not None:
        extra_count = len(row) - header_len
        # A split description shifts the remaining fields to the right.
        # Merge description fragments while preserving the remaining fields.
        description_end = description_idx + extra_count + 1
        merged_description = ",".join(
            row[description_idx:description_end]
        )
        row = (
            row[:description_idx]
            + [merged_description]
            + row[description_end:]
        )

    if len(row) < header_len:
        row = row + [""] * (header_len - len(row))

    return row


def load_testcases(file_path):
    grouped_cases.clear()
    ordered_testcases.clear()
    try:
        with open(file_path, "r", newline="", encoding="utf-8-sig") as f:
            reader = csv.reader(f)
            header = []
            for row in reader:
                candidate = [normalize_header_name(h) for h in row]
                if (
                    "TC_ID/PC_ID" in candidate
                    or "TC_ID" in candidate
                    or "PC_ID" in candidate
                ):
                    header = candidate
                    break

            if not header:
                raise ValueError("TXT header row not found")

            col = {
                normalize_header_name(name): idx
                for idx, name in enumerate(header)
            }
            description_idx = find_column(
                col,
                HEADER_ALIASES["DESCRIPTION"],
                required=False
            )

            current_tc_id = None
            for row in reader:
                if not row:
                    continue  # Skip empty or malformed lines
                row = normalize_row(row, len(header), description_idx)
                row_values = [str(cell).strip().upper() for cell in row]
                cmd = None
                if "WAIT" in row_values:
                    cmd = "WAIT"
                if cmd == "WAIT":
                    if current_tc_id:
                        wait_index = row_values.index("WAIT")
                        if wait_index + 1 < len(row):
                            wait_value = row[wait_index + 1].strip()
                            if wait_value:
                                try:
                                    wait_step = (
                                        "WAIT",
                                        int(wait_value, 16)
                                    )
                                except ValueError:
                                    # A malformed WAIT row must not discard
                                    # testcases that were already parsed.
                                    continue
                                grouped_cases[current_tc_id].append(wait_step)
                                ordered_testcases.append(wait_step)
                    continue
                if len(row) < 5:
                    continue

                tc_id_idx = find_column(col, HEADER_ALIASES["TC_ID"])
                if tc_id_idx is None:
                    raise KeyError(
                        "Column not found. Tried: "
                        + str(HEADER_ALIASES["TC_ID"])
                    )
                tc_id = row[tc_id_idx].strip()
                current_tc_id = tc_id
                step_desc = row[
                    find_column(col, HEADER_ALIASES["DESCRIPTION"])
                ].strip()
                service_id = row[
                    find_column(col, HEADER_ALIASES["SERVICE"])
                ].strip()
                subfunction_or_did = row[
                    find_column(col, HEADER_ALIASES["SUBFUNC"])
                ].strip()
                expected_response = row[
                    find_column(col, HEADER_ALIASES["EXPECTED"])
                ].strip()
                write_data = row[
                    find_column(col, HEADER_ALIASES["WRITE"])
                ].strip()
                addressing = row[
                    find_column(col, HEADER_ALIASES["ADDRESSING"])
                ].strip().lower()
                format_type = row[
                    find_column(col, HEADER_ALIASES["FORMAT"])
                ].strip()
                status_mask_idx = find_column(
                    col,
                    HEADER_ALIASES["STATUS_MASK"],
                    required=False
                )
                communication_type_idx = find_column(
                    col,
                    HEADER_ALIASES["COMM_TYPE"],
                    required=False
                )
                controltype_idx = find_column(
                    col,
                    HEADER_ALIASES["CONTROLTYPE"],
                    required=False
                )
                status_mask = (
                    row[status_mask_idx].strip()
                    if status_mask_idx is not None
                    and status_mask_idx < len(row)
                    else ""
                )
                communication_type = (
                    row[communication_type_idx].strip()
                    if (
                        communication_type_idx is not None
                        and communication_type_idx < len(row)
                    )
                    else ""
                )
                controltype = (
                    row[controltype_idx].strip()
                    if (
                        controltype_idx is not None
                        and controltype_idx < len(row)
                    )
                    else ""
                )

                testcase_step = (
                    tc_id,
                    step_desc,
                    service_id,
                    subfunction_or_did,
                    expected_response,
                    write_data,
                    addressing,
                    format_type,
                    status_mask,
                    communication_type,
                    controltype,
                )
                grouped_cases[tc_id].append(testcase_step)
                ordered_testcases.append(testcase_step)

        return grouped_cases

    except Exception as e:
        print(f"Error parsing testcases: {e}")
        return {}


def load_testcase_sequence(file_path):
    load_testcases(file_path)
    return list(ordered_testcases)
