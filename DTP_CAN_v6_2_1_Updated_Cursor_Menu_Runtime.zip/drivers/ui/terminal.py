class TerminalUI:
    def show(self, message: str) -> None: print(message)
    def error(self, message: str) -> None: print(f"ERROR: {message}")

    def select_from_list(self, title, items, formatter=str, allow_cancel=False):
        if not items: return None
        index=0
        while True:
            print("\033[2J\033[H", end='')
            print('='*60)
            print(f'Select {title}')
            print('='*60)
            for i,item in enumerate(items):
                marker='>' if i==index else ' '
                print(f'{marker} {i+1:2d}. {formatter(item)}')
            print('\nControls: N/D = Next | P/A = Previous | Enter = Select')
            if allow_cancel: print('Q = Cancel')
            cmd=input('> ').strip().lower()
            if cmd=='': return index
            if cmd in {'n','d','down','right'}: index=(index+1)%len(items); continue
            if cmd in {'p','a','up','left'}: index=(index-1)%len(items); continue
            if allow_cancel and cmd=='q': return None
            if cmd.isdigit() and 1 <= int(cmd) <= len(items):
                index=int(cmd)-1
                continue
            print('Invalid key. Use N/D, P/A, or Enter.')
