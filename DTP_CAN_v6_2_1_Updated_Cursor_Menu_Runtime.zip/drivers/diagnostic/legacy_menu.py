import os, time
class DiagnosticMenu:
    def __init__(self,ui,git,uds): self.ui=ui; self.git=git; self.uds=uds
    def run(self):
        while True:
            options=['Read ECU Information','Run Test Cases','Shut Down','Push to Bitbucket']
            idx=self.ui.select_from_list('Diagnostic Main Menu',options)
            if idx is None: continue
            if idx==0: self._ecu_info()
            elif idx==1: self._run_tests()
            elif idx==2:
                self.ui.show('Shutting down...')
                os.system('sudo poweroff'); return
            elif idx==3: self._push()
    def _ecu_info(self):
        self.ui.show('Reading ECU information...')
        try: self.uds.get_ecu_information(self.ui)
        except Exception as exc: self.ui.error(f'ECU information failed: {exc}')
    def _run_tests(self):
        self.ui.show('Run Test Cases')
        tester=input('Tester Name (Enter = N/A): ').strip() or 'N/A'
        self.git.start_report_tracking()
        try:
            self.uds.run_testcase(self.ui,tester_name=tester)
        finally:
            reports=self.git.finish_report_tracking()
        self.ui.show(f'Test execution completed. New reports: {len(reports)}')
    def _push(self):
        try:
            self.git.copy_reports(); self.git.git_add(); self.git.git_commit(); self.git.git_push()
            self.ui.show('Upload Complete')
        except Exception as exc: self.ui.error(f'Bitbucket push failed: {exc}')
