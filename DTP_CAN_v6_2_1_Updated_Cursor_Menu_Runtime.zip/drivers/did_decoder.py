def decode_special_did_value(did, value, *args, **kwargs):
    if isinstance(value, bytes): return value.hex().upper()
    if isinstance(value, (list, tuple)): return ' '.join(str(x) for x in value)
    return value
