from __future__ import annotations
import os, time
from drivers.diagnostic.legacy_menu import DiagnosticMenu

class Application:
    def __init__(self, ui, startup_result, git):
        self.ui=ui; self.startup=startup_result; self.git=git
        self.uds=None
    def start_diagnostics(self):
        self.ui.show('\nInitializing diagnostic client...')
        from drivers.uds_client import UDSClient
        raw=self.startup.config.raw
        self.uds=UDSClient(raw, config_path=self.startup.config_path, repo_path=self.git.repo_path)
        self.uds.repo_path=self.git.repo_path
        try:
            self.uds.check_udp_server()
        except Exception as exc:
            self.ui.show(f'UDP server check warning: {exc}')
        DiagnosticMenu(self.ui,self.git,self.uds).run()
