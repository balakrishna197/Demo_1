from __future__ import annotations
import os, shutil, time
from dataclasses import dataclass
from pathlib import Path
from drivers.config.loader import ConfigLoader
from drivers.config.models import AppConfig
from drivers.network.wifi import WiFiManager
from drivers.repository.git import GitRepository
from drivers.ui.terminal import TerminalUI

@dataclass(frozen=True)
class StartupResult:
    wifi_ssid:str|None; employee:str; variant:str; test_type:str; stage:str; date:str; branch:str
    testcase:str; config_path:str; config:AppConfig; commit:str|None

class StartupCoordinator:
    def __init__(self,ui,wifi,git,config_loader,config_path_hint=None):
        self.ui=ui; self.wifi=wifi; self.git=git; self.config_loader=config_loader
        self.config_path_hint=Path(config_path_hint).resolve() if config_path_hint else None
    def run(self):
        ssid=self._select_wifi()
        employee=self._select('Employee ID',self.git.get_employee_ids())
        variant=self._select('Variant',self.git.get_variants(employee))
        test_type=self._select('Type',self.git.get_types(employee,variant))
        stage=self._select('Stage',self.git.get_stages(employee,variant,test_type))
        date=self._select('Date',self.git.get_dates(employee,variant,test_type,stage))
        branch=self.git.get_matching_branch(employee,variant,test_type,stage,date)
        self.ui.show(f'\nSelected Git Branch: {branch}')
        self.git.clone_repository(branch); self.git.pull_repository()
        testcases,configs=self.git.get_testcases_and_configs()
        testcase=self._select('Testcase',testcases,os.path.basename)
        config_path=self._select('Config JSON',configs,os.path.basename)
        self.git.copy_selected_testcase(testcase)
        config=self.config_loader.load(config_path)
        commit=self.git.current_commit()
        self.ui.show('\nRepository Ready')
        return StartupResult(ssid,employee,variant,test_type,stage,date,branch,testcase,config_path,config,commit)
    def _select_wifi(self):
        networks=self.wifi.scan()
        if not networks: raise RuntimeError('No Wi-Fi networks found.')
        selected=self._select('Wi-Fi',networks,lambda n:n.ssid)
        ssid=selected.ssid
        if not self.wifi.is_connected(ssid):
            password=input(f"Enter Wi-Fi password for '{ssid}': ")
            if not self.wifi.connect(ssid,password): raise RuntimeError(f'Failed to connect to Wi-Fi: {ssid}')
        self.ui.show(f'Connected to: {ssid}')
        return ssid
    def _select(self,title,items,formatter=str):
        if not items: raise RuntimeError(f'No {title} options found.')
        index=self.ui.select_from_list(title,items,formatter=formatter)
        if index is None: raise RuntimeError(f'{title} selection cancelled.')
        return items[index]
