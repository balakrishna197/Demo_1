import os
from pathlib import Path
from datetime import datetime

class CANLogger:
    def __init__(self, channel, interface, can_fd=True, log_dir='output/can_logs', filters=None):
        self.channel=channel; self.interface=interface; self.can_fd=can_fd
        self.log_dir=str(Path(log_dir)); self.filters=filters; self.path=None; self._logger=None; self._bus=None
    def start(self, filename):
        Path(self.log_dir).mkdir(parents=True,exist_ok=True)
        self.path=str(Path(self.log_dir)/filename)
        try:
            import can
            self._bus=can.interface.Bus(channel=self.channel,bustype=self.interface,fd=self.can_fd)
            from can import Logger
            self._logger=Logger(self.path)
            self._notifier=can.Notifier(self._bus,[self._logger])
        except Exception:
            # Preserve diagnostic execution even if CAN logging initialization fails;
            # the UDS client will still report the underlying CAN/ECU error.
            self._bus=None; self._logger=None
        return self.path
    def stop(self):
        try:
            if getattr(self,'_notifier',None): self._notifier.stop()
        except Exception: pass
        try:
            if self._logger: self._logger.stop()
        except Exception: pass
        try:
            if self._bus: self._bus.shutdown()
        except Exception: pass
