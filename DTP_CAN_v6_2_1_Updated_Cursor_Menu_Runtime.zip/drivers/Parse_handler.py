import csv
from pathlib import Path

HEADER_ALIASES = {
    "TC_ID": ["TC_ID", "TC ID", "Testcase ID", "Testcase", "TCID"],
    "DESCRIPTION": ["Description", "DESCRIPTION", "Step Description"],
    "SERVICE": ["Service", "SID", "Service ID"],
    "SUBFUNCTION": ["Subfunction", "Sub Function", "SubFunc", "Sub"],
    "EXPECTED": ["Expected Response", "Expected", "Expected Response Data"],
    "WRITE_DATA": ["Write Data", "Data", "WriteData"],
    "ADDRESSING": ["Addressing", "Addressing Mode", "Mode"],
    "FORMAT": ["Format", "Format Type"],
    "STATUS_MASK": ["Status Mask", "StatusMask"],
    "COMMUNICATION_TYPE": ["Communication Type", "CommunicationType"],
    "CONTROLTYPE": ["Control Type", "ControlType", "Controltype"],
}

def find_column(columns, aliases):
    normalized={str(k).strip().lower().replace('_',' '):v for k,v in columns.items()}
    for alias in aliases:
        key=alias.strip().lower().replace('_',' ')
        if key in normalized: return normalized[key]
    return -1

def _clean(v): return (v or '').strip()

def load_testcase_sequence(path):
    rows=[]
    with Path(path).open('r', encoding='utf-8-sig', newline='') as f:
        reader=csv.reader(f)
        all_rows=list(reader)
    header_idx=None
    header=None
    for i,row in enumerate(all_rows):
        if not row: continue
        first=_clean(row[0]).lstrip('#')
        if first.upper() in {x.upper() for x in HEADER_ALIASES['TC_ID']}:
            header=[_clean(x).lstrip('#') for x in row]; header_idx=i; break
    if header is None: raise ValueError(f'No testcase header found in {path}')
    columns={name:i for i,name in enumerate(header)}
    idx={k:find_column(columns,v) for k,v in HEADER_ALIASES.items()}
    for row in all_rows[header_idx+1:]:
        if not row or not any(_clean(x) for x in row): continue
        def val(k):
            i=idx[k]; return _clean(row[i]) if i>=0 and i<len(row) else ''
        tc=val('TC_ID')
        if not tc or tc.startswith('#'): continue
        if tc.upper()=='WAIT':
            try: rows.append(('WAIT', int(val('EXPECTED') or val('SERVICE') or '0')))
            except: rows.append(('WAIT',0))
            continue
        rows.append((tc,val('DESCRIPTION'),val('SERVICE'),val('SUBFUNCTION'),val('EXPECTED'),val('WRITE_DATA'),val('ADDRESSING') or 'physical',val('FORMAT'),val('STATUS_MASK'),val('COMMUNICATION_TYPE'),val('CONTROLTYPE')))
    return rows

def load_testcases(path):
    return load_testcase_sequence(path)
