"""Git/Bitbucket repository adapter preserving v6.2.1 selection behavior."""

from __future__ import annotations

import logging
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class RepositorySelection:
    branch: str
    commit: str | None
    testcase_path: str | None
    config_path: str | None


class GitRepository:
    """Git CLI adapter. Selection workflow stays in StartupCoordinator."""

    REPO_URL = "git@bitbucket.org:mobase-rnd/dtp-can.git"

    def __init__(self, base_dir: str):
        self.base_dir = str(Path(base_dir).resolve())
        self.repo_path: str | None = None
        self.branch: str | None = None

    def list_remote_branches(self) -> list[str]:
        result = subprocess.run(
            ["git", "ls-remote", "--heads", self.REPO_URL],
            capture_output=True, text=True, check=True,
        )
        branches = []
        for line in result.stdout.splitlines():
            if not line.strip() or "\t" not in line:
                continue
            ref = line.split("\t", 1)[1]
            branches.append(ref.replace("refs/heads/", ""))
        return sorted(set(branches))

    def _parts(self):
        return [b.split("/") for b in self.list_remote_branches()]

    def get_employee_ids(self):
        return sorted({p[0] for p in self._parts() if len(p) >= 5})

    def get_variants(self, employee):
        return sorted({p[1] for p in self._parts() if len(p) >= 5 and p[0] == employee})

    def get_types(self, employee, variant):
        return sorted({p[2] for p in self._parts() if len(p) >= 5 and p[:2] == [employee, variant]})

    def get_stages(self, employee, variant, test_type):
        return sorted({p[3] for p in self._parts() if len(p) >= 5 and p[:3] == [employee, variant, test_type]})

    def get_dates(self, employee, variant, test_type, stage):
        prefix = [employee, variant, test_type, stage]
        return sorted({p[4] for p in self._parts() if len(p) >= 5 and p[:4] == prefix})

    def get_matching_branch(self, employee, variant, test_type, stage, date):
        target = [employee, variant, test_type, stage, date]
        for parts in self._parts():
            if len(parts) >= 5 and parts[:5] == target:
                return "/".join(parts)
        raise RuntimeError("Matching branch not found")

    def clone_repository(self, branch: str):
        self.branch = branch
        safe_branch_name = branch.replace("/", "_")
        self.repo_path = os.path.join(self.base_dir, safe_branch_name)
        logging.info("Selected Branch: %s", branch)
        logging.info("Repository Path: %s", self.repo_path)

        if os.path.isdir(os.path.join(self.repo_path, ".git")):
            return
        if os.path.exists(self.repo_path):
            raise RuntimeError(f"Repository path exists but is not a Git repository: {self.repo_path}")

        subprocess.run(
            ["git", "clone", "--branch", branch, self.REPO_URL, self.repo_path],
            check=True,
        )

    def pull_repository(self):
        if not self.branch or not self.repo_path:
            raise RuntimeError("Branch/repository not selected")
        subprocess.run(
            ["git", "-C", self.repo_path, "pull", "origin", self.branch],
            check=True,
        )

    def get_testcases_and_configs(self):
        if not self.repo_path:
            raise RuntimeError("Repository has not been selected")
        testcases, configs = [], []
        for root, dirs, files in os.walk(self.repo_path):
            if ".git" in dirs:
                dirs.remove(".git")
            for filename in files:
                path = os.path.join(root, filename)
                lower = filename.lower()
                if lower.endswith(".txt"):
                    testcases.append(path)
                elif lower.endswith(".json") and lower != "git_credentials.json":
                    configs.append(path)
        if not testcases:
            raise RuntimeError("No testcase files found")
        if not configs:
            raise RuntimeError("No config files found")
        return sorted(testcases), sorted(configs)

    def copy_selected_testcase(self, testcase_path):
        root=Path(self.base_dir)
        support=root / "supportfiles"
        support.mkdir(parents=True, exist_ok=True)
        for item in support.glob("*.txt"):
            try: item.unlink()
            except OSError: pass
        dst=support / Path(testcase_path).name
        import shutil
        shutil.copy2(testcase_path,dst)
        (root / "selected_testcase.txt").write_text(dst.name,encoding="utf-8")
        return str(dst)

    def start_report_tracking(self):
        output=Path(self.base_dir)/"output"
        output.mkdir(parents=True,exist_ok=True)
        self._output_snapshot={str(p.relative_to(output)) for p in output.rglob('*') if p.is_file()}
        self.current_run_reports=[]

    def finish_report_tracking(self):
        output=Path(self.base_dir)/"output"
        current={str(p.relative_to(output)) for p in output.rglob('*') if p.is_file()}
        self.current_run_reports=sorted(current-self._output_snapshot)
        return self.current_run_reports

    def copy_reports(self):
        if not self.repo_path: raise RuntimeError("Repository not selected")
        source=Path(self.base_dir)/"output"; dest=Path(self.repo_path)/"output"
        if not getattr(self,'current_run_reports',[]): raise RuntimeError("No new reports generated in current run")
        import shutil
        for rel in self.current_run_reports:
            src=source/rel; dst=dest/rel; dst.parent.mkdir(parents=True,exist_ok=True)
            if src.is_file(): shutil.copy2(src,dst)

    def git_add(self): subprocess.run(["git","-C",self.repo_path,"add","."],check=True)
    def git_commit(self): subprocess.run(["git","-C",self.repo_path,"commit","-m","Updated Reports"],check=False)
    def git_push(self): subprocess.run(["git","-C",self.repo_path,"push","-u","origin",self.branch],check=True)

    def current_commit(self, repository_path: str | None = None):
        repo = repository_path or self.repo_path or self.base_dir
        result = subprocess.run(
            ["git", "-C", repo, "rev-parse", "HEAD"],
            capture_output=True, text=True, check=False,
        )
        return result.stdout.strip() if result.returncode == 0 else None
