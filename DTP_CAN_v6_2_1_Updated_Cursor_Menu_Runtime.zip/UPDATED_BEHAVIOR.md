# DTP-CAN v6.2.1 Updated Behavior

## Selection behavior
All available choices are displayed at once with a `>` cursor.

- `N` / `D` / Down / Right: move cursor to next item
- `P` / `A` / Up / Left: move cursor to previous item
- **Enter**: select the item under the cursor
- The same selector is used for Wi-Fi, Employee ID, Variant, Type, Stage, Date, Testcase, Config and Diagnostic Main Menu.

The full list is no longer hidden behind a single-item prompt.

## Runtime flow
Wi-Fi -> Employee -> Variant -> Type -> Stage -> Date -> matching branch -> clone/pull -> Testcase -> JSON Config -> UDS client -> Diagnostic Main Menu.

Diagnostic Main Menu:
1. Read ECU Information
2. Run Test Cases
3. Shut Down
4. Push to Bitbucket

`Run Test Cases` calls the production v6.2.1 `UDSClient.run_testcase()` instead of the previous modular scaffold's `NotImplementedError` transport.

## JSON build rule
No repository/config JSON is required at build time. The JSON is selected after the Git repository is cloned and is loaded by absolute path.
