"""DTP-CAN v6.2.1 composition root.

Startup selects the full available lists with a visible cursor. Enter selects
that cursor. After repository/config selection the original diagnostic main
menu is started and Run Test Cases calls the production v6.2.1 UDSClient.
"""
from drivers.application.startup import StartupCoordinator
from drivers.application.application import Application
from drivers.config.loader import ConfigLoader
from drivers.config.paths import AppPaths
from drivers.network.wifi import WiFiManager
from drivers.repository.git import GitRepository
from drivers.ui.terminal import TerminalUI

def main():
    print('DTP-CAN v6.2.1')
    paths=AppPaths(); paths.ensure_output_dirs()
    ui=TerminalUI(); git=GitRepository(str(paths.base_dir)); wifi=WiFiManager(); loader=ConfigLoader(paths)
    startup=StartupCoordinator(ui,wifi,git,loader)
    result=startup.run()
    Application(ui,result,git).start_diagnostics()
    return 0
if __name__=='__main__': raise SystemExit(main())
