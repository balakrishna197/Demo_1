#!/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

echo "DTP-CAN v6.2.1 build"
echo "Project: $PROJECT_DIR"

if [[ ! -f "$PROJECT_DIR/config/config.json" ]]; then
    echo "ERROR: config/config.json not found."
    exit 1
fi

if [[ ! -d "$PROJECT_DIR/drivers" ]]; then
    echo "ERROR: drivers package not found."
    exit 1
fi

python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
python3 -m pip install pyinstaller

rm -rf build dist
mkdir -p dist

pyinstaller \
    --clean \
    --onefile \
    --name uds_diagnostics \
    --collect-submodules drivers \
    main.py

echo ""
echo "Build complete:"
echo "  $PROJECT_DIR/dist/uds_diagnostics"
echo ""
echo "Runtime configuration:"
echo "  $PROJECT_DIR/config/config.json"
