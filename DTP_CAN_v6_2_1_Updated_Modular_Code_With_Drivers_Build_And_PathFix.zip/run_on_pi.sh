#!/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXECUTABLE="$PROJECT_DIR/dist/uds_diagnostics"

if [[ ! -x "$EXECUTABLE" ]]; then
    echo "ERROR: $EXECUTABLE not found."
    echo "Run ./build_on_pi.sh first."
    exit 1
fi

cd "$PROJECT_DIR"
exec "$EXECUTABLE"
