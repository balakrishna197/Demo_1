"""JSON configuration loader for source and PyInstaller execution."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .paths import ApplicationPaths


class ConfigLoader:
    """Load configuration without depending on the current working directory."""

    def __init__(self, paths: ApplicationPaths | None = None) -> None:
        self.paths = paths or ApplicationPaths()

    def resolve(self, path: str | Path) -> Path:
        requested = Path(path)
        if requested.is_absolute():
            return requested
        return self.paths.project_root / requested

    def load(self, path: str | Path = "config/config.json") -> dict[str, Any]:
        config_path = self.resolve(path)

        if not config_path.is_file():
            raise FileNotFoundError(
                f"Configuration file not found: {config_path}\n"
                f"Project root: {self.paths.project_root}\n"
                f"Current working directory: {Path.cwd()}"
            )

        try:
            with config_path.open("r", encoding="utf-8") as file:
                data = json.load(file)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"Invalid JSON configuration: {config_path}; "
                f"line={exc.lineno}, column={exc.colno}: {exc.msg}"
            ) from exc

        if not isinstance(data, dict):
            raise ValueError(f"Configuration root must be a JSON object: {config_path}")

        return data
