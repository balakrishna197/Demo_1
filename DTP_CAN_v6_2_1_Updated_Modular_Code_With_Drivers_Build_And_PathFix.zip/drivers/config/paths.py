"""Central runtime path management for DTP-CAN v6.2.1."""

from __future__ import annotations

import sys
from pathlib import Path


class ApplicationPaths:
    """Resolve paths consistently in source and PyInstaller execution."""

    def __init__(self, project_root: Path | None = None) -> None:
        self.project_root = (
            project_root.resolve()
            if project_root is not None
            else self._resolve_project_root()
        )

    @staticmethod
    def _resolve_project_root() -> Path:
        if getattr(sys, "frozen", False):
            # dist/uds_diagnostics -> project root
            return Path(sys.executable).resolve().parent.parent

        # drivers/config/paths.py -> project root
        return Path(__file__).resolve().parents[2]

    @property
    def config_dir(self) -> Path:
        return self.project_root / "config"

    @property
    def config_file(self) -> Path:
        return self.config_dir / "config.json"

    @property
    def supportfiles_dir(self) -> Path:
        return self.project_root / "supportfiles"

    @property
    def output_dir(self) -> Path:
        return self.project_root / "output"

    @property
    def can_logs_dir(self) -> Path:
        return self.output_dir / "can_logs"

    @property
    def html_reports_dir(self) -> Path:
        return self.output_dir / "html_reports"

    @property
    def logs_dir(self) -> Path:
        return self.output_dir / "logs"

    def create_runtime_directories(self) -> None:
        for directory in (
            self.supportfiles_dir,
            self.can_logs_dir,
            self.html_reports_dir,
            self.logs_dir,
        ):
            directory.mkdir(parents=True, exist_ok=True)
